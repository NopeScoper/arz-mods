return function(GT_MOD)

    local InterfaceEditor = {} -- module
    InterfaceEditor.preset = {}
    InterfaceEditor.txtFiles = {}

    local imgui = require("mimgui")
    local ffi = require("ffi")
    local new, sizeof, str = imgui.new, ffi.sizeof, ffi.string

    local fa = require("fAwesome5")
    local encoding = require("encoding")
    encoding.default = "CP1251"
    local u8 = encoding.UTF8

    local checkboxes, sliders, buffers = GT_MOD.UI.checkboxes, GT_MOD.UI.sliders, GT_MOD.UI.buffers
   
    local navigations = GT_MOD.UI.navigations

    local col1 = imgui.ImVec4(GT_MOD.config.ini.BeginColor.r, GT_MOD.config.ini.BeginColor.g, GT_MOD.config.ini.BeginColor.b, GT_MOD.config.ini.BeginColor.a)
    local col2 = imgui.ImVec4(GT_MOD.config.ini.ColorText.r, GT_MOD.config.ini.ColorText.g, GT_MOD.config.ini.ColorText.b, GT_MOD.config.ini.ColorText.a)

    local IEPresets = {
        Money = {
            posMoneyX=-32,
            fontmoneyborder=2,
            animmoney=2,
            sizeMoneyY=1.1,
            EditMoney=true,
            moneyzerofix=false,
            fontmoneystyle=3,
            posdollar=0,
            sizeMoneyX=0.55,
            posMoneyY=89,
        },
        Radar = {
            radaralpha=255,
            radarblipA=255,
            radarPosX=40,
            radarfix=true,
            minimapzoom=false,
            minimapzoomvalue=180.0,
            smalliconsradar=false,
            roundedRadarSize=1.0,
            radarWidth=76,
            radar_color_fix=false,
            radarPosY=104,
            radarHeight=94,
            trianglev_icon_border=1.4,
            trianglen_icon_size=1.4,
            player_icon_size=7.0,
            smalliconsradar=false,
            quadro_icon_size=1.4,
            trianglen_icon_border=1.4,
            quadro_icon_border=1.4,
            trianglev_icon_size=1.4,
            osnov_icon=7.5,
            arrowmap_size=10,
            radrarnorth=false,
            Type=0,
            radardisc=false,
        },
        Health = {
            nohealthflick=false,
            healthborder=true,
            sizeHealthY=9,
            posHealthY=77,
            posHealthX=-141,
            sizeHealthX=109,
            EditHealth=true,
            oneHundredAndSixtyHPbar=false,
        },
        Armor = {
            EditArmor=true,
            posArmorX=-94,
            posArmorY=48,
            sizeArmorX =62,
            sizeArmorY =9,
            eternalArmor=false,
            armorborder=true,
        },
        Wanted = {
            spaceWanted=18,
            sizeWantedY=1.21,
            sizeWantedX=0.6,
            posWantedX=-29,
            EditWanted=true,
            eternalwanted=false,
            posWantedY=114,
            emptyStars=false,
        },
        Crosshair = {
            crosshairSizeX=64.0,
            crosshairSizeY=64.0,
            nocrosshaireditsize=false,
        },
        Patrons = {
            sizePatronsY=0.7,
            posPatronsY=43,
            EditPatrons=true,
            sizePatronsX=0.3,
            posPatronsX=47,
            renderammo=false,
            fontammostyle=1,
            singleclip = false,
            EternalPatrons = false,
        },
        MenuPause = {
            beginmenu=false,
            fullmenuheight=480,
            fontmenubasestyle=2,
            fullmenuwidth=640,
            fontmenutumblerstyle=2,
            fontmenuheaderstyle=0,
            fullmenuimage=false,
            speedinputsmap=21.00,
            mapzoomvalue=300,
            mapzoomfixer=true,
            fixloadmap=true,
            mapzoom=true,
            helptext=false,
            arrowicon_menu=false,
            gxtEntryEditor=false,
            beginText="���� �����",
            useMynameInBeginMenu=false,
            resume ="����������",
            start_new_game="������ ����� ����",
            map="�����",
            stats="����������",
            brief="������",
            settings="���������",
            quitGame="����� �� ����",
        },
        Breath = {
            posBreathX=-94,
            EditBreath=true,
            sizeBreathY=9,
            breathborder=true,
            eternalBreath=false,
            sizeBreathX=62,
            posBreathY=62,
        },
        Weapon = {
            sizeWeaponY=58,
            posWeaponX=-32,
            posWeaponY=20,
            sizeWeaponX=47,
            EditWeapon=true,
        },
        Clock = {
            posClockX=-32,
            fontstyleclock=2,
            fontoutlineclock=2,
            sizeClockX=0.55,
            posClockY=22,
            DrawClock=false,
            PcClock=false,
            DrawSec=false,
            EditClock=true,
            sizeClockY=1.1,
        },
        Other = {
            showhud=false,
            showchat=false,
            targetblip=true,
            areanames=false,
            areanamesSize=0.7,
            areanamesPosX=32,
            areanamesPosY=76,
            vehiclenames=false,
            vehiclenamesSize=0.7,
            vehiclenamesPosX=32,
            vehiclenamesPosY=104,
        },
        Recolorer = {
            Recolorer = false,
            Health = -6222836,
            Armor = -1,
            Stars = -2851328,
            Patrons = -3543041,
            PlayerHealth = -65536,
            PlayerHealth2 = -15461356,
            PlayerArmor = -1,
            PlayerArmor2 = -15461356,
            Money = -16751862,
        },
        HPHud = {
            Status = false,
            fonts = 3,
            hptext = false,
            posX = 609.70,
            posY = 66.0,
            Color = "0xFFFFFFFF",
            sizeX = 0.250,
            sizeY = 1.000,
        },
        ArmorHud = {
            Status = false,
            fonts = 3,
            armortext = false,
            posX = 609.70,
            posY = 44.30,
            Color = "0xFFFFFFFF",
            sizeX = 0.250,
            sizeY = 1.000,
        },
    }

    local function formatterJson(data, options)
        local function pretty(dataStr, spaces)
            local spaces = spaces ~= nil and string.rep(' ', spaces) or '\t' 
            local result = ''
            local level = 0
            local in_string = false
            
            for i = 1, #dataStr do
                local c = dataStr:sub(i, i)
            
                if c == '{' or c == '[' then
                    level = level + 1
                    result = result .. c .. '\n' .. string.rep(spaces, level)
                elseif c == '}' or c == ']' then
                    level = level - 1
                    result = result .. '\n' .. string.rep(spaces, level) .. c
                elseif c == ',' then
                    result = result .. c
                    if not in_string then
                        result = result .. '\n' .. string.rep(spaces, level)
                    end
                elseif c == ':' then
                    result = result .. ': '
                else
                    result = result .. c
                    if c == '"' then
                        in_string = not in_string
                    end
                end
            end
            
            return result
        end

        local options = options or { }
        local data = type(data) == 'table' and encodeJson(data) or data
        local dataStr = pretty(data, options['spaces'])

        return dataStr
    end

    function InterfaceEditor.getJson()
        if not doesDirectoryExist(getWorkingDirectory().."\\GameTweaker\\IE-presets") then
            createDirectory(getWorkingDirectory().."\\GameTweaker\\IE-presets")
        end
        if doesFileExist(getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..GT_MOD.config.ini.settings.currentpreset) then
            local jsfile = getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..GT_MOD.config.ini.settings.currentpreset
            local file = io.open(jsfile, "r")
            a = file:read("*a")
            file:close()
            InterfaceEditor.preset = decodeJson(a)
            local file = io.open(jsfile, "w")
            file:write(formatterJson(InterfaceEditor.preset))
            file:flush()
            file:close()
        else
            local file = io.open(getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..GT_MOD.config.ini.settings.currentpreset, "a+")
            file:close()
            local file = io.open(getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..GT_MOD.config.ini.settings.currentpreset, "w")
            file:write(formatterJson(IEPresets))
            file:flush()
            file:close()
            InterfaceEditor.getJson()
        end
    end

    function InterfaceEditor.jsonExist(table)
        for key, value in pairs(table) do
            for subkey, subvalue in pairs(value) do
                if InterfaceEditor.preset[key][subkey] == nil then
                    InterfaceEditor.preset[key][subkey] = subvalue
                end
            end
        end
    end

    function InterfaceEditor.saveJson()
        local file = io.open(getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..GT_MOD.config.ini.settings.currentpreset, "w")
        file:write(formatterJson(InterfaceEditor.preset))
        file:flush()
        file:close()
    end

    function InterfaceEditor.getTxtFilesInDirectory(directory)
        InterfaceEditor.txtFiles = {}
        for filename in lfs.dir(directory) do
            if filename:match("%.json$") then
                table.insert(InterfaceEditor.txtFiles, filename)
            end
        end
        return InterfaceEditor.txtFiles
    end

    function InterfaceEditor.getSelect(id, name)
        for i, v in ipairs(name) do
            if v == id then
                return i
            end
        end
        return 1
    end

    -- Initialize
    InterfaceEditor.getJson()
    InterfaceEditor.jsonExist(IEPresets)

    local preset = InterfaceEditor.preset

    local function explode_rgba(argb)
        local a = bit.band(bit.rshift(argb, 24), 0xFF) / 255
        local r = bit.band(bit.rshift(argb, 16), 0xFF) / 255
        local g = bit.band(bit.rshift(argb, 8), 0xFF) / 255
        local b = bit.band(argb, 0xFF) / 255
        return r, g, b, a
    end

    local function LoadPresetData()
        sliders = {
            mapzoomvalue = new.float(tonumber(preset["MenuPause"]["mapzoomvalue"])),
            roundedRadarSize = new.float(tonumber(preset["Radar"]["roundedRadarSize"])),
            radaralpha = new.float(tonumber(preset["Radar"]["radaralpha"])),
            radarblipA = new.float(tonumber(preset["Radar"]["radarblipA"])),
            radarw = new.float(tonumber(preset["Radar"]["radarWidth"])),
            radarh = new.float(tonumber(preset["Radar"]["radarHeight"])),
            radarposx = new.float(tonumber(preset["Radar"]["radarPosX"])),
            radarposy = new.float(tonumber(preset["Radar"]["radarPosY"])),
            minimapzoomvalue = new.float(tonumber(preset["Radar"]["minimapzoomvalue"])),
            hpposX = new.float(tonumber(preset["HPHud"]["posX"])),
            hpposY = new.float(tonumber(preset["HPHud"]["posY"])),
            hpSizeX = new.float(tonumber(preset["HPHud"]["sizeX"])),
            hpSizeY = new.float(tonumber(preset["HPHud"]["sizeY"])),
            armorhudPosX = new.float(tonumber(preset["ArmorHud"]["posX"])),
            armorhudPosY = new.float(tonumber(preset["ArmorHud"]["posY"])),
            armorhudSizeX = new.float(tonumber(preset["ArmorHud"]["sizeX"])),
            armorhudSizeY = new.float(tonumber(preset["ArmorHud"]["sizeY"])),
            speedinputsmap = new.float(tonumber(preset["MenuPause"]["speedinputsmap"])),
            osnov_icon = new.float(tonumber(preset["Radar"]["osnov_icon"])),
            quadro_icon_size = new.float(tonumber(preset["Radar"]["quadro_icon_size"])),
            quadro_icon_border = new.float(tonumber(preset["Radar"]["quadro_icon_border"])),
            trianglev_icon_size = new.float(tonumber(preset["Radar"]["trianglev_icon_size"])),
            trianglev_icon_border = new.float(tonumber(preset["Radar"]["trianglev_icon_border"])),
            trianglen_icon_size = new.float(tonumber(preset["Radar"]["trianglen_icon_size"])),
            trianglen_icon_border = new.float(tonumber(preset["Radar"]["trianglen_icon_border"])),
            player_icon_size = new.float(tonumber(preset["Radar"]["player_icon_size"])),
            arrowmap_size = new.float(tonumber(preset["Radar"]["arrowmap_size"])),
            posPatronsX = new.float(tonumber(preset["Patrons"]["posPatronsX"])),
            posPatronsY = new.float(tonumber(preset["Patrons"]["posPatronsY"])),
            sizePatronsX = new.float(tonumber(preset["Patrons"]["sizePatronsX"])),
            sizePatronsY = new.float(tonumber(preset["Patrons"]["sizePatronsY"])),
            posHealthX = new.float(tonumber(preset["Health"]["posHealthX"])),
            posHealthY = new.float(tonumber(preset["Health"]["posHealthY"])),
            sizeHealthX = new.float(tonumber(preset["Health"]["sizeHealthX"])),
            sizeHealthY = new.float(tonumber(preset["Health"]["sizeHealthY"])),
            posMoneyX = new.float(tonumber(preset["Money"]["posMoneyX"])),
            posMoneyY = new.float(tonumber(preset["Money"]["posMoneyY"])),
            sizeMoneyX = new.float(tonumber(preset["Money"]["sizeMoneyX"])),
            sizeMoneyY = new.float(tonumber(preset["Money"]["sizeMoneyY"])),
            posBreathX = new.float(tonumber(preset["Breath"]["posBreathX"])),
            posBreathY = new.float(tonumber(preset["Breath"]["posBreathY"])),
            sizeBreathX = new.float(tonumber(preset["Breath"]["sizeBreathX"])),
            sizeBreathY = new.float(tonumber(preset["Breath"]["sizeBreathY"])),
            posArmorX = new.float(tonumber(preset["Armor"]["posArmorX"])),
            posArmorY = new.float(tonumber(preset["Armor"]["posArmorY"])),
            sizeArmorX = new.float(tonumber(preset["Armor"]["sizeArmorX"])),
            sizeArmorY = new.float(tonumber(preset["Armor"]["sizeArmorY"])),
            posWeaponX = new.float(tonumber(preset["Weapon"]["posWeaponX"])),
            posWeaponY = new.float(tonumber(preset["Weapon"]["posWeaponY"])),
            sizeWeaponX = new.float(tonumber(preset["Weapon"]["sizeWeaponX"])),
            sizeWeaponY = new.float(tonumber(preset["Weapon"]["sizeWeaponY"])),
            posWantedX = new.float(tonumber(preset["Wanted"]["posWantedX"])),
            posWantedY = new.float(tonumber(preset["Wanted"]["posWantedY"])),
            sizeWantedX = new.float(tonumber(preset["Wanted"]["sizeWantedX"])),
            sizeWantedY = new.float(tonumber(preset["Wanted"]["sizeWantedY"])),
            spaceWanted = new.float(tonumber(preset["Wanted"]["spaceWanted"])),
            posClockX = new.float(tonumber(preset["Clock"]["posClockX"])),
            posClockY = new.float(tonumber(preset["Clock"]["posClockY"])),
            sizeClockX = new.float(tonumber(preset["Clock"]["sizeClockX"])),
            sizeClockY = new.float(tonumber(preset["Clock"]["sizeClockY"])),


            areanamesSize = new.float(tonumber(preset["Other"]["areanamesSize"])),
            areanamesPosX = new.float(tonumber(preset["Other"]["areanamesPosX"])),
            areanamesPosY = new.float(tonumber(preset["Other"]["areanamesPosY"])),
            --
            vehiclenamesSize = new.float(tonumber(preset["Other"]["vehiclenamesSize"])),
            vehiclenamesPosX = new.float(tonumber(preset["Other"]["vehiclenamesPosX"])),
            vehiclenamesPosY = new.float(tonumber(preset["Other"]["vehiclenamesPosY"])),
        }

        checkboxes = {
            emptyStars = new.bool(preset["Wanted"]["emptyStars"]),
            mapzoom = new.bool(preset["MenuPause"]["mapzoom"]),
            radarfix = new.bool(preset["Radar"]["radarfix"]),
            minimapzoom = new.bool(preset["Radar"]["minimapzoom"]),
            radardisc = new.bool(preset["Radar"]["radardisc"]),
            radar_color_fix = new.bool(preset["Radar"]["radar_color_fix"]),
            mapzoomfixer = new.bool(preset["MenuPause"]["mapzoomfixer"]),
            hphud = new.bool(preset["HPHud"]["Status"]),
            nohealthflick = new.bool(preset["Health"]["nohealthflick"]),
            oneHundredAndSixtyHPbar = new.bool(preset["Health"]["oneHundredAndSixtyHPbar"]),
            hpt = new.bool(preset["HPHud"]["hptext"]),
            armorhud = new.bool(preset["ArmorHud"]["Status"]),
            armortext = new.bool(preset["ArmorHud"]["armortext"]),
            targetblip = new.bool(preset["Other"]["targetblip"]),
            vehiclenames = new.bool(preset["Other"]["vehiclenames"]),
            areanames = new.bool(preset["Other"]["areanames"]),
            fixloadmap = new.bool(preset["MenuPause"]["fixloadmap"]),
            helptext = new.bool(preset["MenuPause"]["helptext"]),
            beginmenu = new.bool(preset["MenuPause"]["beginmenu"]),
            recolorer = new.bool(preset["Recolorer"]["Recolorer"]),
            nocrosshaireditsize = new.bool(preset["Crosshair"]["nocrosshaireditsize"]),
            renderammo = new.bool(preset["Patrons"]["renderammo"]),
            singleclip = new.bool(preset["Patrons"]["singleclip"]),
            EternalPatrons = new.bool(preset["Patrons"]["EternalPatrons"]),
            showchat = new.bool(preset["Other"]["showchat"]),
            showhud = new.bool(preset["Other"]["showhud"]),
            moneyzerofix = new.bool(preset["Money"]["moneyzerofix"]),
            fullmenuimage = new.bool(preset["MenuPause"]["fullmenuimage"]),
            smalliconsradar = new.bool(preset["Radar"]["smalliconsradar"]),
            radrarnorth = new.bool(preset["Radar"]["radrarnorth"]),
            arrowicon_menu = new.bool(preset["MenuPause"]["arrowicon_menu"]),
            gxtEntryEditor = new.bool(preset["MenuPause"]["gxtEntryEditor"]),
            useMynameInBeginMenu = new.bool(preset["MenuPause"]["useMynameInBeginMenu"]),
            EditPatrons = new.bool(preset["Patrons"]["EditPatrons"]),
            EditHealth = new.bool(preset["Health"]["EditHealth"]),
            healthborder = new.bool(preset["Health"]["healthborder"]),
            EditMoney = new.bool(preset["Money"]["EditMoney"]),
            EditBreath = new.bool(preset["Breath"]["EditBreath"]),
            breathborder = new.bool(preset["Breath"]["breathborder"]),
            eternalBreath = new.bool(preset["Breath"]["eternalBreath"]),
            EditArmor = new.bool(preset["Armor"]["EditArmor"]),
            armorborder = new.bool(preset["Armor"]["armorborder"]),
            eternalArmor = new.bool(preset["Armor"]["eternalArmor"]),
            EditWeapon = new.bool(preset["Weapon"]["EditWeapon"]),
            EditWanted = new.bool(preset["Wanted"]["EditWanted"]),
            eternalwanted = new.bool(preset["Wanted"]["eternalwanted"]),
            EditClock = new.bool(preset["Clock"]["EditClock"]),
            DrawClock = new.bool(preset["Clock"]["DrawClock"]),
            PcClock = new.bool(preset["Clock"]["PcClock"]),
            DrawSec = new.bool(preset["Clock"]["DrawSec"])
        }

        buffers = {
            crosshairX = new.float(tonumber(preset["Crosshair"]["crosshairSizeX"])),
            crosshairY = new.float(tonumber(preset["Crosshair"]["crosshairSizeY"])),
            fullmenuheight = new.float(tonumber(preset["MenuPause"]["fullmenuheight"])),
            fullmenuwidth = new.float(tonumber(preset["MenuPause"]["fullmenuwidth"])),
            beginText = new.char[64](u8(preset["MenuPause"]["beginText"])),
            resume = new.char[64](u8(preset["MenuPause"]["resume"])),
            start_new_game = new.char[64](u8(preset["MenuPause"]["start_new_game"])),
            map = new.char[64](u8(preset["MenuPause"]["map"])),
            stats = new.char[64](u8(preset["MenuPause"]["stats"])),
            brief = new.char[64](u8(preset["MenuPause"]["brief"])),
            settings = new.char[64](u8(preset["MenuPause"]["settings"])),
            quitGame = new.char[64](u8(preset["MenuPause"]["quitGame"]))
        }

        icolors = {
            RECOLORER_HEALTH = new.float[4](explode_rgba(preset["Recolorer"]["Health"])),
            RECOLORER_ARMOUR = new.float[4](explode_rgba(preset["Recolorer"]["Armor"])),
            RECOLORER_PLAYERHEALTH = new.float[4](explode_rgba(preset["Recolorer"]["PlayerHealth"])),
            RECOLORER_PLAYERHEALTH2 = new.float[4](explode_rgba(preset["Recolorer"]["PlayerHealth2"])),
            RECOLORER_PLAYERARMOR = new.float[4](explode_rgba(preset["Recolorer"]["PlayerArmor"])),
            RECOLORER_PLAYERARMOR2 = new.float[4](explode_rgba(preset["Recolorer"]["PlayerArmor2"])),
            RECOLORER_MONEY = new.float[4](explode_rgba(preset["Recolorer"]["Money"])),
            RECOLORER_STARS = new.float[4](explode_rgba(preset["Recolorer"]["Stars"])),
            RECOLORER_PATRONS = new.float[4](explode_rgba(preset["Recolorer"]["Patrons"])),
            IndicatorHP_color = new.float[4](explode_rgba(preset["HPHud"]["Color"])),
            IndicatorARMOR_color = new.float[4](explode_rgba(preset["ArmorHud"]["Color"]))
        }

        ivar = {
            animmoney = new.int(tonumber(preset["Money"]["animmoney"])),
            fontmoneybordervar = new.int(tonumber(preset["Money"]["fontmoneyborder"])),
            fontoutlineclockvar = new.int(tonumber(preset["Clock"]["fontoutlineclock"])),
            fontmoneystylevar = new.int(tonumber(preset["Money"]["fontmoneystyle"])),
            posdollarvar = new.int(tonumber(preset["Money"]["posdollar"])),
            fontammostylevar = new.int(tonumber(preset["Patrons"]["fontammostyle"])),
            fontstyleclockvar = new.int(tonumber(preset["Clock"]["fontstyleclock"])),
            fontmenubasestylevar = new.int(tonumber(preset["MenuPause"]["fontmenubasestyle"])),
            fontmenuheaderstylevar = new.int(tonumber(preset["MenuPause"]["fontmenuheaderstyle"])),
            fontmenutumblerstylevar = new.int(tonumber(preset["MenuPause"]["fontmenutumblerstyle"])),
            fontstylehpvar = new.int(tonumber(preset["HPHud"]["fonts"])),
            fontstylearmvar = new.int(tonumber(preset["ArmorHud"]["fonts"])),
            radarTypeVar = new.int(tonumber(preset["Radar"]["Type"]))
        }
    end

    LoadPresetData()

    local txtFilesInCurrentDirectory = InterfaceEditor.getTxtFilesInDirectory(
        getGameDirectory().."\\moonloader\\GameTweaker\\IE-presets"
    )
    local selectedFile = 1
    local tempName, tempIter



    local function drawFileSelection()
        GT_MOD.UI.MainBox("�������", imgui.ImVec2(200,300), 0)

        imgui.PushFont(GT_MOD.UI.fonts[35])
        imgui.PushStyleColor(imgui.Col.Text, col1)
        imgui.Text(u8"�������")
        imgui.PopStyleColor()
        imgui.PopFont()
        imgui.Spacing()
        imgui.PushStyleColor(imgui.Col.Text, col2)
            for i, filename in pairs(txtFilesInCurrentDirectory) do
                imgui.PushFont(GT_MOD.UI.fonts.icons_18)
                if imgui.Button(fa.ICON_FA_TRASH.."##" .. i) and filename ~= "Standart.json" then
                    tempName = filename
                    tempIter = i
                    imgui.OpenPopup(u8'�������� �������')
                end
                
                imgui.PopFont()
            
                imgui.SameLine()
                if selectedFile ~= InterfaceEditor.getSelect(GT_MOD.config.ini.settings.currentpreset, txtFilesInCurrentDirectory) then
                    selectedFile = InterfaceEditor.getSelect(GT_MOD.config.ini.settings.currentpreset, txtFilesInCurrentDirectory)
                end
                if imgui.Selectable((string.gsub(u8(filename), ".json", "")), selectedFile == i) then 
                    selectedFile = i
                    GT_MOD.config.ini.settings.currentpreset = filename
                    GT_MOD.config.save()

                    InterfaceEditor.getJson()
                    InterfaceEditor.jsonExist(IEPresets)
                    InterfaceEditor.saveJson()

                    preset = InterfaceEditor.preset
                    
                    GT_MOD.functions.gotofunc("InterfaceElementEditor") 
                    GT_MOD.functions.gotofunc("Recolorer")
                    LoadPresetData()
                end
            end
        
            if imgui.BeginPopupModal(u8'�������� �������', nil, imgui.WindowFlags.NoResize) then
                imgui.Text(u8"�� ������������� ������ ������� "..u8:encode(tempName).." ?")
                imgui.SetCursorPosX(imgui.GetCursorPos().x + 60)
                if imgui.Button(u8"�������", imgui.ImVec2(90, 24)) and tempName ~= "Standart.json" then
                    table.remove(txtFilesInCurrentDirectory, tempIter)
                    selectedFile = 0
                    os.remove(getGameDirectory().."\\moonloader\\GameTweaker\\IE-presets\\"..tempName)
                    imgui.CloseCurrentPopup()
                end
                imgui.SameLine()
                imgui.SetCursorPosX(imgui.GetCursorPos().x + 10)
                if imgui.Button(u8"������", imgui.ImVec2(80, 24)) then
                    imgui.CloseCurrentPopup()
                end
                imgui.EndPopup()
            end
            
        imgui.PopStyleColor()
        imgui.EndChild()
    end

    function InterfaceEditor.ImGui_Draw()

        imgui.SetCursorPos(imgui.ImVec2(imgui.GetWindowSize().x / 30, imgui.GetCursorPosY() + 5))
        imgui.PushFont(GT_MOD.UI.fonts[50])
        --imgui.TextColored(imgui.ImVec4(GT_MOD.config.ini.BeginColor.r, GT_MOD.config.ini.BeginColor.g, GT_MOD.config.ini.BeginColor.b, GT_MOD.config.ini.BeginColor.a), u8"INTERFACE")
         imgui.NewLine()
        imgui.PopFont()
        imgui.PushFont(GT_MOD.UI.fonts["����"])
        imgui.NewLine()
        for i, title in ipairs(navigations.interface_elemets) do
            if GT_MOD.UI.HeaderButton(navigations.current_elemets == i, title) then
                navigations.current_elemets = i
            end
            if i ~= #navigations.interface_elemets then
                imgui.SameLine(nil, 30)
            end
        end
            imgui.SetCursorPos(imgui.ImVec2(imgui.GetCursorPosX() - 1, imgui.GetCursorPosY() + 5 ))
            if navigations.current_elemets == 1 then
                if GT_MOD.config.ini.settings.currentpreset ~= "Standart.json" then
                imgui.PushStyleColor(imgui.Col.Border, GT_MOD.config.ini.borderchild.draw and imgui.GetStyle().Colors[imgui.Col.PlotHistogram] or imgui.ImVec4(0,0,0,0))
                imgui.BeginChild("##leftmenugg", imgui.ImVec2(160, imgui.GetWindowSize().y - 118), true)
                    imgui.SetCursorPosX(imgui.GetCursorPosX() - 15)
                    GT_MOD.UI.CustomSelectable(navigations.gameinterface, navigations.activeTab.gameinterface, imgui.ImVec2(180, 30))
                imgui.EndChild()
                imgui.SameLine()
                imgui.SetCursorPosX(imgui.GetCursorPosX() - 7)
                imgui.PushStyleColor(imgui.Col.Border, GT_MOD.config.ini.borderchild.draw and imgui.GetStyle().Colors[imgui.Col.PlotHistogram] or imgui.ImVec4(0,0,0,0))
                imgui.BeginChild("##rightmenugg", imgui.ImVec2(imgui.GetWindowSize().x - 180, imgui.GetWindowSize().y - 130), true)
                imgui.PopStyleColor(2)
                
                    if navigations.activeTab.gameinterface[0] == 1 then
                    

                        if imgui.Checkbox(u8"�������� �������� ��������", checkboxes.EditPatrons) then
                            
                            InterfaceEditor.preset["Patrons"]["EditPatrons"] = checkboxes.EditPatrons[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end

                        if InterfaceEditor.preset["Patrons"]["EditPatrons"] then
                            
                            imgui.PushItemWidth(180)
                            if imgui.Combo(u8"����� ������ ��������", ivar.fontammostylevar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                                InterfaceEditor.preset["Patrons"]["fontammostyle"] = ivar.fontammostylevar[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.PopItemWidth()
                            if imgui.Checkbox(u8"�������� ������� ������� ������", checkboxes.renderammo) then
                                
                                InterfaceEditor.preset["Patrons"]["renderammo"] = checkboxes.renderammo[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.Checkbox(u8"������ ������ (����� �����)", checkboxes.singleclip) then
                                
                                InterfaceEditor.preset["Patrons"]["singleclip"] = checkboxes.singleclip[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.Checkbox(u8"������ �������", checkboxes.EternalPatrons) then
                                
                                InterfaceEditor.preset["Patrons"]["EternalPatrons"] = checkboxes.EternalPatrons[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.DragFloat(u8"##������� �������� X", sliders.posPatronsX, 0.2, -955.0, 250.0, u8"������� �������� X: %.2f") then
                                InterfaceEditor.preset["Patrons"]["posPatronsX"] = ("%.2f"):format(sliders.posPatronsX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Patrons"]["posPatronsX"] = 47.0
                                sliders.posPatronsX[0] = InterfaceEditor.preset["Patrons"]["posPatronsX"]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� �������� Y", sliders.posPatronsY, 0.2, -20.0, 420.0, u8"������� �������� Y: %.2f") then
                                InterfaceEditor.preset["Patrons"]["posPatronsY"] = ("%.2f"):format(sliders.posPatronsY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##1', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Patrons"]["posPatronsY"] = 43.0
                                InterfaceEditor.saveJson()
                                sliders.posPatronsY[0] = InterfaceEditor.preset["Patrons"]["posPatronsY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            
                            if imgui.DragFloat(u8"##������ �������� X", sliders.sizePatronsX, 0.001, 0.0, 3.0, u8"������ �������� X: %.2f") then
                                InterfaceEditor.preset["Patrons"]["sizePatronsX"] = ("%.2f"):format(sliders.sizePatronsX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##2', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Patrons"]["sizePatronsX"] = 0.3
                                InterfaceEditor.saveJson()
                                sliders.sizePatronsX[0] = InterfaceEditor.preset["Patrons"]["sizePatronsX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ �������� Y", sliders.sizePatronsY, 0.001, 0.0, 3.0, u8"������ �������� Y: %.2f") then
                                InterfaceEditor.preset["Patrons"]["sizePatronsY"] = ("%.2f"):format(sliders.sizePatronsY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##3', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Patrons"]["sizePatronsY"] = 0.7
                                InterfaceEditor.saveJson()
                                sliders.sizePatronsY[0] = InterfaceEditor.preset["Patrons"]["sizePatronsY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                        end

                    elseif navigations.activeTab.gameinterface[0] == 2 then
                    
                        if imgui.Checkbox(u8"�������� �������� ��������", checkboxes.EditHealth) then
                            InterfaceEditor.preset["Health"]["EditHealth"] = checkboxes.EditHealth[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                       
                        if  InterfaceEditor.preset["Health"]["EditHealth"] then
                            if imgui.Checkbox(u8"��������� ������� ������� ��", checkboxes.nohealthflick) then
                                InterfaceEditor.preset["Health"]["nohealthflick"] = checkboxes.nohealthflick[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            
                            if imgui.Checkbox(u8"������� 160 HP", checkboxes.oneHundredAndSixtyHPbar) then
                                InterfaceEditor.preset["Health"]["oneHundredAndSixtyHPbar"] = checkboxes.oneHundredAndSixtyHPbar[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            
                            if imgui.Checkbox(u8"���������� ������� ������� ��������", checkboxes.healthborder) then
                                InterfaceEditor.preset["Health"]["healthborder"] = checkboxes.healthborder[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            
                            if imgui.DragFloat(u8"##������� �������� X", sliders.posHealthX, 0.2, -700.0, -110.0, u8"������� �������� X: %.2f") then
                                InterfaceEditor.preset["Health"]["posHealthX"] = ("%.2f"):format(sliders.posHealthX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##4', imgui.ImVec2(90, 24)) then
                                
                                InterfaceEditor.preset["Health"]["posHealthX"] = -141.0
                                InterfaceEditor.saveJson()
                                sliders.posHealthX[0] = InterfaceEditor.preset["Health"]["posHealthX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� �������� Y", sliders.posHealthY, 0.2, 9.0, 500.0, u8"������� �������� Y: %.2f") then
                                InterfaceEditor.preset["Health"]["posHealthY"] = ("%.2f"):format(sliders.posHealthY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##5', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Health"]["posHealthY"] = 77.0
                                InterfaceEditor.saveJson()
                                sliders.posHealthY[0] = InterfaceEditor.preset["Health"]["posHealthY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ �������� X", sliders.sizeHealthX, 0.1, 0.0, 350.0, u8"������ �������� X: %.2f") then
                                InterfaceEditor.preset["Health"]["sizeHealthX"] = ("%.2f"):format(sliders.sizeHealthX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##6', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Health"]["sizeHealthX"] = 109.0
                                InterfaceEditor.saveJson()
                                sliders.sizeHealthX[0] = InterfaceEditor.preset["Health"]["sizeHealthX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ �������� Y", sliders.sizeHealthY, 0.1, 0.0, 50.0, u8"������ �������� Y: %.2f") then
                                InterfaceEditor.preset["Health"]["sizeHealthY"] = ("%.2f"):format(sliders.sizeHealthY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##7', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Health"]["sizeHealthY"]  = 9.0
                                InterfaceEditor.saveJson()
                                sliders.sizeHealthY[0] = InterfaceEditor.preset["Health"]["sizeHealthY"] 
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            
                        end

                    elseif navigations.activeTab.gameinterface[0] == 3 then

                        if imgui.Checkbox(u8"�������� ������ ����� � "..string.format("$%08d", getPlayerMoney(PLAYER_HANDLE))..u8" �� "..string.format("$%d", getPlayerMoney(PLAYER_HANDLE)), checkboxes.moneyzerofix) then
                            InterfaceEditor.preset["Money"]["moneyzerofix"] = checkboxes.moneyzerofix[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        imgui.Text(u8"�������� ��������� ���������� �����:")
                        imgui.SameLine()
                        imgui.PushItemWidth(180)
                        if imgui.Combo(u8"##�������� ��������� ���������� �����", ivar.animmoney, imgui.new['const char*'][#(GT_MOD.UI.tbmtext)](GT_MOD.UI.tbmtext), #(GT_MOD.UI.tbmtext)) then
                            InterfaceEditor.preset["Money"]["animmoney"] =  ivar.animmoney[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        GT_MOD.UI.Hint(u8"������ �������� ����������� / ��������� ����� � ����", 0.3)
                        if imgui.Combo(u8"������� ������� ������ �����", ivar.fontmoneybordervar, imgui.new['const char*'][#(GT_MOD.UI.fontmoneybordertext)](GT_MOD.UI.fontmoneybordertext), #(GT_MOD.UI.fontmoneybordertext)) then
                            InterfaceEditor.preset["Money"]["fontmoneyborder"] = ivar.fontmoneybordervar[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if imgui.Combo(u8"����� ������ �����", ivar.fontmoneystylevar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                            InterfaceEditor.preset["Money"]["fontmoneystyle"] = ivar.fontmoneystylevar[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if imgui.Combo(u8"������� �������", ivar.posdollarvar, imgui.new['const char*'][#(GT_MOD.UI.posdollartext)](GT_MOD.UI.posdollartext), #(GT_MOD.UI.posdollartext)) then
                            InterfaceEditor.preset["Money"]["posdollar"] = ivar.posdollarvar[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        imgui.PopItemWidth()

                        if imgui.Checkbox(u8"�������� �������� �����", checkboxes.EditMoney) then
                            InterfaceEditor.preset["Money"]["EditMoney"] = checkboxes.EditMoney[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end

                        if InterfaceEditor.preset["Money"]["EditMoney"] then
                            
                            if imgui.DragFloat(u8"##������� ����� X", sliders.posMoneyX, 0.2, -610.0, 1.0,  u8"������� ����� X: %.2f") then
                                InterfaceEditor.preset["Money"]["posMoneyX"] = ("%.1f"):format(sliders.posMoneyX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##8', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Money"]["posMoneyX"] = -32.0
                                InterfaceEditor.saveJson()
                                sliders.posMoneyX[0] = InterfaceEditor.preset["Money"]["posMoneyX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ����� Y", sliders.posMoneyY, 0.2, 12.0, 440.0, u8"������� ����� Y: %.2f") then
                                InterfaceEditor.preset["Money"]["posMoneyY"] = ("%.2f"):format(sliders.posMoneyY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##9', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Money"]["posMoneyY"] = 89.0
                                InterfaceEditor.saveJson()
                                sliders.posMoneyY[0] = InterfaceEditor.preset["Money"]["posMoneyY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ����� X", sliders.sizeMoneyX, 0.01, 0.0, 3.0, u8"������ ����� X: %.2f") then
                                InterfaceEditor.preset["Money"]["sizeMoneyX"] = ("%.2f"):format(sliders.sizeMoneyX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##101', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Money"]["sizeMoneyX"] = 0.55
                                InterfaceEditor.saveJson()
                                sliders.sizeMoneyX[0] = InterfaceEditor.preset["Money"]["sizeMoneyX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ����� Y", sliders.sizeMoneyY, 0.01, 0.0, 3.0, u8"������ ����� Y: %.2f") then
                                InterfaceEditor.preset["Money"]["sizeMoneyY"] = ("%.2f"):format(sliders.sizeMoneyY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##11', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Money"]["sizeMoneyY"] = 1.1
                                InterfaceEditor.saveJson()
                                sliders.sizeMoneyY[0] = InterfaceEditor.preset["Money"]["sizeMoneyY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                        end

                    elseif navigations.activeTab.gameinterface[0] == 4 then
                        if imgui.Checkbox(u8"�������� ������", checkboxes.radarfix) then
                            InterfaceEditor.preset["Radar"]["radarfix"] = checkboxes.radarfix[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if InterfaceEditor.preset["Radar"]["radarfix"] then
                            if GT_MOD.UI.CustomSlider(u8"##������������ ���������", sliders.radaralpha, 0.01, 255.00, u8"������������ ���������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["radaralpha"] = ("%.2f"):format(sliders.radaralpha[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##������������ ������ ������", sliders.radarblipA, 0.01, 255.00, u8"������������ ������ ������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["radarblipA"] = ("%.2f"):format(sliders.radarblipA[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.PushItemWidth(170)
                            if imgui.Combo(u8"��� ������", ivar.radarTypeVar, imgui.new['const char*'][#(GT_MOD.UI.radarTypeText)](GT_MOD.UI.radarTypeText), #(GT_MOD.UI.radarTypeText)) then
                                InterfaceEditor.preset["Radar"]["Type"] = ivar.radarTypeVar[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.PopItemWidth()


                            if imgui.Checkbox(u8"������� ������� ������", checkboxes.radar_color_fix) then
                                InterfaceEditor.preset["Radar"]["radar_color_fix"] = checkboxes.radar_color_fix[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.Checkbox(u8"��������� ������� ������", checkboxes.radardisc) then
                                InterfaceEditor.preset["Radar"]["radardisc"] = checkboxes.radardisc[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.Checkbox(u8"�������� ��������� ���������", checkboxes.minimapzoom) then
                                InterfaceEditor.preset["Radar"]["minimapzoom"] = checkboxes.minimapzoom[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if InterfaceEditor.preset["Radar"]["minimapzoom"] then
                                if GT_MOD.UI.CustomSlider(u8"##��������� ���������", sliders.minimapzoomvalue, 180.0, 600.0, u8"���������: %0.2f", 230) then
                                    InterfaceEditor.preset["Radar"]["minimapzoomvalue"] = ("%.2f"):format(sliders.minimapzoomvalue[0])
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                end
                            end

                            imgui.PushItemWidth(430)
                                if InterfaceEditor.preset["Radar"]["Type"] == 1 then
                                    if GT_MOD.UI.CustomSlider(u8"##������ ������", sliders.roundedRadarSize, 0.50, 2.50, u8"������ ������: %0.2f", 230) then
                                        InterfaceEditor.preset["Radar"]["roundedRadarSize"] = ("%.2f"):format(sliders.roundedRadarSize[0])
                                        InterfaceEditor.saveJson()
                                        GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    end
                                end
                                
                                
                                if InterfaceEditor.preset["Radar"]["Type"] ~= 1 then
                                    if GT_MOD.UI.CustomSlider(u8"##������ ������", sliders.radarw, 50.00, 100.00, u8"������ ������: %0.2f", 230) then
                                        InterfaceEditor.preset["Radar"]["radarWidth"] = ("%.2f"):format(sliders.radarw[0])
                                        InterfaceEditor.saveJson()
                                        GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    end
                                    imgui.SameLine()
                                    imgui.SetCursorPosX(imgui.GetCursorPos().x + 200)
                                    if imgui.Button(u8'��������##r1', imgui.ImVec2(90, 24)) then
                                        InterfaceEditor.preset["Radar"]["radarWidth"] = 76.0
                                        InterfaceEditor.saveJson()
                                        sliders.radarw[0] = InterfaceEditor.preset["Radar"]["radarWidth"]
                                        GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    end
                                    if GT_MOD.UI.CustomSlider(u8"##������ ������", sliders.radarh, 50.00, 100.00, u8"������ ������: %0.2f", 230) then
                                        InterfaceEditor.preset["Radar"]["radarHeight"] = ("%.2f"):format(sliders.radarh[0])
                                        InterfaceEditor.saveJson()
                                        GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    end
                                    imgui.SameLine()
                                    imgui.SetCursorPosX(imgui.GetCursorPos().x + 200)
                                    if imgui.Button(u8'��������##r2', imgui.ImVec2(90, 24)) then
                                        InterfaceEditor.preset["Radar"]["radarHeight"] = 94.0
                                        InterfaceEditor.saveJson()
                                        sliders.radarh[0] = InterfaceEditor.preset["Radar"]["radarHeight"]
                                        GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    end
                                    
                                end
                                if imgui.DragFloat(u8"##��������� ������ �� X", sliders.radarposx, 0.2, 0.00, 600.00, u8"��������� ������ �� X: %0.2f") then
                                    InterfaceEditor.preset["Radar"]["radarPosX"] = ("%.2f"):format(sliders.radarposx[0])
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                end
                                imgui.SameLine()
                                if imgui.Button(u8'��������##r3', imgui.ImVec2(90, 24)) then
                                    InterfaceEditor.preset["Radar"]["radarPosX"] = 40.0
                                    InterfaceEditor.saveJson()
                                    sliders.radarposx[0] = InterfaceEditor.preset["Radar"]["radarPosX"]
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                end
                                if imgui.DragFloat(u8"##��������� ������ �� Y", sliders.radarposy, 0.2, 80.00, 555.00, u8"��������� ������ �� Y: %0.2f") then
                                    InterfaceEditor.preset["Radar"]["radarPosY"] = ("%.2f"):format(sliders.radarposy[0])
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                end
                                imgui.SameLine()
                                if imgui.Button(u8'��������##r4', imgui.ImVec2(90, 24)) then
                                    InterfaceEditor.preset["Radar"]["radarPosY"] = 104.0
                                    InterfaceEditor.saveJson()
                                    sliders.radarposy[0] = InterfaceEditor.preset["Radar"]["radarPosY"]
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                end
                            imgui.PopItemWidth()
                        end
                        
                        if imgui.Checkbox(u8"��������� ������ ������", checkboxes.radrarnorth) then
                            InterfaceEditor.preset["Radar"]["radrarnorth"] = checkboxes.radrarnorth[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if imgui.Checkbox(u8"����������� ������ �� ������", checkboxes.smalliconsradar) then
                            InterfaceEditor.preset["Radar"]["smalliconsradar"] = checkboxes.smalliconsradar[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                
                        if InterfaceEditor.preset["Radar"]["smalliconsradar"] then
                            imgui.PushItemWidth(425)
                            if GT_MOD.UI.CustomSlider(u8"##���������� ������", sliders.quadro_icon_size, 0.5, 3.0, u8"���������� ������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["quadro_icon_size"] = sliders.quadro_icon_size[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##���������� ������ �������", sliders.quadro_icon_border, 0.5, 3.0, u8"���������� ������ �������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["quadro_icon_border"] = sliders.quadro_icon_border[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##����������� ������ �����", sliders.trianglev_icon_size, 0.5, 3.0, u8"�����. ������ �����: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["trianglev_icon_size"] = sliders.trianglev_icon_size[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##����������� ������ ����� �������", sliders.trianglev_icon_border, 0.5, 3.0, u8"�����. ������ ����� �������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["trianglev_icon_border"] = sliders.trianglev_icon_border[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##����������� ������ ����", sliders.trianglen_icon_size, 0.5, 3.0, u8"�����. ������ ����: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["trianglen_icon_size"] = sliders.trianglen_icon_size[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##����������� ������ ���� �������", sliders.trianglen_icon_border, 0.5, 3.0, u8"�����. ������ ���� �������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["trianglen_icon_border"] = sliders.trianglen_icon_border[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##������ ������", sliders.player_icon_size, 0.5, 10.0, u8"������ ������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["player_icon_size"] = sliders.player_icon_size[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##������ ������ �� ����� � ����", sliders.arrowmap_size, 1.0, 30.0, u8"������ ������ �� ����� � ����: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["arrowmap_size"] = sliders.arrowmap_size[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if GT_MOD.UI.CustomSlider(u8"##�������� ������", sliders.osnov_icon, 0.5, 10.0, u8"�������� ������: %0.2f", 230) then
                                InterfaceEditor.preset["Radar"]["osnov_icon"] = sliders.osnov_icon[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.PopItemWidth()
                        end
                    elseif navigations.activeTab.gameinterface[0] == 5 then
                        if imgui.Checkbox(u8"��������� ������ arrow � ����", checkboxes.arrowicon_menu) then
                            InterfaceEditor.preset["MenuPause"]["arrowicon_menu"] = checkboxes.arrowicon_menu[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if imgui.Checkbox(u8"�������� ������ ����������� � ����", checkboxes.fullmenuimage) then
                            InterfaceEditor.preset["MenuPause"]["fullmenuimage"] = checkboxes.fullmenuimage[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("MenuImage")
                        end
                        imgui.PushItemWidth(60)
                        if imgui.InputFloat(u8"������", buffers.fullmenuwidth, 0, 10000, "%0.1f") then
                            if buffers.fullmenuwidth[0] < 0.0 then
                                buffers.fullmenuwidth[0] = 0.0
                            end
                            if buffers.fullmenuwidth[0] > 10000.0 then
                                buffers.fullmenuwidth[0] = 10000.0
                            end
                            InterfaceEditor.preset["MenuPause"]["fullmenuwidth"] = buffers.fullmenuwidth[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("MenuImage")
                        end
                        imgui.SameLine()
                        if imgui.InputFloat(u8"������", buffers.fullmenuheight, 0, 10000, "%0.1f") then
                            if buffers.fullmenuheight[0] < 0.0 then
                                buffers.fullmenuheight[0] = 0.0
                            end
                            if buffers.fullmenuheight[0] > 10000.0 then
                                buffers.fullmenuheight[0] = 10000.0
                            end
                            InterfaceEditor.preset["MenuPause"]["fullmenuheight"] = buffers.fullmenuheight[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("MenuImage")
                        end
                        imgui.PopItemWidth()
                        if imgui.Checkbox(u8"�������������� ��������������� �����", checkboxes.mapzoom) then
                            InterfaceEditor.preset["MenuPause"]["mapzoom"] = checkboxes.mapzoom[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        GT_MOD.UI.Hint(u8"�������� / ��������� �������������� ��������� ����� � ���� ESC", 0.3)
                        imgui.Text(u8"������� ��������� ����� [�� 300.00 �� 1000.00]")
                        if imgui.DragFloat(u8"##mapzoomvalue", sliders.mapzoomvalue, 0.2, 300.00, 1000.00, "%.2f") then
                            if InterfaceEditor.preset["MenuPause"]["mapzoom"] then
                                InterfaceEditor.preset["MenuPause"]["mapzoomvalue"] = ("%.2f"):format(sliders.mapzoomvalue[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.memory_setfloat(5719357, InterfaceEditor.preset["MenuPause"]["mapzoomvalue"], true)
                            else
                                GT_MOD.functions.memory_setfloat(5719357, 1000.00, true)
                            end
                        end
                        if imgui.Checkbox(u8"��������� ��������� � ���� (ESC)", checkboxes.helptext) then
                            InterfaceEditor.preset["MenuPause"]["helptext"] = checkboxes.helptext[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("HelpText")
                        end
                        if imgui.Checkbox(u8"��������� ��������� � ���� (ESC)", checkboxes.beginmenu) then
                            InterfaceEditor.preset["MenuPause"]["beginmenu"] = checkboxes.beginmenu[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("BeginMenu")
                        end

                        if GT_MOD.UI.CustomSlider(u8"##speedinputsmap", sliders.speedinputsmap, 7.0, 50.0, u8"�������� ����������� � �����: %.2f", 230) then
                            InterfaceEditor.preset["MenuPause"]["speedinputsmap"] = ("%.2f"):format(sliders.speedinputsmap[0])
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end

                        imgui.PushItemWidth(180)
                        if imgui.Combo(u8"����� ��������� ������ ����", ivar.fontmenubasestylevar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                            InterfaceEditor.preset["MenuPause"]["fontmenubasestyle"] = ivar.fontmenubasestylevar[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if imgui.Combo(u8"����� ������ ���������� ����", ivar.fontmenuheaderstylevar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                            InterfaceEditor.preset["MenuPause"]["fontmenuheaderstyle"] = ivar.fontmenuheaderstylevar[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if imgui.Combo(u8"����� ������ ON - OFF (��������) ����", ivar.fontmenutumblerstylevar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                            InterfaceEditor.preset["MenuPause"]["fontmenutumblerstyle"] = ivar.fontmenutumblerstylevar[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        imgui.PopItemWidth()
                        imgui.NewLine()
                        if imgui.Checkbox(u8"�������� ������ ����", checkboxes.gxtEntryEditor) then
                            InterfaceEditor.preset["MenuPause"]["gxtEntryEditor"] = checkboxes.gxtEntryEditor[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if InterfaceEditor.preset["MenuPause"]["gxtEntryEditor"] then

                            --GT_MOD.UI.MainBox("����� ������", imgui.ImVec2(500,290), 0)
                                imgui.PushFont(GT_MOD.UI.fonts[35])


                                imgui.PushStyleColor(imgui.Col.Text, col1)
                                imgui.Text(u8"����� ������")
                                imgui.PopStyleColor()
                                imgui.PopFont()
                                imgui.Spacing()
                                imgui.PushStyleColor(imgui.Col.Text, col2)

                                imgui.PushItemWidth(130)

                                if imgui.InputText(u8"##beginText", buffers.beginText, sizeof(buffers.beginText)) then
                                    InterfaceEditor.preset["MenuPause"]["beginText"] = u8:decode(ffi.string(buffers.beginText))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"��������� ����")
                                imgui.SameLine()
                                if imgui.Checkbox(u8"������������ ��� ���", checkboxes.useMynameInBeginMenu) then
                                    InterfaceEditor.preset["MenuPause"]["useMynameInBeginMenu"] = checkboxes.useMynameInBeginMenu[0]
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                end

                                if imgui.InputText(u8"##resume", buffers.resume, sizeof(buffers.resume)) then
                                    InterfaceEditor.preset["MenuPause"]["resume"] = u8:decode(ffi.string(buffers.resume))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"����������")

                                if imgui.InputText(u8"##start_new_game", buffers.start_new_game, sizeof(buffers.start_new_game)) then
                                    InterfaceEditor.preset["MenuPause"]["start_new_game"] = u8:decode(ffi.string(buffers.start_new_game))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"������ ����� ����")

                                if imgui.InputText(u8"##map", buffers.map, sizeof(buffers.map)) then
                                    InterfaceEditor.preset["MenuPause"]["map"] = u8:decode(ffi.string(buffers.map))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"�����")

                                if imgui.InputText(u8"##stats", buffers.stats, sizeof(buffers.stats)) then
                                    InterfaceEditor.preset["MenuPause"]["stats"] = u8:decode(ffi.string(buffers.stats))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"����������")

                                if imgui.InputText(u8"##brief", buffers.brief, sizeof(buffers.brief)) then
                                    InterfaceEditor.preset["MenuPause"]["brief"] = u8:decode(ffi.string(buffers.brief))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"������")

                                if imgui.InputText(u8"##settings", buffers.settings, sizeof(buffers.settings)) then
                                    InterfaceEditor.preset["MenuPause"]["settings"] = u8:decode(ffi.string(buffers.settings))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"���������")

                                if imgui.InputText(u8"##quitGame", buffers.quitGame, sizeof(buffers.quitGame)) then
                                    InterfaceEditor.preset["MenuPause"]["quitGame"] = u8:decode(ffi.string(buffers.quitGame))
                                    InterfaceEditor.saveJson()
                                    GT_MOD.functions.gotofunc("InterfaceElementEditor")
                                    
                                end
                                imgui.SameLine()
                                imgui.Text(u8"����� �� ����")



                                imgui.PopItemWidth()
                                
                                imgui.PopStyleColor()
                            --imgui.EndChild()

                        end

                        
                    elseif navigations.activeTab.gameinterface[0] == 6 then
                        imgui.Text(u8"������ �������:")
                        imgui.PushItemWidth(60)
                        if imgui.InputFloat(u8"X", buffers.crosshairX, 0.0, 255.0, "%0.2f") then
                            if buffers.crosshairX[0] > 255.0 then
                                buffers.crosshairX[0] = 255.0
                            elseif buffers.crosshairX[0] < 0.0 then
                                buffers.crosshairX[0] = 0.0
                            end
                            InterfaceEditor.preset["Crosshair"]["crosshairSizeX"] = buffers.crosshairX[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("EditCrosshair")
                        end
                        imgui.PopItemWidth()
                        imgui.PushItemWidth(60)
                        if imgui.InputFloat(u8"Y", buffers.crosshairY, 0.0, 255.0, "%0.2f") then
                            if buffers.crosshairY[0] > 255.0 then
                                buffers.crosshairY[0] = 255.0
                            elseif buffers.crosshairY[0] < 0.0 then
                                buffers.crosshairY[0] = 0.0
                            end
                            InterfaceEditor.preset["Crosshair"]["crosshairSizeY"] = buffers.crosshairY[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("EditCrosshair")
                        end
                        if imgui.Button(u8"��������", imgui.ImVec2(90, 24)) then
                            buffers.crosshairX[0] = 64.0
                            buffers.crosshairY[0] = 64.0
                            InterfaceEditor.preset["Crosshair"]["crosshairSizeX"] = buffers.crosshairX[0]
                            InterfaceEditor.preset["Crosshair"]["crosshairSizeY"] = buffers.crosshairY[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("EditCrosshair")
                        end
                        if imgui.Checkbox(u8"��������� ��������� ������� ������� ��� ��������", checkboxes.nocrosshaireditsize) then
                            InterfaceEditor.preset["Crosshair"]["nocrosshaireditsize"] = checkboxes.nocrosshaireditsize[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("EditCrosshair")
                        end
                         GT_MOD.UI.Hint(u8"�� ������ �� ������� ����, ����������� ������ ����� ������� �������.")
                        imgui.PopItemWidth()
                    elseif navigations.activeTab.gameinterface[0] == 7 then
                        if imgui.Checkbox(u8"�������� �������� ���������", checkboxes.EditBreath) then
                            InterfaceEditor.preset["Breath"]["EditBreath"] = checkboxes.EditBreath[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end

                        if InterfaceEditor.preset["Breath"]["EditBreath"] then
                            if imgui.Checkbox(u8"�������� ������ ��������", checkboxes.eternalBreath) then
                                InterfaceEditor.preset["Breath"]["eternalBreath"] = checkboxes.eternalBreath[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.Checkbox(u8"���������� ������� ������� ���������", checkboxes.breathborder) then
                                InterfaceEditor.preset["Breath"]["breathborder"] = checkboxes.breathborder[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ��������� X", sliders.posBreathX, 0.2, -660.0, -40.0, u8"������� ��������� X: %.2f") then
                                InterfaceEditor.preset["Breath"]["posBreathX"] = ("%.2f"):format(sliders.posBreathX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##9', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Breath"]["posBreathX"] = -94.0
                                InterfaceEditor.saveJson()
                                sliders.posBreathX[0] = InterfaceEditor.preset["Breath"]["posBreathX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ��������� Y", sliders.posBreathY, 0.2, 0.0, 445.0, u8"������� ��������� Y: %.2f") then
                                InterfaceEditor.preset["Breath"]["posBreathY"] = ("%.2f"):format(sliders.posBreathY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##10', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Breath"]["posBreathY"] = 62.0
                                InterfaceEditor.saveJson()
                                sliders.posBreathY[0] = InterfaceEditor.preset["Breath"]["posBreathY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ��������� X", sliders.sizeBreathX, 0.1, 0.01, 150.0, u8"������ ��������� X: %.2f") then
                                InterfaceEditor.preset["Breath"]["sizeBreathX"] = ("%.2f"):format(sliders.sizeBreathX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##11', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Breath"]["sizeBreathX"] = 62.0
                                InterfaceEditor.saveJson()
                                sliders.sizeBreathX[0] = InterfaceEditor.preset["Breath"]["sizeBreathX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                        
                            if imgui.DragFloat(u8"##������ ��������� Y", sliders.sizeBreathY, 0.1, 0.01, 50.0, u8"������ ��������� Y: %.2f") then
                                InterfaceEditor.preset["Breath"]["sizeBreathY"] = ("%.2f"):format(sliders.sizeBreathY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##12', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Breath"]["sizeBreathY"] = 9.0
                                InterfaceEditor.saveJson()
                                sliders.sizeBreathY[0] = InterfaceEditor.preset["Breath"]["sizeBreathY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            

                        end
                    
                    elseif navigations.activeTab.gameinterface[0] == 8 then
                        if imgui.Checkbox(u8"�������� �������� �����", checkboxes.EditArmor) then
                            InterfaceEditor.preset["Armor"]["EditArmor"] = checkboxes.EditArmor[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end

                        if InterfaceEditor.preset["Armor"]["EditArmor"] then
                            if imgui.Checkbox(u8"�������� ������ �����", checkboxes.eternalArmor) then
                                InterfaceEditor.preset["Armor"]["eternalArmor"] = checkboxes.eternalArmor[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.Checkbox(u8"���������� ������� ������� �����", checkboxes.armorborder) then
                                InterfaceEditor.preset["Armor"]["armorborder"] = checkboxes.armorborder[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ����� X", sliders.posArmorX, 0.2, -660.0, -1.0, u8"������� ����� X: %.2f") then
                                InterfaceEditor.preset["Armor"]["posArmorX"] = ("%.2f"):format(sliders.posArmorX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##13', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Armor"]["posArmorX"] = -94.0
                                InterfaceEditor.saveJson()
                                sliders.posArmorX[0] = InterfaceEditor.preset["Armor"]["posArmorX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ����� Y", sliders.posArmorY, 0.2, 0.0, 445.0, u8"������� ����� Y: %.2f") then
                                InterfaceEditor.preset["Armor"]["posArmorY"] = ("%.2f"):format(sliders.posArmorY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##14', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Armor"]["posArmorY"] = 48.0
                                InterfaceEditor.saveJson()
                                sliders.posArmorY[0] = InterfaceEditor.preset["Armor"]["posArmorY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ����� X", sliders.sizeArmorX, 0.1, 0.01, 150.0, u8"������ ����� X: %.2f") then
                                InterfaceEditor.preset["Armor"]["sizeArmorX"] = ("%.2f"):format(sliders.sizeArmorX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
        
                            if imgui.Button(u8'��������##15', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Armor"]["sizeArmorX"] = 62.0
                                InterfaceEditor.saveJson()
                                sliders.sizeArmorX[0] = InterfaceEditor.preset["Armor"]["sizeArmorX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                        
                            if imgui.DragFloat(u8"##������ ����� Y", sliders.sizeArmorY, 0.1, 0.01, 50.0, u8"������ ����� Y: %.2f") then
                                InterfaceEditor.preset["Armor"]["sizeArmorY"] = ("%.2f"):format(sliders.sizeArmorY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##16', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Armor"]["sizeArmorY"] = 9.0
                                InterfaceEditor.saveJson()
                                sliders.sizeArmorY[0] = InterfaceEditor.preset["Armor"]["sizeArmorY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            
                        end

                    elseif navigations.activeTab.gameinterface[0] == 9 then
                        if imgui.Checkbox(u8"�������� �������� ������", checkboxes.EditWeapon) then
                            InterfaceEditor.preset["Weapon"]["EditWeapon"] = checkboxes.EditWeapon[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if InterfaceEditor.preset["Weapon"]["EditWeapon"] then
                            if imgui.DragFloat(u8"##������� ������ X", sliders.posWeaponX, 0.2, -530.0, 70.0, u8"������� ������ X: %.2f") then
                                InterfaceEditor.preset["Weapon"]["posWeaponX"] = ("%.2f"):format(sliders.posWeaponX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##17', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Weapon"]["posWeaponX"] = -32.0
                                InterfaceEditor.saveJson()
                                sliders.posWeaponX[0] = InterfaceEditor.preset["Weapon"]["posWeaponX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ������ Y", sliders.posWeaponY, 0.2, 0.0, 400.0, u8"������� ������ Y: %.2f") then
                                InterfaceEditor.preset["Weapon"]["posWeaponY"] = ("%.2f"):format(sliders.posWeaponY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##18', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Weapon"]["posWeaponY"] = 20.0
                                InterfaceEditor.saveJson()
                                sliders.posWeaponY[0] = InterfaceEditor.preset["Weapon"]["posWeaponY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ������ X", sliders.sizeWeaponX, 0.1, 0.01, 400.0, u8"������ ������ X: %.2f") then
                                InterfaceEditor.preset["Weapon"]["sizeWeaponX"] = ("%.2f"):format(sliders.sizeWeaponX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##19', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Weapon"]["sizeWeaponX"] = 47.0
                                InterfaceEditor.saveJson()
                                sliders.sizeWeaponX[0] = InterfaceEditor.preset["Weapon"]["sizeWeaponX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ������ Y", sliders.sizeWeaponY, 0.1, 0.01, 400.0, u8"������ ������ Y: %.2f") then
                                InterfaceEditor.preset["Weapon"]["sizeWeaponY"] = ("%.2f"):format(sliders.sizeWeaponY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##20', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Weapon"]["sizeWeaponY"] = 58.0
                                InterfaceEditor.saveJson()
                                sliders.sizeWeaponY[0] = InterfaceEditor.preset["Weapon"]["sizeWeaponY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                        end
                    elseif navigations.activeTab.gameinterface[0] == 10 then
                        if imgui.Checkbox(u8"�������� �������� �������", checkboxes.EditWanted) then
                            InterfaceEditor.preset["Wanted"]["EditWanted"] = checkboxes.EditWanted[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if InterfaceEditor.preset["Wanted"]["EditWanted"] then
                            if imgui.Checkbox(u8"�������� ������ ������", checkboxes.eternalwanted) then
                                InterfaceEditor.preset["Wanted"]["eternalwanted"] = checkboxes.eternalwanted[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.Checkbox(u8"�� ���������� ������ ������", checkboxes.emptyStars) then
                                InterfaceEditor.preset["Wanted"]["emptyStars"] = checkboxes.emptyStars[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.DragFloat(u8"##��������", sliders.spaceWanted, 0.1, -50.0, 50.0, u8"��������: %.2f") then
                                InterfaceEditor.preset["Wanted"]["spaceWanted"] = ("%.2f"):format(sliders.spaceWanted[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##��������', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Wanted"]["spaceWanted"] = 18.0
                                InterfaceEditor.saveJson()
                                sliders.spaceWanted[0] = InterfaceEditor.preset["Wanted"]["spaceWanted"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ������� X", sliders.posWantedX, 0.2, -530.0, 70.0, u8"������� ������� X: %.2f") then
                                InterfaceEditor.preset["Wanted"]["posWantedX"] = ("%.2f"):format(sliders.posWantedX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##21', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Wanted"]["posWantedX"]  = -29.0
                                InterfaceEditor.saveJson()
                                sliders.posWantedX[0] = InterfaceEditor.preset["Wanted"]["posWantedX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ������� Y", sliders.posWantedY, 0.2, 15.0, 440.0, u8"������� ������� Y: %.2f") then
                                InterfaceEditor.preset["Wanted"]["posWantedY"] = ("%.2f"):format(sliders.posWantedY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##22', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Wanted"]["posWantedY"] = 114.0
                                InterfaceEditor.saveJson()
                                sliders.posWantedY[0] = InterfaceEditor.preset["Wanted"]["posWantedY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ������� X", sliders.sizeWantedX, 0.01, 0.01, 1.0, u8"������ ������� X: %.2f") then
                                InterfaceEditor.preset["Wanted"]["sizeWantedX"] = ("%.2f"):format(sliders.sizeWantedX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##23', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Wanted"]["sizeWantedX"] = 0.60
                                InterfaceEditor.saveJson()
                                sliders.sizeWantedX[0] = InterfaceEditor.preset["Wanted"]["sizeWantedX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ������� Y", sliders.sizeWantedY, 0.01, 0.01, 1.5, u8"������ ������� Y: %.2f") then
                                InterfaceEditor.preset["Wanted"]["sizeWantedY"] = ("%.2f"):format(sliders.sizeWantedY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##24', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Wanted"]["sizeWantedY"] = 1.21
                                InterfaceEditor.saveJson()
                                sliders.sizeWantedY[0] = InterfaceEditor.preset["Wanted"]["sizeWantedY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                        end
                    elseif navigations.activeTab.gameinterface[0] == 11 then
                        if imgui.Checkbox(u8"�������� �������� �����", checkboxes.EditClock) then
                            InterfaceEditor.preset["Clock"]["EditClock"] = checkboxes.EditClock[0]
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("InterfaceElementEditor")
                        end
                        if InterfaceEditor.preset["Clock"]["EditClock"] then
                            if imgui.Checkbox(u8"�������� ����������� ����� �� ��������� ����", checkboxes.DrawClock) then
                                InterfaceEditor.preset["Clock"]["DrawClock"] = checkboxes.DrawClock[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.Checkbox(u8"���������� ����� �� �� �����", checkboxes.PcClock) then
                                InterfaceEditor.preset["Clock"]["PcClock"] = checkboxes.PcClock[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if InterfaceEditor.preset["Clock"]["PcClock"] then
                                if imgui.Checkbox(u8"���������� ������� �� �����", checkboxes.DrawSec) then
                                    InterfaceEditor.preset["Clock"]["DrawSec"] = checkboxes.DrawSec[0]
                                    InterfaceEditor.saveJson()
                                end
                            end
                            imgui.PushItemWidth(180)
                            if imgui.Combo(u8"����� ������ �����", ivar.fontstyleclockvar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                                InterfaceEditor.preset["Clock"]["fontstyleclock"] = ivar.fontstyleclockvar[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            if imgui.Combo(u8"������� ������� ������ �����", ivar.fontoutlineclockvar, imgui.new['const char*'][#(GT_MOD.UI.fontmoneybordertext)](GT_MOD.UI.fontmoneybordertext), #(GT_MOD.UI.fontmoneybordertext)) then
                                InterfaceEditor.preset["Clock"]["fontoutlineclock"] = ivar.fontoutlineclockvar[0]
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.PopItemWidth()
                            if imgui.DragFloat(u8"##������� ����� X", sliders.posClockX, 0.2, -580.0, -0.0, u8"������� ����� X: %.2f") then
                                InterfaceEditor.preset["Clock"]["posClockX"] = ("%.2f"):format(sliders.posClockX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##25', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Clock"]["posClockX"] = -32.0
                                InterfaceEditor.saveJson()
                                sliders.posClockX[0] = InterfaceEditor.preset["Clock"]["posClockX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������� ����� Y", sliders.posClockY, 0.2, 0.0, 427.0, u8"������� ����� Y: %.2f") then
                                InterfaceEditor.preset["Clock"]["posClockY"] = ("%.2f"):format(sliders.posClockY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##26', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Clock"]["posClockY"] = 22.0
                                InterfaceEditor.saveJson()
                                sliders.posClockY[0] = InterfaceEditor.preset["Clock"]["posClockY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ����� X", sliders.sizeClockX, 0.01, 0.0, 3.0, u8"������ ����� X: %.2f") then
                                InterfaceEditor.preset["Clock"]["sizeClockX"] = ("%.2f"):format(sliders.sizeClockX[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##27', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Clock"]["sizeClockX"] = 0.55
                                InterfaceEditor.saveJson()
                                sliders.sizeClockX[0] = InterfaceEditor.preset["Clock"]["sizeClockX"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                            if imgui.DragFloat(u8"##������ ����� Y", sliders.sizeClockY, 0.01, 0.0, 3.0, u8"������ ����� Y: %.2f") then
                                InterfaceEditor.preset["Clock"]["sizeClockY"] = ("%.2f"):format(sliders.sizeClockY[0])
                                InterfaceEditor.saveJson()
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end
                            imgui.SameLine()
                            if imgui.Button(u8'��������##28', imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["Clock"]["sizeClockY"] = 1.1
                                InterfaceEditor.saveJson()
                                sliders.sizeClockY[0] = InterfaceEditor.preset["Clock"]["sizeClockY"]
                                GT_MOD.functions.gotofunc("InterfaceElementEditor")
                            end

                        end
                    end
                    imgui.EndChild()
                else
                    imgui.NewLine()
                    imgui.Text(u8"�������������� ��������� ����������.")
                    imgui.Text(u8"� ��� ������ ������ Standart")

                    local DL = imgui.GetWindowDrawList()
                    local ToU32 = imgui.ColorConvertFloat4ToU32

                    -- �������� ������� ����
                    local p = imgui.GetCursorScreenPos()

                    -- ��������� ����� �����
                    local startX, startY = p.x + 240, p.y - 12

                    -- ����� �������������� �����
                    local horizontalLength = 285

                    -- ����� ������������ �����
                    local verticalLength = 50

                    -- ���������� ����� �������������� �����
                    local midX, midY = startX + horizontalLength, startY

                    -- ���������� ����� ������������ �����
                    local endX, endY = midX, midY - verticalLength

                    -- ���� ����� � �������
                    local color = ToU32(imgui.GetStyle().Colors[imgui.Col.Text])

                    -- ����� � ������ �������
                    local arrowLength = 10
                    local arrowWidth = 10  -- �������� ������ ������� ��� ������������������

                    -- ��������� ����������� ������������ �����
                    local dirX, dirY = 0, -1  -- ����������� ������������ ����� (�����)

                    -- ��������� ������� �������
                    local arrowTipX, arrowTipY = endX, endY

                    -- ��������� ��������� �������
                    local baseX, baseY = endX - dirX * arrowLength, endY - dirY * arrowLength

                    -- ������������� ��� ������ �������
                    local perpX, perpY = -dirY * arrowWidth / 2, dirX * arrowWidth / 2

                    -- ��������� ���������� ��������� ������� (����� � ������ �������)
                    local arrowLeftX, arrowLeftY = baseX + perpX+1, baseY + perpY
                    local arrowRightX, arrowRightY = baseX - perpX, baseY - perpY

                    -- ������ �������������� �����
                    DL:AddLine(imgui.ImVec2(startX, startY), imgui.ImVec2(midX, midY), color, 2.0)

                    -- ������ ������������ �����
                    DL:AddLine(imgui.ImVec2(midX, midY), imgui.ImVec2(endX, endY), color, 2.0)

                    -- ������ �������
                    DL:AddTriangleFilled(
                        imgui.ImVec2(arrowTipX, arrowTipY),    -- ������� �������
                        imgui.ImVec2(arrowLeftX, arrowLeftY), -- ����� ������� ���������
                        imgui.ImVec2(arrowRightX, arrowRightY), -- ������ ������� ���������
                        color
                    )

                end

            elseif navigations.current_elemets == 2 then
                imgui.PushStyleColor(imgui.Col.Border, GT_MOD.config.ini.borderchild.draw and imgui.GetStyle().Colors[imgui.Col.PlotHistogram] or imgui.ImVec4(0,0,0,0))
                imgui.BeginChild("##rightmenugg", imgui.ImVec2(imgui.GetWindowSize().x - 45, imgui.GetWindowSize().y - 118), true)
                imgui.PopStyleColor()
                if imgui.Checkbox(u8"�������� �������", checkboxes.recolorer) then
                    InterfaceEditor.preset["Recolorer"]["Recolorer"] = checkboxes.recolorer[0]
                    InterfaceEditor.saveJson()
                    GT_MOD.functions.gotofunc("Recolorer")
                end
                if InterfaceEditor.preset["Recolorer"]["Recolorer"] then
                    if imgui.ColorEdit3(u8"##������", icolors.RECOLORER_HEALTH, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_HEALTH[0])), tonumber(("%.3f"):format(icolors.RECOLORER_HEALTH[1])), tonumber(("%.3f"):format(icolors.RECOLORER_HEALTH[2]))
                        InterfaceEditor.preset["Recolorer"]["Health"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� ������� ��������")
                    if imgui.ColorEdit3(u8"##���� ������� �����", icolors.RECOLORER_ARMOUR, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_ARMOUR[0])), tonumber(("%.3f"):format(icolors.RECOLORER_ARMOUR[1])), tonumber(("%.3f"):format(icolors.RECOLORER_ARMOUR[2]))
                        InterfaceEditor.preset["Recolorer"]["Armor"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� ������� �����") 
                    if imgui.ColorEdit3(u8"##���� �����", icolors.RECOLORER_MONEY, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_MONEY[0])), tonumber(("%.3f"):format(icolors.RECOLORER_MONEY[1])), tonumber(("%.3f"):format(icolors.RECOLORER_MONEY[2]))
                        InterfaceEditor.preset["Recolorer"]["Money"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� �����") 
                    if imgui.ColorEdit3(u8"##���� �����", icolors.RECOLORER_STARS, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_STARS[0])), tonumber(("%.3f"):format(icolors.RECOLORER_STARS[1])), tonumber(("%.3f"):format(icolors.RECOLORER_STARS[2]))
                        InterfaceEditor.preset["Recolorer"]["Stars"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� �����") 
                    if imgui.ColorEdit3(u8"##���� ��������", icolors.RECOLORER_PATRONS, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_PATRONS[0])), tonumber(("%.3f"):format(icolors.RECOLORER_PATRONS[1])), tonumber(("%.3f"):format(icolors.RECOLORER_PATRONS[2]))
                        InterfaceEditor.preset["Recolorer"]["Patrons"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� ���-�� ��������")
                    if imgui.ColorEdit3(u8"##���� �� �������", icolors.RECOLORER_PLAYERHEALTH, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERHEALTH[0])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERHEALTH[1])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERHEALTH[2]))
                        InterfaceEditor.preset["Recolorer"]["PlayerHealth"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� ������� �� �������")
                    if imgui.ColorEdit3(u8"##���� �� ������� ���", icolors.RECOLORER_PLAYERHEALTH2, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERHEALTH2[0])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERHEALTH2[1])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERHEALTH2[2]))
                        InterfaceEditor.preset["Recolorer"]["PlayerHealth2"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� ������� �� ������� ���")
                    if imgui.ColorEdit3(u8"##���� ����� �������", icolors.RECOLORER_PLAYERARMOR, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERARMOR[0])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERARMOR[1])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERARMOR[2]))
                        InterfaceEditor.preset["Recolorer"]["PlayerArmor"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� ������� ����� �������")
                    if imgui.ColorEdit3(u8"##���� ����� ������� ���", icolors.RECOLORER_PLAYERARMOR2, imgui.ColorEditFlags.AlphaBar + imgui.ColorEditFlags.NoInputs) then
                        local r, g, b = tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERARMOR2[0])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERARMOR2[1])), tonumber(("%.3f"):format(icolors.RECOLORER_PLAYERARMOR2[2]))
                        InterfaceEditor.preset["Recolorer"]["PlayerArmor2"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("Recolorer")
                    end
                    imgui.SameLine() imgui.Text(u8"���� ������� ����� ������� ���")
                end
                imgui.EndChild()
            elseif navigations.current_elemets == 3 then
                imgui.PushStyleColor(imgui.Col.Border, GT_MOD.config.ini.borderchild.draw and imgui.GetStyle().Colors[imgui.Col.PlotHistogram] or imgui.ImVec4(0,0,0,0))
                imgui.BeginChild("##rightmenugg", imgui.ImVec2(imgui.GetWindowSize().x - 20, imgui.GetWindowSize().y - 118), true)
                imgui.PopStyleColor()

                        imgui.PushFont(GT_MOD.UI.fonts[35])
                        imgui.PushStyleColor(imgui.Col.Text, col1)
                        imgui.Text(u8"��������� ��")
                        imgui.PopStyleColor()
                        imgui.PopFont()
                        imgui.Spacing()
                        imgui.PushStyleColor(imgui.Col.Text, col2)
                        if imgui.Checkbox(u8"�������� ���������", checkboxes.hphud) then
                            InterfaceEditor.preset["HPHud"]["Status"] = checkboxes.hphud[0]
                            InterfaceEditor.saveJson()
                        end
                        if InterfaceEditor.preset["HPHud"]["Status"] then
                            if imgui.Checkbox(u8"�������� ������� HP", checkboxes.hpt) then
                                InterfaceEditor.preset["HPHud"]["hptext"] = checkboxes.hpt[0]
                                InterfaceEditor.saveJson()
                            end
                            imgui.PushItemWidth(330)
                            if imgui.DragFloat(u8"##��������� ����������: X", sliders.hpposX, 0.2, 0.0, 625.0, u8"��������� X: %.2f") then
                                InterfaceEditor.preset["HPHud"]["posX"] = ("%.2f"):format(sliders.hpposX[0])
                                InterfaceEditor.saveJson()
                            end imgui.SameLine()
                            if imgui.Button(u8"��������##hpposx", imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["HPHud"]["posX"] = 609.70
                                InterfaceEditor.saveJson()
                                sliders.hpposX[0] = 609.70
                            end
                            if imgui.DragFloat(u8"##��������� ����������: Y", sliders.hpposY, 0.2, 0.0, 440.0, u8"��������� Y: %.2f") then
                                InterfaceEditor.preset["HPHud"]["posY"]  = ("%.2f"):format(sliders.hpposY[0])
                                InterfaceEditor.saveJson()
                            end imgui.SameLine()
                            if imgui.Button(u8"��������##hpposy", imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["HPHud"]["posY"] = 66.0
                                InterfaceEditor.saveJson()
                                sliders.hpposY[0] = 66.0
                            end
                            if imgui.DragFloat(u8"##������ ���������� ��: X", sliders.hpSizeX, 0.01, 0.0, 440.0, u8"������ X: %.2f") then
                                InterfaceEditor.preset["HPHud"]["sizeX"] = ("%.2f"):format(sliders.hpSizeX[0])
                                InterfaceEditor.saveJson()
                            end imgui.SameLine()
                            if imgui.Button(u8"��������##hpSizeX", imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["HPHud"]["sizeX"] = 0.25
                                InterfaceEditor.saveJson()
                                sliders.hpSizeX[0] = 0.25
                            end
                            if imgui.DragFloat(u8"##������ ���������� ��: Y", sliders.hpSizeY, 0.01, 0.0, 440.0, u8"������ Y: %.2f") then
                                InterfaceEditor.preset["HPHud"]["sizeY"] = ("%.2f"):format(sliders.hpSizeY[0])
                                InterfaceEditor.saveJson()
                            end imgui.SameLine()
                            if imgui.Button(u8"��������##hpSizeY", imgui.ImVec2(90, 24)) then
                                InterfaceEditor.preset["HPHud"]["sizeY"] = 1.00
                                InterfaceEditor.saveJson()
                                sliders.hpSizeY[0] = 1.00
                            end
                            imgui.PopItemWidth()
                            imgui.PushItemWidth(180)
                            if imgui.Combo(u8"����� ������##hp", ivar.fontstylehpvar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                                InterfaceEditor.preset["HPHud"]["fonts"] = ivar.fontstylehpvar[0]
                                InterfaceEditor.saveJson()
                            end
                            imgui.PopItemWidth()
                            
                            imgui.Text(u8"���� ����������:") imgui.SameLine() if imgui.ColorEdit4(u8"##���� ����������##hp", icolors.IndicatorHP_color, imgui.ColorEditFlags.NoInputs) then
                                local r, g, b, a = tonumber(("%.3f"):format(icolors.IndicatorHP_color[0])), tonumber(("%.3f"):format(icolors.IndicatorHP_color[1])), tonumber(("%.3f"):format(icolors.IndicatorHP_color[2]))
                                InterfaceEditor.preset["HPHud"]["Color"] = GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                                InterfaceEditor.saveJson()
                            end


                            
                        end

                        imgui.PopStyleColor()

                    

                imgui.NewLine()

                    imgui.PushFont(GT_MOD.UI.fonts[35])
                    imgui.PushStyleColor(imgui.Col.Text, col1)
                    imgui.Text(u8"��������� �����")
                    imgui.PopStyleColor()
                    imgui.PopFont()
                    imgui.Spacing()
                    imgui.PushStyleColor(imgui.Col.Text, col2)
                    if imgui.Checkbox(u8"�������� ���������##�����", checkboxes.armorhud) then
                        InterfaceEditor.preset["ArmorHud"]["Status"] = checkboxes.armorhud[0]
                        InterfaceEditor.saveJson()
                    end
                    if InterfaceEditor.preset["ArmorHud"]["Status"] then
                        if imgui.Checkbox(u8"�������� ������� AR", checkboxes.armortext) then
                            InterfaceEditor.preset["ArmorHud"]["armortext"] = checkboxes.armortext[0]
                            InterfaceEditor.saveJson()
                        end
                        imgui.PushItemWidth(330)
                        if imgui.DragFloat(u8"##��������� ����������: X##arm", sliders.armorhudPosX, 0.2, 0.0, 625.0, u8"��������� X: %.2f") then
                            InterfaceEditor.preset["ArmorHud"]["posX"] = ("%.2f"):format(sliders.armorhudPosX[0])
                            InterfaceEditor.saveJson()
                        end imgui.SameLine()
                        if imgui.Button(u8"��������##hpposx", imgui.ImVec2(90, 24)) then
                            InterfaceEditor.preset["ArmorHud"]["posX"] = 609.70
                            InterfaceEditor.saveJson()
                            sliders.armorhudPosX[0] = 609.70
                        end
                        if imgui.DragFloat(u8"##��������� ����������: Y##arm", sliders.armorhudPosY, 0.2, 0.0, 440.0, u8"��������� Y: %.2f") then
                            InterfaceEditor.preset["ArmorHud"]["posY"] = ("%.2f"):format(sliders.armorhudPosY[0])
                            InterfaceEditor.saveJson()
                        end imgui.SameLine()
                        if imgui.Button(u8"��������##armorhudPosY", imgui.ImVec2(90, 24)) then
                            InterfaceEditor.preset["ArmorHud"]["posY"] = 44.30
                            InterfaceEditor.saveJson()
                            sliders.armorhudPosY[0] = 44.30
                        end
                        if imgui.DragFloat(u8"##������ ����������: X##arm", sliders.armorhudSizeX, 0.01, 0.0, 440.0, u8"������ X: %.2f") then
                            InterfaceEditor.preset["ArmorHud"]["sizeX"] = ("%.2f"):format(sliders.armorhudSizeX[0])
                            InterfaceEditor.saveJson()
                        end imgui.SameLine()
                        if imgui.Button(u8"��������##armSizeX", imgui.ImVec2(90, 24)) then
                            InterfaceEditor.preset["ArmorHud"]["sizeX"] = 0.25
                            InterfaceEditor.saveJson()
                            sliders.armorhudSizeX[0] = 0.25
                        end
                        if imgui.DragFloat(u8"##������ ����������: Y##arm", sliders.armorhudSizeY, 0.01, 0.0, 440.0, u8"������ Y: %.2f") then
                            InterfaceEditor.preset["ArmorHud"]["sizeY"] = ("%.2f"):format(sliders.armorhudSizeY[0])
                            InterfaceEditor.saveJson()
                        end imgui.SameLine()
                        if imgui.Button(u8"��������##hpSizeY", imgui.ImVec2(90, 24)) then
                            InterfaceEditor.preset["ArmorHud"]["sizeY"] = 1.00
                            InterfaceEditor.saveJson()
                            sliders.armorhudSizeY[0] = 1.00
                        end
                        imgui.PopItemWidth()
                        imgui.PushItemWidth(180)
                        if imgui.Combo(u8"����� ������##arm", ivar.fontstylearmvar, imgui.new['const char*'][#(GT_MOD.UI.fontstyletext)](GT_MOD.UI.fontstyletext), #(GT_MOD.UI.fontstyletext)) then
                            InterfaceEditor.preset["ArmorHud"]["fonts"] = ivar.fontstylearmvar[0]
                            InterfaceEditor.saveJson()
                        end
                        imgui.PopItemWidth()
                        
                        imgui.Text(u8"���� ����������:") imgui.SameLine() if imgui.ColorEdit4(u8"##���� ����������##arm", icolors.IndicatorARMOR_color, imgui.ColorEditFlags.NoInputs) then
                            local r, g, b, a = tonumber(("%.3f"):format(icolors.IndicatorARMOR_color[0])), tonumber(("%.3f"):format(icolors.IndicatorARMOR_color[1])), tonumber(("%.3f"):format(icolors.IndicatorARMOR_color[2]))
                            InterfaceEditor.preset["ArmorHud"]["Color"]= GT_MOD.functions.join_argb(255, r * 255, g * 255, b * 255)
                            InterfaceEditor.saveJson()
                        end

                        
                    end

                    imgui.PopStyleColor()

                imgui.EndChild()
            elseif navigations.current_elemets == 4 then
                imgui.PushStyleColor(imgui.Col.Border, GT_MOD.config.ini.borderchild.draw and imgui.GetStyle().Colors[imgui.Col.PlotHistogram] or imgui.ImVec4(0,0,0,0))
                imgui.BeginChild("##rightmenugg", imgui.ImVec2(imgui.GetWindowSize().x - 45, imgui.GetWindowSize().y - 118), true)
                imgui.PopStyleColor()
                    drawFileSelection()
                    imgui.SameLine()
                    imgui.SetCursorPosX(imgui.GetCursorPos().x+40)
                    GT_MOD.UI.MainBox("������� �����", imgui.ImVec2(250,110), 0)

                        imgui.PushFont(GT_MOD.UI.fonts[35])
                        imgui.PushStyleColor(imgui.Col.Text, col1)
                        imgui.Text(u8"������� ������")
                        imgui.PopStyleColor()
                        imgui.PopFont()
                        imgui.Spacing()
                        imgui.PushStyleColor(imgui.Col.Text, col2)
                            imgui.PushItemWidth(120)
                            imgui.Text(u8"��������:")
                            imgui.SameLine()
                            imgui.InputText(u8'##������� �������� �������:', GT_MOD.UI.buffers.IEpresetName, ffi.sizeof(GT_MOD.UI.buffers.IEpresetName))
                            imgui.PopItemWidth()

                            if imgui.Button(u8"�������", imgui.ImVec2(88, 24)) then
                                if u8:decode(ffi.string(GT_MOD.UI.buffers.IEpresetName)) ~= nil and u8:decode(ffi.string(GT_MOD.UI.buffers.IEpresetName)) ~= "" then
                                    InterfaceEditor.txtFiles = {}
                                    if not doesFileExist(getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..u8:decode(ffi.string(GT_MOD.UI.buffers.IEpresetName))..".json") then
                                        local file = io.open(getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..u8:decode(ffi.string(GT_MOD.UI.buffers.IEpresetName))..".json", "a+") -- ��������� � ������� ����
                                        file:close() -- ���������, ��� ���� �� ����� ����� �� �� ��������. �� �� ��� ���������!
                                        GT_MOD.functions.AddNotify(script_name.."{FFFFFF} ����: {dc4747}"..u8:decode(ffi.string(GT_MOD.UI.buffers.IEpresetName))..".json {FFFFFF}������� ������!", 3000)

                                        local file = io.open(getWorkingDirectory().."\\GameTweaker\\IE-presets\\"..u8:decode(ffi.string(GT_MOD.UI.buffers.IEpresetName))..".json", "w")
                            
                                        file:write(formatterJson(IEPresets))
                                        file:flush() -- ���������
                                        file:close() -- ���������
                                        GT_MOD.UI.buffers.IEpresetName = new.char[128]()
                                        txtFilesInCurrentDirectory = InterfaceEditor.getTxtFilesInDirectory(getGameDirectory().."\\moonloader\\GameTweaker\\IE-presets")  -- ��������� ������ ������
                                    else
                                        GT_MOD.functions.AddNotify("���� � ����� ��������� ��� ����������", 3000)
                                        GT_MOD.UI.buffers.IEpresetName = new.char[128]()
                                    end
                                end
                            end
                            

                        imgui.PopStyleColor()
                    imgui.EndChild()

                    
                imgui.EndChild()
            elseif navigations.current_elemets == 5 then
                imgui.PushStyleColor(imgui.Col.Border, GT_MOD.config.ini.borderchild.draw and imgui.GetStyle().Colors[imgui.Col.PlotHistogram] or imgui.ImVec4(0,0,0,0))
                imgui.BeginChild("##rightmenugg", imgui.ImVec2(imgui.GetWindowSize().x - 45, imgui.GetWindowSize().y - 118), true)
                imgui.PopStyleColor()
                    if imgui.Checkbox(u8"������ ���", checkboxes.showchat) then
                        InterfaceEditor.preset["Other"]["showchat"] = checkboxes.showchat[0]
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("ShowCHAT")
                    end
                    if imgui.Checkbox(u8"������ ���", checkboxes.showhud) then
                        InterfaceEditor.preset["Other"]["showhud"] = checkboxes.showhud[0]
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("ShowHUD")
                    end
                    
                    if imgui.Checkbox(u8"������ �� �������", checkboxes.targetblip) then
                        InterfaceEditor.preset["Other"]["targetblip"] = checkboxes.targetblip[0]
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("TargetBlip")
                    end
                    GT_MOD.UI.Hint(u8"�������� / ��������� ����������� ��� �������� ����� �� � ��� ��������", 0.3)

                    imgui.NewLine()
                    if imgui.Checkbox(u8"����������� �������� ���������� ��� �������", checkboxes.vehiclenames) then
                        InterfaceEditor.preset["Other"]["vehiclenames"] = checkboxes.vehiclenames[0]
                        InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("VehicleNames")
                    end

                    if InterfaceEditor.preset["Other"]["vehiclenames"] then
                        if GT_MOD.UI.CustomSlider(u8"##����������������", sliders.vehiclenamesSize, 0.01, 2.00, u8"������ �������� ����������: %0.2f", 230) then
                            InterfaceEditor.preset["Other"]["vehiclenamesSize"] = ("%.2f"):format(sliders.vehiclenamesSize[0])
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsVehicleNames")
                        end

                        if GT_MOD.UI.CustomSlider(u8"##������������", sliders.vehiclenamesPosX, 0.01, 540.00, u8"������� �������� ���������� X: %0.2f", 230) then
                            InterfaceEditor.preset["Other"]["vehiclenamesPosX"] = ("%.2f"):format(sliders.vehiclenamesPosX[0])
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsVehicleNames")
                        end
                        if GT_MOD.UI.CustomSlider(u8"##������������y", sliders.vehiclenamesPosY, 15.01, 440.00, u8"������� �������� ���������� Y: %0.2f", 230) then
                            InterfaceEditor.preset["Other"]["vehiclenamesPosY"] = ("%.2f"):format(sliders.vehiclenamesPosY[0])
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsVehicleNames")
                        end
                        imgui.NewLine()
                        if imgui.Button(u8"��������##settingsvehcilenames") then
                            InterfaceEditor.preset["Other"]["vehiclenamesSize"] = 0.7
                            InterfaceEditor.preset["Other"]["vehiclenamesPosX"] = 32
                            InterfaceEditor.preset["Other"]["vehiclenamesPosY"] = 104
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsVehicleNames")
                            LoadPresetData()
                        end
                    end
                    if imgui.Checkbox(u8"����������� �������� �������", checkboxes.areanames) then
                        InterfaceEditor.preset["Other"]["areanames"] = checkboxes.areanames[0]
                         InterfaceEditor.saveJson()
                        GT_MOD.functions.gotofunc("AreaNames")
                    end

                    if InterfaceEditor.preset["Other"]["areanames"] then
                        if GT_MOD.UI.CustomSlider(u8"##���������������", sliders.areanamesSize, 0.01, 2.00, u8"������ �������� �������: %0.2f", 230) then
                            InterfaceEditor.preset["Other"]["areanamesSize"] = ("%.2f"):format(sliders.areanamesSize[0])
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsAreaNames")
                        end

                        if GT_MOD.UI.CustomSlider(u8"##����������������", sliders.areanamesPosX, 0.01, 540.00, u8"������� �������� ������� X: %0.2f", 230) then
                            InterfaceEditor.preset["Other"]["areanamesPosX"] = ("%.2f"):format(sliders.areanamesPosX[0])
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsAreaNames")
                        end
                        if GT_MOD.UI.CustomSlider(u8"##������������ykvbws", sliders.areanamesPosY, -200.01, 100.00, u8"������� �������� ������� Y: %0.2f", 230) then
                            InterfaceEditor.preset["Other"]["areanamesPosY"] = ("%.2f"):format(sliders.areanamesPosY[0])
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsAreaNames")
                        end
                        imgui.NewLine()
                        if imgui.Button(u8"��������##settingsareanames") then
                            InterfaceEditor.preset["Other"]["areanamesSize"] = 0.7
                            InterfaceEditor.preset["Other"]["areanamesPosX"] = 32
                            InterfaceEditor.preset["Other"]["areanamesPosY"] = 76
                            InterfaceEditor.saveJson()
                            GT_MOD.functions.gotofunc("SettingsAreaNames")
                            LoadPresetData()
                        end
                    end


                imgui.EndChild()
            end
            imgui.PopFont()
        end

        
    return InterfaceEditor
end