return function(GT_MOD)

    
local functions = {} -- module

local ffi = require("ffi")
local tcc = require("libtcc")
local memory = require("memory")
local RakLua = require("RakLua")
local imgui = require("mimgui")

local encoding = require("encoding")
encoding.default = "CP1251"
local u8 = encoding.UTF8

local checkboxes, sliders, buffers, icolors = GT_MOD.UI.checkboxes, GT_MOD.UI.sliders, GT_MOD.UI.buffers, GT_MOD.UI.icolors

local FixedInput = false

local priorityClasses = {
    {name = u8"������", value = 0x00004000},
    {name = u8"���� ��������", value = 0x00008000},
    {name = u8"����������", value = 0x00000020},
    {name = u8"�������", value = 0x00000080},
}

local names = {}
for _, priority in ipairs(priorityClasses) do
    table.insert(names, priority.name)
end

ffi.cdef[[
    typedef struct {
        char dmDeviceName[32];
        uint16_t dmSpecVersion;
        uint16_t dmDriverVersion;
        uint16_t dmSize;
        uint16_t dmDriverExtra;
        uint32_t dmFields;
        int32_t dmPositionX;
        int32_t dmPositionY;
        uint32_t dmDisplayOrientation;
        uint32_t dmDisplayFixedOutput;
        int16_t dmColor;
        int16_t dmDuplex;
        int16_t dmYResolution;
        int16_t dmTTOption;
        int16_t dmCollate;
        char dmFormName[32];
        uint16_t dmLogPixels;
        uint32_t dmBitsPerPel;
        uint32_t dmPelsWidth;
        uint32_t dmPelsHeight;
        uint32_t dmDisplayFlags;
        uint32_t dmDisplayFrequency;
        uint32_t dmICMMethod;
        uint32_t dmICMIntent;
        uint32_t dmMediaType;
        uint32_t dmDitherType;
        uint32_t dmReserved1;
        uint32_t dmReserved2;
        uint32_t dmPanningWidth;
        uint32_t dmPanningHeight;
    } DEVMODE;
    
    int EnumDisplaySettingsA(const char* deviceName, uint32_t modeNum, DEVMODE* devMode);
]]

function getMaxRefreshRate()
    local currentMode = ffi.new("DEVMODE")
    currentMode.dmSize = ffi.sizeof("DEVMODE")
    
    -- �������� ������� ���������
    if ffi.C.EnumDisplaySettingsA(nil, 0xFFFFFFFF, currentMode) == 0 then
        return 60
    end
    
    local currentWidth = currentMode.dmPelsWidth
    local currentHeight = currentMode.dmPelsHeight
    local maxRate = 0
    
    -- ���������� ��� ������
    local modeNum = 0
    local mode = ffi.new("DEVMODE")
    
    while ffi.C.EnumDisplaySettingsA(nil, modeNum, mode) ~= 0 do
        if mode.dmPelsWidth == currentWidth and 
           mode.dmPelsHeight == currentHeight then
            if mode.dmDisplayFrequency > maxRate then
                maxRate = mode.dmDisplayFrequency
            end
        end
        modeNum = modeNum + 1
    end
    
    return maxRate > 0 and maxRate or 60
end


local function sampBase() return getModuleHandle("samp.dll") end


function functions.explode_argb(argb)
    local a = bit.band(bit.rshift(argb, 24), 0xFF)
    local r = bit.band(bit.rshift(argb, 16), 0xFF)
    local g = bit.band(bit.rshift(argb, 8), 0xFF)
    local b = bit.band(argb, 0xFF)
    return a, r, g, b
end


function functions.explode_rgba(argb)-- ������������� ���� �� ������� � ���� 0xFF - alpha FFFFFF - white � r,g,b,a ��� coloredit
    local a = bit.band(bit.rshift(argb, 24), 0xFF) / 255
    local r = bit.band(bit.rshift(argb, 16), 0xFF) / 255
    local g = bit.band(bit.rshift(argb, 8), 0xFF) / 255
    local b = bit.band(argb, 0xFF) / 255
    return r, g, b, a
end

function functions.join_argb(a, r, g, b)
    local argb = b
    argb = bit.bor(argb, bit.lshift(g, 8))
    argb = bit.bor(argb, bit.lshift(r, 16))
    argb = bit.bor(argb, bit.lshift(a, 24))
    return argb
end


function functions.AddNotify(text, displayTime, width)
    --���� ���, ����� ������ ���������� ����� ���� ������
    sampAddChatMessage(text, 0x88aa62)
end

function functions.isLookingAtPlayer()
    return readMemory(0xB6F028+0x2B, 1, true) == 1
end


function functions.get_samp_version()
    if samp_base == nil or samp_base == 0 then 
        samp_base = getModuleHandle("samp.dll") 
    end 

    if samp_base ~= 0 then 
        local e_lfanew = ffi.cast("long*", samp_base + 60)[0] 
        local nt_header = samp_base + e_lfanew 
        local entry_point_addr = ffi.cast("unsigned int*", nt_header + 40)[0] 
        local versions = {
            [0x31DF13] = "r1",
            [0x3195DD] = "r2",
            [0xCC4D0] = "r3",
            [0xCBCB0] = "r4",
            [0xFDB60] = "dl"
        }
        return versions[entry_point_addr] or "unknown"
    end 

    return "unknown" 
end

-- [ memory funcs (fix for moonloader v. 0.27)]
function functions.memory_getfloat(adr, prot)
    return representIntAsFloat(readMemory(adr, 4, prot))
end

function functions.memory_setfloat(adr, value, prot)
    return writeMemory(adr, 4, representFloatAsInt(value), prot)
end


function functions.hex2bin(hexData, address, numBytes)
    -- ����������� hex ������ � ������ ������
    local bytes = {}
    for i = 1, #hexData, 2 do
        local byte = tonumber(hexData:sub(i, i + 1), 16)
        table.insert(bytes, byte)
    end

    -- ���������� ����� �� 4 �� ���
    for i = 1, numBytes, 4 do
        local chunk = 0
        for j = 0, 3 do
            local index = i + j
            if index <= numBytes then
                chunk = chunk + (bytes[index] or 0) * (0x100 ^ j)
            end
        end
        writeMemory(address + i - 1, math.min(4, numBytes - i + 1), chunk, true)
    end
end

 -- ������� ��� ������������ ������� ������� ������ ������
local cleanMemoryTimestamps = cleanMemoryTimestamps or {}
local lastWarningTime = lastWarningTime or 0 -- ����� ���������� ��������������
local isCleaning = isCleaning or false -- ���� ���������� �������

local objdists = {}-- ������� ��� �������� �� �������� � �� ���������

function functions.getobjdists()
    
    
    local file = io.open("moonloader\\GameTweaker\\Objects_Dist.txt", "a+")
    
    file:close()
    local file = io.open("moonloader\\GameTweaker\\Objects_Dist.txt", "a+")
    for line in file:lines() do
        objdists[#objdists+1] = line -- ���������� ������ � ������
    end
    file:close()
    if ffi.string(GT_MOD.UI.buffers.multilineText) == "" then
        GT_MOD.UI.buffers.multilineText = imgui.new.char[100000](u8(table.concat(objdists, "\n")))
    end
end

function functions.saveobjdist()
    if doesFileExist("moonloader\\GameTweaker\\Objects_Dist.txt") then
        local path = getGameDirectory().."//moonloader//GameTweaker//Objects_Dist.txt"
        os.remove(path)
        file = io.open("moonloader\\GameTweaker\\Objects_Dist.txt", "a+") -- ��������� ����
        file:write(string.format(""..u8:decode ( ffi.string(GT_MOD.UI.buffers.multilineText) ).."\n") )

        file:close()
        objdists = {}
        functions.getobjdists()
        functions.gotofunc("SetDistObjects")
    end
end

function m_pCols(id_obj)
    return id_obj ~= nil and (callFunction(0x403DA0, 1, 1, id_obj) + 0x14) or false
end



function functions.CollisionProcess()
    local targetModels = {904, 858, 747, 650}
    
    for k, object in pairs(getAllObjects()) do
        local modelId = getObjectModel(object)
        
        for i, targetId in pairs(targetModels) do
            if modelId == targetId then

                setObjectCollision(object, not GT_MOD.config.ini.settings.CollGrass)
                break
            end
        end
    end
end

function functions.gotofunc(fnc)
    local preset = GT_MOD.InterfaceEditor.preset

    if fnc == "LoadPatch" or fnc == "all" then -- ��������� ��� ������������� ����

        --writeMemory(0x5A3EA0, 1, 0xC3, true)--disable pocobj

        writeMemory(0x5B8E55, 4, 90000, true)--flickr
        writeMemory(0x5B8EB0, 4, 90000, true)--flickr

        local fVol = readMemory(0xEEFCEA, 4, true)
        writeMemory(0xB5FCC8, 4, fVol, true)-- audiostream start game 0

        writeMemory(0x5EFFE7, 1, 0xEB, true)-- disable talking
        -------------------------------------------------------------
        writeMemory(0x5557CF, 4, 0x90909090, true)-- binthesky by DK
        writeMemory(0x5557CF+3, 4, 0x90909090, true)

    

        writeMemory(0x745BC9, 2, 0x9090, true) --SADisplayResolutions(1920x1080// 16:9)

        writeMemory(0xC2B9CC, 4, 0x3EB3B675, true)--car speed fps fix

        writeMemory(0x57733B, 4, 0x90909090, true)--��������� �������� �� ������ "������ ����� ����" � ���� �����
        writeMemory(0x57733B+4, 1, 0x90, true)
        

        ---disable input in framelimiter menu (���� �� �����)
        --writeMemory(0xBA6748+0x4C, 1, 0, true)
        --writeMemory(0x57CEC7,4, 0x0008C2, true)
        ------------------------------------------
    end
    
    --if GT_MOD.config.ini.settings.debug_info then sampfuncsLog("["..os.date("%H:%M:%S").."] {88aa62}"..script_name.."{FFFFFF} ����� �������: {dc4747}"..fnc) end

    ------------------------------------fixes and other-----------------------------
    if fnc == "all" then

        memory.fill(0x584C6D, 0x90, 0x19, true)-- fixloadmap
         --------------------------[[fix radio icon in menu pause]]------------------------------
        writeMemory(0xCDCDCD, 4, representFloatAsInt(0.098125), true) -- Y ������� std 0.078125
        writeMemory(0xCDCDDD, 4, representFloatAsInt(0.0546875), true) -- X ������� std 0.0546875
        writeMemory(0xDDDDDD, 4, representFloatAsInt(0.08375), true) -- X ����� std 0.09375
        writeMemory(0xCDDDDD, 4, representFloatAsInt(0.14392857), true) -- Y ����� std 0.13392857
        writeMemory(0x57473B+2, 4, 0xCDCDCD, true) -- Y ������� 0.078125 
        writeMemory(0x574761+2, 4, 0xCDCDDD, true) -- X ������� 0.0546875
        writeMemory(0x57482F+2, 4, 0xCDDDDD, true) -- Y �����
        writeMemory(0x574857+2, 4, 0xDDDDDD, true) -- X �����
        -----------------------------------------------------------------------------------------
        callFunction(0x7469A0, 0, 0) --mousefix in pause


        -- Fix Mouse not restoring properly after returning from ALT+TAB or MINIMIZED
        -- Disable re-initialization of DirectInput mouse device by the game
        writeMemory(0x748808, 1, 0xEB, true)
        writeMemory(0x7487C1, 1, 0xEB, true)

        writeMemory(0x53F31D, 1, 0xEB, true)
        writeMemory(0x53F3F1, 1, 0xEB, true)

        writeMemory(0x576CCC, 1, 0xEB, true)
        writeMemory(0x576EBA, 1, 0xEB, true)
        writeMemory(0x576F8A, 1, 0xEB, true)

        --[[
            push = + 1
            fld or fmul or fsub or fadd = + 2
            lea + 3
            mov = + 4
        ]]

        ------------------------------------------
        --sensfix
        memory.write(5382798, 0xB6EC1C, 4, true)
        memory.write(5311528, 0xB6EC1C, 4, true)
        memory.write(5316106, 0xB6EC1C, 4, true)
        ------


        memory.write(0x058E280, 0xEB, 1, true)--white fuck in crosshair

        memory.setint8(0x4414C0, 0xC3, false)--PassingOfTimeOnDeath
        memory.setint8(0x732F5D+1, 0, true) -- fog weapons fix (1 orig)
        memory.setuint32(0x736F88, 0, true)-- AirCraftExplosionFix
        writeMemory(0x8D37D0, 1, 0, true) -- ���������� ������� FPS ����� ������ ���������� �� ����.
        
        --------[fix spawn bottle or smoke]----------
        memory.fill(0x4217F4, 0x90, 21, true)
        memory.fill(0x4218D8, 0x90, 17, true)
        memory.fill(0x5F80C0, 0x90, 10, true)
        memory.fill(0x5FBA47, 0x90, 10, true)
        ---------------------------------------------

        writeMemory(0x522DBE, 2, 0x09EB, true)--interior cam fix (thanks air) original (0974) = (09EB)
    end

    if fnc == "SetPriorityClass" then
        ffi.cdef[[
            int SetPriorityClass(void* hProcess, int dwPriorityClass);
            void* GetCurrentProcess();
        ]]


        local priority = priorityClasses[GT_MOD.config.ini.settings.PriorityClass+1]
        local process = ffi.C.GetCurrentProcess()

        ffi.C.SetPriorityClass(process, priority.value)
    end
    
    if fnc == "updateWindow" then
        --[[local RwD3D9ChangeMultiSamplingLevels = ffi.cast("int(__cdecl*)(int)", 0x7F8A90)
        RwD3D9ChangeMultiSamplingLevels(readMemory(0x8E2430, 4, true))]]
    end

    if fnc == "KillList" or fnc == "all" then

        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.KillListChange then
                writeMemory(sampBase()+0xD7FD4, 4, representFloatAsInt(GT_MOD.config.ini.settings.KillListPosX), true) 
                writeMemory(sampBase()+0xD7FD8, 4, representFloatAsInt(GT_MOD.config.ini.settings.KillListPosY), true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase()+0xD7FD4, 4, representFloatAsInt(0.75), true) 
                    writeMemory(sampBase()+0xD7FD8, 4, representFloatAsInt(0.300), true)
                end
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.KillListChange then
                writeMemory(sampBase()+0xEA2F4, 4, representFloatAsInt(GT_MOD.config.ini.settings.KillListPosX), true)
                writeMemory(sampBase()+0xEA2F8, 4, representFloatAsInt(GT_MOD.config.ini.settings.KillListPosY), true) 
            else
                if fnc ~= "all" then
                    writeMemory(sampBase()+0xEA2F4, 4, representFloatAsInt(0.75), true)
                    writeMemory(sampBase()+0xEA2F8, 4, representFloatAsInt(0.300), true) 
                end
            end
        end
    end
    if fnc == "NetStatsWithHud" or fnc == "all" then
        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.NetStatsWithHud then
                writeMemory(sampBase() + 0x7137F, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x7137F+4, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x7137F+8, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x7137F+12, 1, 0x90, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0x7137F, 4, 0xA10C0D8B, true) 
                    writeMemory(sampBase() + 0x7137F+4, 4, 0x6A03BC, true)
                    writeMemory(sampBase() + 0x7137F+8, 4, 0x2BF84E8, true)
                    writeMemory(sampBase() + 0x7137F+12, 1, 0x00, true)
                end
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.NetStatsWithHud then
                writeMemory(sampBase() + 0x7526F, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x7526F+4, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x7526F+8, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x7526F+12, 1, 0x90, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0x7526F, 4, 0xA10C0D8B, true) 
                    writeMemory(sampBase() + 0x7526F+4, 4, 0x6A03BC, true)
                    writeMemory(sampBase() + 0x7526F+8, 4, 0x2BF84E8, true)
                    writeMemory(sampBase() + 0x7526F+12, 1, 0x00, true)
                end
            end
        end
    end
    if fnc == "InputPatch" or fnc == "all" then
        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.inputPatch then
                writeMemory(sampBase() + 0x6B9FB, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x6B9FB+4, 1, 0x90, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0x6B9FB, 4, 0xFF9EE0E8, true) 
                    writeMemory(sampBase() + 0x6B9FB+4, 1, 0xFF, true)
      
                end
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.inputPatch then
                writeMemory(sampBase() + 0x6F8FB, 4, 0x90909090, true)
                writeMemory(sampBase() + 0x6F8FB+4, 1, 0x90, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0x6F8FB, 4, 0xFF9EE0E8, true)
                    writeMemory(sampBase() + 0x6F8FB+4, 1, 0xFF, true)
                end
            end
        end
    end
    -----------------------------------------------------------------------
    if fnc == "OpenMenu" then
        GT_MOD.UI.main[0] = not GT_MOD.UI.main[0]
	end
    if fnc == "OpenTws" then
        GT_MOD.UI.tws[0] = not GT_MOD.UI.tws[0]
	end
    if fnc == "OpenTimecycCreator" then
        GT_MOD.UI.tcyc[0] = not GT_MOD.UI.tcyc[0]
	end

    if fnc == "GTATime" then
        writeMemory(0xB7015C, 4, GT_MOD.config.ini.settings.miliseconds, true)--c ms time
        if GT_MOD.config.ini.settings.gtatime then
            writeMemory(0x52CF10, 1, 0x51, true)
        else
            writeMemory(0x52CF10, 1, 0xC3, true)
        end
        setTimeOfDay(GT_MOD.config.ini.settings.hours, GT_MOD.config.ini.settings.min)
    end

    if fnc == "GTAWeather" then
        local function getMilliseconds()
            local _, b = math.modf(os.clock())
            return ("%03d"):format(b * 1000)
        end

        if GT_MOD.config.ini.settings.gtaweather then
            math.randomseed(os.time())
            
    
            local allowedWeathers = {}
            local excludedWeathers = {21, 22, 44, 45} -- ����������� ������
            
            -- ��������� ������� ����������� �����, �������� �������������
            for weatherId = 0, 28 do
                local isExcluded = false
                for _, excludedId in ipairs(excludedWeathers) do
                    if weatherId == excludedId then
                        isExcluded = true
                        break
                    end
                end
                if not isExcluded then
                    table.insert(allowedWeathers, weatherId)
                end
            end
            
            -- �������� ��������� ������ �� �����������
            local randw = allowedWeathers[math.random(1, #allowedWeathers)]
            
            forceWeatherNow(randw)
            writeMemory(0x72A510, 1, 0x66, false)
            
            -- ��������� ��������� ������
            if GT_MOD.config.ini.settings.noRain then
                local offsets = {}
                -- �����
                offsets = {0x2C, 0x2D, 0x2E, 0x2F}
                for i = 1, 4 do memory.setint8(0x8D5EB0 + offsets[i], 15, true) end
                -- ��
                memory.setint8(0x8D5EF0 + 0x2E, 0, true)
                -- ��
                offsets = {0x12, 0x13, 0x2D, 0x2E}
                for i = 1, 4 do memory.setint8(0x8D5F30 + offsets[i], 7, true) end
            end
            
            -- ��������� �������� ������
            if GT_MOD.config.ini.settings.noFog then
                local offsets = {}
                -- �����
                offsets = {0xA, 0xB, 0x29, 0x2A}
                for i = 1, 4 do memory.setint8(0x8D5EB0 + offsets[i], 15, true) end
                -- ��
                offsets = {0x7, 0x8, 0x1E, 0x1F, 0x31, 0x32}
                for i = 1, 6 do memory.setint8(0x8D5F30 + offsets[i], 7, true) end
            end
            
            -- ��������� ��������� ����
            if GT_MOD.config.ini.settings.noSandstorm then
                local offsets = {0x3, 0x4, 0x25, 0x26, 0x27, 0x3C, 0x3D, 0x3E}
                for i = 1, 8 do memory.setint8(0x8D5FB0 + offsets[i], 18, true) end
            end
            
            local CWeather__ReleaseWeather = ffi.cast("void (__cdecl*)()", 0x72A510)
            CWeather__ReleaseWeather()
            math.randomseed(os.time() * getMilliseconds())
            memory.setint8(0xC81310, math.random(0, 63), false) -- CWeather::WeatherTypeInList
        else
            writeMemory(0x72A510, 1, 0xC3, false)
        end
    end

    if fnc == "BlockWeather" or fnc == "all" then
        if functions.get_samp_version() == "r1" then

            if GT_MOD.config.ini.settings.blockweather then
                writeMemory(sampBase() + 0x9C130, 4, 0x0004C2, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0x9C130, 4, 0x5D418B, true)
                end
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.blockweather then
                writeMemory(sampBase() + 0xA0430, 4, 0x0004C2, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0xA0430, 4, 0x5D418B, true)
                end
            end
        end
    end
    
    if fnc == "SetTime" or fnc == "all" then
        GT_MOD.TimecycEditor.Im.Hours = GT_MOD.config.ini.settings.hours
        GT_MOD.TimecycEditor.Im.Mins = GT_MOD.config.ini.settings.min

        setTimeOfDay(GT_MOD.config.ini.settings.hours, GT_MOD.config.ini.settings.min)
	end
    if fnc == "SetWeather" or fnc == "all" then
        GT_MOD.TimecycEditor.Im.CurrWeather[0] = GT_MOD.config.ini.settings.weather
        forceWeatherNow(GT_MOD.config.ini.settings.weather)
	end

    if fnc == "SetPlayersDist" or fnc == "all" then
        writeMemory(0xFDFEEC+933, 4, representFloatAsInt(GT_MOD.config.ini.settings.playersDist), true)
        writeMemory(0x73295C + 2, 4, 0xFDFEEC+933, true)
	end

    if fnc == "SetWeaponDist" or fnc == "all" then
        writeMemory(0xDEECAE+350, 4, representFloatAsInt(GT_MOD.config.ini.settings.drawweapondist), true)
        writeMemory(0x7336A8 +2, 4, 0xDEECAE+350, true)
	end
    
    if fnc == "BlockTime" or fnc == "all" then
        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.blocktime then
                writeMemory(sampBase() + 0x9C0A0, 4, 0x000008C2, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0x9C0A0, 4, 0x0824448B, true)
                end
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.blocktime then
                writeMemory(sampBase() + 0xA03A0, 4, 0x000008C2, true)
            else
                if fnc ~= "all" then
                    writeMemory(sampBase() + 0xA03A0, 4, 0x0824448B, true)
                end
            end
        end
    end

    
    if fnc == "GivemeDist" or fnc == "all" then
        if GT_MOD.config.ini.settings.givemedist then
            ---------------return original bytes-------
            functions.hex2bin("8B0DF0C4B700", 0x53EA93, 6)
            functions.hex2bin("DEC1D95E54", 0x55FCD9, 5)
            ------------------------------------------

            memory.write(0x53EA95, 0xB7C7F0, 4, true)
            memory.write(0x7FE621, 0xC99F68, 4, true)
        else
            if fnc ~= "all" then
                memory.write(0x53EA95, 0xB7C4F0, 4, true)
                memory.write(0x7FE621, 0xC992F0, 4, true)
            end
        end
	end
    if fnc == "LodDist" or fnc == "all" then
        if GT_MOD.config.ini.settings.givemedist then
            functions.memory_setfloat(0xCFFA11, GT_MOD.config.ini.settings.lod, true)
            local aWrites = {
                [1] = 0x555172+2, [2] = 0x555198+2, [3] = 0x5551BB+2, [4] = 0x55522E+2, [5] = 0x555238+2,
                [6] = 0x555242+2, [7] = 0x5552F4+2, [8] = 0x5552FE+2, [9] = 0x555308+2, [10] = 0x555362+2,
                [11] = 0x55537A+2, [12] = 0x555388+2, [13] = 0x555A95+2, [14] = 0x555AB1+2, [15] = 0x555AFB+2,
                [16] = 0x555B05+2, [17] = 0x555B1C+2, [18] = 0x555B2A+2, [19] = 0x555B38+2, [20] = 0x555B82+2,
                [21] = 0x555B8C+2, [22] = 0x555B9A+2, [23] = 0x5545E6+2, [24] = 0x554600+2, [25] = 0x55462A+2,
                [26] = 0x5B527A+2,
            }
            for i = 0, #aWrites do
                writeMemory(aWrites[i], 4, 0xCFFA11, true)
            end
        end
    end
   
    if fnc == "ShadowEdit" or fnc == "all" then
        if GT_MOD.config.ini.settings.shadowedit then
            memory.write(0x55FC61, 0, 1, true)
            memory.write(0x55FCBB, 0, 1, true)
            memory.setint32(0xB7C4E8, GT_MOD.config.ini.settings.shadowcp, true)
            memory.setint32(0xB7C4EC, GT_MOD.config.ini.settings.shadowlight, true)
        else
            if fnc ~= "all" then
                memory.write(0x55FC61, 72, 1, true)
                memory.write(0x55FCBB, 76, 1, true)
            end
        end
	end
    if fnc == "NoShadows" or fnc == "all" then
            --reset shadow for shadow asi shader fix
            functions.hex2bin('E838A21C00', 0x53E0C3, 5)
            functions.hex2bin('E893C81C00', 0x53E0C8, 5)
            functions.hex2bin('E87D9E1C00', 0x53E0BE, 5)

        
            if GT_MOD.config.ini.settings.pedshadows then
                writeMemory(0x707B40, 1, 0xC3, true)--��������� ���� ��� ������
            else
                if fnc ~= "all" then
                    writeMemory(0x707B40, 1, 0x83, true)--�������� ���� ��� ������
                end
            end
            if GT_MOD.config.ini.settings.vehshadows then
                --��������� ���� ��� �����������
                memory.fill(0x6ABCF5, 0x90, 5, true)
                memory.fill(0x6BD667, 0x90, 5, true)
                memory.fill(0x6C0B21, 0x90, 5, true)
                memory.fill(0x6C58A0, 0x90, 5, true)
                memory.fill(0x6CA73A, 0x90, 5, true)
            else
                if fnc ~= "all" then
                    functions.hex2bin('E8A6000600', 0x6ABCF5, 5)
                    functions.hex2bin('E834E70400', 0x6BD667, 5)
                    functions.hex2bin('E87AB20400', 0x6C0B21, 5)
                    functions.hex2bin('E8FB640400', 0x6C58A0, 5)
                    functions.hex2bin('E861160400', 0x6CA73A, 5)
                end
            end
            if GT_MOD.config.ini.settings.poleshadows then
                writeMemory(0x70C750, 1, 0xC3, true)--��������� ���� ��� ��������
            else
                if fnc ~= "all" then
                    writeMemory(0x70C750, 1, 0x83, true)--�������� ���� ��� ��������
                end
            end

            if GT_MOD.config.ini.settings.bestshadows then
                writeMemory(0x0053E159, 1, 0xC3, true)
            else
                if fnc ~= "all" then
                    writeMemory(0x0053E159, 1, 0xE9, true)
                end
            end

	end

    if fnc == "FPSUnlock" then
        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.unlimitfps then
                memory.write(sampBase() + 0x9D9D1, 0x8B, 1, true)
            else
                memory.write(sampBase() + 0x9D9D1, 0x9B, 1, true)
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.unlimitfps then
                memory.write(sampBase() + 0xA1F60, 0x5051FF15, 4, true)
            else
                memory.write(sampBase() + 0xA1F60, 0xFFF57BE8, 4, true) 
            end
        end
	end

    if fnc == "NoWind" or fnc == "all" then
        writeMemory(0x506667+1, 4, GT_MOD.config.ini.settings.nowind and 0xB72914 or 0x8E26DC, true)
        writeMemory(0x505BEB+1, 4, GT_MOD.config.ini.settings.nowind and 0xB72914 or 0x8E26DC, true)
        writeMemory(0x505377+2, 4, GT_MOD.config.ini.settings.nowind and 0xB72914 or 0x8E26DC, true)
    end

    if fnc == "MenuPauseSound" or fnc == "all" then
        if GT_MOD.config.ini.settings.MenuPauseSound then
            writeMemory(0x4DD4A0, 4, 0x3B68FF6A, true) --0x3B68FF6A ? 0x000CC2
        else
            writeMemory(0x4DD4A0, 4, 0x000CC2, true) --0x3B68FF6A ? 0x000CC2
        end
    end

    if fnc == "BladeSound" or fnc == "all" then
        writeMemory(0x6DB863, 2, GT_MOD.config.ini.settings.bladeSound and 0x0D77 or 0x9090, true)
    end

    if fnc == "HeliEngineSound" or fnc == "all" then
        writeMemory(0xB6B994, 1, GT_MOD.config.ini.settings.heliEngineSound and 0 or 1, true)
    end

    
    if fnc == "EffectsManager" or fnc == "all" then

            functions.hex2bin(GT_MOD.config.ini.effects_manager.MotionBlur and "E811E2FFFF" or "9090909090", 0x704E8A, 5)
            writeMemory(0x8D5104, 1, GT_MOD.config.ini.effects_manager.MotionBlurIntensity, true)

            writeMemory(0xCFEDAF+1384, 4, representFloatAsInt(GT_MOD.config.ini.effects_manager.vehspec and 0.0 or 1.85), true)
            writeMemory(0x5D990A+2, 4, 0xCFEDAF+1384, true)

            if GT_MOD.config.ini.effects_manager.noPointLight then
                writeMemory(0x7000E0, 1, 0xC3, true)
            else
                if fnc ~= "all" then
                    writeMemory(0x7000E0, 1, 0x8B, true)
                end
            end

            if GT_MOD.config.ini.effects_manager.noRainyFog then
                writeMemory(0x72ADB7 , 2, 0x9090, true) --0x0875
            else
                if fnc ~= "all" then
                    writeMemory(0x72ADB7 , 2, 0x0875, true) --0x0875
                end
            end

            if GT_MOD.config.ini.effects_manager.noweatherflash then
                writeMemory(0x53EA17+1, 4, 0x8CC2D7, true)--����
                writeMemory(0x73557A+1, 4, 0x8CC2D7, true)--���������
            else
                if fnc ~= "all" then
                    writeMemory(0x53EA17+1, 4, 0xC812CC, true)--����
                    writeMemory(0x73557A+1, 4, 0xC812CC, true)--���������
                end
            end


            if GT_MOD.config.ini.effects_manager.noplaneline then
                memory.fill(0x7178F0, 0x90, 5, true)
            else
                if fnc ~= "all" then
                    functions.hex2bin('E9ABFAFFFF', 0x7178F0, 5)
                end
            end

            if GT_MOD.config.ini.effects_manager.fireworld then
                writeMemory(0x539F00, 4, 0x0024C2, true)-- ��������� �����, ��� 0x6C8B5551
            else
                if fnc ~= "all" then
                    writeMemory(0x539F00, 4, 0x6C8B5551, true)-- ��������� �����, ��� 0x6C8B5551
                end
            end

            if GT_MOD.config.ini.effects_manager.tiretracks then
                memory.fill(0x53E175, 0x90, 5, true)
            else
                if fnc ~= "all" then
                    functions.hex2bin('E8C6241E00', 0x53E175, 5)
                end
            end

            if GT_MOD.config.ini.effects_manager.nobirds then
                memory.fill(0x712833, 0x90, 2, true)
            else
                if fnc ~= "all" then
                    functions.hex2bin('3BC5', 0x712833, 2) --nobirds
                end
            end

            if GT_MOD.config.ini.effects_manager.nocloudbig then
                memory.write(5497268, -1869574000, 4, true)--������� ������ ������ ����
                memory.write(5497272, 144, 1, true)--������� ������ ������ ����
            else
                if fnc ~= "all" then
                    memory.write(5497268, 495044584, 4, true)--������� ������ ������ ���
                    memory.write(5497272, 0, 1, true)--������� ������ ������ ���
                end
            end


            if GT_MOD.config.ini.effects_manager.nocloudsmall then
                memory.fill(5497121, 144, 5, true)--������ ������ ����
            else
                if fnc ~= "all" then
                    memory.write(5497121, 494111464, 4, true)--������ ������ ���
                    memory.write(5497125, 0, 1, true)--������ ������ ���
                end
            end

            if GT_MOD.config.ini.effects_manager.nocloudhorizont then
                writeMemory(0x70EAB0, 1, 0xC3, true)-- disable horizont clouds original byte 0x83
            else
                if fnc ~= "all" then
                    writeMemory(0x70EAB0, 1, 0x83, true)-- disable horizont clouds original byte 0x83
                end
            end

            if GT_MOD.config.ini.effects_manager.postfx then
                memory.write(7358318, 2866, 4, true)--postfx off
                memory.write(7358314, -380152237, 4, true)--postfx off
                writeMemory(0x53E227, 1, 0xC3, true)
                functions.gotofunc("StaticLight")
            else
                if fnc ~= "all" then
                    memory.write(7358318, 1448280247, 4, true)--postfx on
                    memory.write(7358314, -988281383, 4, true)--postfx on
                    writeMemory(0x53E227, 1, 0xE9, true)
                end
                functions.gotofunc("StaticLight")
            end

            if GT_MOD.config.ini.effects_manager.reflectionwater then
                functions.memory_setfloat(0xCDFDDA, 0, true)
                writeMemory(0x6FBAE4+2, 4, 0xCDFDDA, true)
            else
                if fnc ~= "all" then
                    functions.memory_setfloat(0xCDFDDA, 0.3, true)
                    writeMemory(0x6FBAE4+2, 4, 0xCDFDDA, true)
                end
            end
            if GT_MOD.config.ini.effects_manager.nomorehaze then
                writeMemory(0x72C1B7, 1, 0xEB, true)
            else
                if fnc ~= "all" then
                    writeMemory(0x72C1B7, 1, 0x7C, true)
                end
            end
            if GT_MOD.config.ini.effects_manager.nosparks then
                writeMemory(0x49F040, 4, 0x0028C2, true) -- ��������� �����
            else
                if fnc ~= "all" then
                    writeMemory(0x49F040, 4, 0xF683E7E9, true) -- �������� �����
                end
            end
            if GT_MOD.config.ini.effects_manager.nowaterfog then
                writeMemory(0x6E7760, 1, 0xC3, true)
            else
                if fnc ~= "all" then
                    writeMemory(0x6E7760, 1, 0xA0, true)
                end
            end
            if GT_MOD.config.ini.effects_manager.breakobject then
                writeMemory(0x59DE40, 4, 0x0010C2, true) -- ��������� ���� ��� ������� ��������
            else
                if fnc ~= "all" then
                    writeMemory(0x59DE40, 4, 0x5358EC83, true) -- �������� ���� ��� ������� ��������
                end
            end
            if GT_MOD.config.ini.effects_manager.nogunfire then
                writeMemory(0x5DF340, 4, 0x0008C2, true)-- ��������� ����� ��� ���������
            else
                if fnc ~= "all" then
                    writeMemory(0x5DF340, 4, 0x8BF18B56, true)-- ������� ����� ��� ���������
                end
            end
            if GT_MOD.config.ini.effects_manager.nogunsmoke then
                writeMemory(0x4A0DE0, 4, 0x0010C2, true) -- ��������� ��� ��� ��������
            else
                if fnc ~= "all" then
                    writeMemory(0x4A0DE0, 4, 0xB6F03CA1, true) -- �������� ��� ��� ��������
                end
            end
            if GT_MOD.config.ini.effects_manager.nofxsystem then
                memory.fill(0x4A125D, 0x90, 8, true) -- 8B 4E 08 E8 47 91 00 00  FxSystem_c::Play(void)
            else
                if fnc ~= "all" then
                    functions.hex2bin('8B4E08E88B900000', 0x4A125D, 8) --FxSystem_c::Play(void)
                end
            end
            if GT_MOD.config.ini.effects_manager.noblood then
                memory.fill(0x49EB23, 0x90, 2, true)-- blood particle
            else
                if fnc ~= "all" then
                    functions.hex2bin('EB05', 0x49EB23, 2)-- blood particle
                end
            end
            if GT_MOD.config.ini.effects_manager.swim then
                memory.write(0x68AA70, 0x0004C2, 4, true) -- process swim effects ped
                memory.write(0x6C399F+1, 0, 4, true)--addsplashparticles
                memory.write(0x6C3606+1, 0, 4, true)-- ����� ��� ������
                memory.write(0x4A1144, 0x0004C2, 4, true)-- ������ ���� ����� � �� ��������
                memory.write(0x4A10D4, 0x0004C2, 4, true)-- water_splash
                memory.write(0x4A11B4, 0x0004C2, 4, true)

                writeMemory(0x6DD130, 4, 0x0004C2, true)-- boat splash ������ ���� �� ������� ����������
                writeMemory(0x6ED9A0, 4, 0xC3, true)--����� �� ������� ����������
            else
                if fnc ~= "all" then
                    memory.write(0x68AA70, -1587216534, 4, true)
                    memory.write(0x6C399F+1, 1053609165, 4, true)
                    memory.write(0x6C3606+1, 1045220557, 4, true)
                    memory.write(0x4A1144, 9603048, 4, true)-- ������ ���� ����� � �� ��������
                    memory.write(0x4A10D4, 9631720, 4, true)-- water_splash
                    memory.write(0x4A11B4, 9574376, 4, true)

                    writeMemory(0x6DD130, 4, 0x80EC81, true)-- boat splash ������ ���� �� ������� ����������
                    writeMemory(0x6ED9A0, 4, 0x83EC8B55, true)--����� �� ������� ����������
                end
            end
            if GT_MOD.config.ini.effects_manager.noexhaust then
                memory.fill(0x6AB344, 0x90, 5, true)
                memory.fill(0x6BD3FF, 0x90, 5, true)
            else
                if fnc ~= "all" then
                    functions.hex2bin("E8F72E0300", 0x6AB344, 5)-- ��� �� ���� ����������
                    functions.hex2bin("E83C0E0200", 0x6BD3FF, 5)
                end
            end

            if GT_MOD.config.ini.effects_manager.noSmokeCplane then
                writeMemory(0x6CBEFE+1, 4, 0, true)--disable cplane smoke 
            else
                if fnc ~= "all" then
                    writeMemory(0x6CBEFE+1, 4, 0x3E4CCCCD, true)--disable cplane smoke 
                end
            end
            if GT_MOD.config.ini.effects_manager.wheelsand then
                writeMemory(0x4A06F5+1, 4, 0, true) -- ����� �� ��� �����
                memory.write(0x4A0630, 0x9090, 2, true)-- �����
            else
                if fnc ~= "all" then
                    writeMemory(0x4A0AA0+1, 4, 0x3F800000, true) -- ���� �� ��� �����
                    memory.write(0x4A0630, 0x05EB, 2, true)-- �����
                end
            end
            if GT_MOD.config.ini.effects_manager.wheeldust then
                writeMemory(0x6DEF50+1, 4, 0, true) -- ���� �� ��� �����
                memory.write(0x4A09E0, 0x9090, 2, true)-- ����
            else
                if fnc ~= "all" then
                    writeMemory(0x6DEF50+1, 4, 0x9A99993E, true) -- ���� �� ��� �����
                    memory.write(0x4A09E0, 0x05EB, 2, true)-- ����
                end
            end
            if GT_MOD.config.ini.effects_manager.wheelmud then
                writeMemory(0x4A0003+1, 4, 0, true) -- ����� �� ��� �����
                writeMemory(0x4A04A3+1, 4, 0, true) -- ����� �� ��� ����� x2
                memory.write(0x4A040E, 0x9090, 2, true) -- �����
            else
                if fnc ~= "all" then
                    writeMemory(0x4A0003+1, 4, 0x3F800000, true) -- ����� �� ��� �����
                    writeMemory(0x4A04A3+1, 4, 0x3F800000, true) -- ����� �� ��� ����� x2
                    memory.write(0x4A040E, 0x05EB, 2, true) -- �����
                end
            end
            if GT_MOD.config.ini.effects_manager.wheelgravel then
                writeMemory(0x4A0253+1, 4, 0, true) -- ������ �� ��� �����
                memory.write(0x4A01BE, 0x9090, 2, true) -- ������
            else
                if fnc ~= "all" then
                    writeMemory(0x4A0253+1, 4, 0x3F800000, true) -- ������ �� ��� �����
                    memory.write(0x4A01BE, 0x05EB, 2, true) -- ������
                end
            end
            if GT_MOD.config.ini.effects_manager.wheelgrass then
                memory.write(0x49FF6E, 0x9090, 2, true) -- �����
            else
                if fnc ~= "all" then
                    memory.write(0x49FF6E, 0x05EB, 2, true) -- �����
                end
            end
            if GT_MOD.config.ini.effects_manager.wheelspray then
                memory.write(0x49FB50, 0x9090, 2, true) -- ���
                writeMemory(0x6DF1C3+1, 4, 0, true) -- ��� �� ��� �����
                writeMemory(0x6DF1BE+1, 4, 0, true) -- ��� �� ��� �����
                writeMemory(0x6DED24+1, 4, 0, true) -- ��� ��� ������, W+S
                writeMemory(0x6DED1A+1, 4, 0, true)
            else
                if fnc ~= "all" then
                    memory.write(0x49FB50, 0x05EB, 2, true) -- ���
                    writeMemory(0x6DF1C3+1, 4, 0x3F800000, true) -- ��� �� ��� �����
                    writeMemory(0x6DF1BE+1, 4, 0x3F000000, true) -- ��� �� ��� �����
                    writeMemory(0x6DED24+1, 4, 0x3F333333, true) -- ��� ��� ������, W+S
                    writeMemory(0x6DED1A+1, 4, 0x3E99999A, true)
                end
            end
            if GT_MOD.config.ini.effects_manager.vehsparks then
                functions.memory_setfloat(0xCB0870, -99.9, true) -- ����� ��� ��������� ����������
                memory.write(0x5458DA+2, 0xCB0870, 4, true)
            else
                if fnc ~= "all" then
                    functions.memory_setfloat(0xCB0870, 0.0000118509, true) -- ����� ��� ��������� ����������
                    memory.write(0x5458DA+2, 0xCB0870, 4, true)
                end
            end
            if GT_MOD.config.ini.effects_manager.vehdust then
                writeMemory(0x6C9FAF+1, 4, 0, true)-- ���� ��� ������ �� ���������� ����������� plane
                writeMemory(0x6C55F4+1, 4, 0, true)--���� ��� ������ �� ���������� ����������� heli
            else
                if fnc ~= "all" then
                    writeMemory(0x6C9FAF+1, 4, 0x40000000, true)-- ���� ��� ������ �� ���������� ����������� plane
                    writeMemory(0x6C55F4+1, 4, 0x3F800000, true)--���� ��� ������ �� ���������� ����������� heli
                end
            end
            if GT_MOD.config.ini.effects_manager.vehdmgdust then
                writeMemory(0x6A6E93+1, 4, 0, true)--���� ��� ������������ ���������� � ���������
            else
                if fnc ~= "all" then
                    writeMemory(0x6A6E93+1, 4, 0x3DCCCCCD, true)--���� ��� ������������ ���������� � ���������
                end
            end
            if GT_MOD.config.ini.effects_manager.footdust then
                writeMemory(0x5E3811+1, 4, 0, true)--foot dust
                writeMemory(0x5458E0+1, 4, 0, true)
            else
                if fnc ~= "all" then
                    writeMemory(0x5E3811+1, 4, 0x3E19999A, true)--foot dust
                    writeMemory(0x5458E0+1, 4, 0x3DCCCCCD, true)
                end
            end
            if GT_MOD.config.ini.effects_manager.nodust then
                writeMemory(0x49F57D+1, 4, 0, true) -- ���� ��� �������� � �����
                writeMemory(0x49F49D+1, 4, 0, true) -- ���� ��� ������������ ���� � ������������, �����, ������ � �.�
            else
                if fnc ~= "all" then
                    writeMemory(0x49F57D+1, 4, 0x3ECCCCCD, true) -- ���� ��� �������� � �����
                    writeMemory(0x49F49D+1, 4, 0x3D99999A, true) -- ���� ��� ������������ ���� � ������������, �����, ������ � �.�
                end
            end
            if GT_MOD.config.ini.effects_manager.gunshell then
                writeMemory(0x73A40A, 2, 0x9090, true)--������
            else
                if fnc ~= "all" then
                    writeMemory(0x73A40A, 2, 0x0375, true)--������
                end
            end
            if GT_MOD.config.ini.effects_manager.teargas then
                writeMemory(0x00872BF0, 1, 0xC3, false)
            else
                if fnc ~= "all" then
                    writeMemory(0x00872BF0, 1, 0x74, false)
                end
            end
            if GT_MOD.config.ini.effects_manager.footprints then
                writeMemory(0x005E559C+1, 4, -1, true)-- ����� ��� �� ����� (footprints in the sand)
            else
                if fnc ~= "all" then
                    writeMemory(0x005E559C+1, 4, 0x40800000, true)-- ����� ��� �� ����� (footprints in the sand)
                end
            end
            if GT_MOD.config.ini.effects_manager.vehdmgsmoke then
                writeMemory(0x6D2A80, 4, 0xC3, true)--smoke dmg vehicles
            else
                if fnc ~= "all" then
                    writeMemory(0x6D2A80, 4, 0x5618EC83, true)--smoke dmg vehicles
                end
            end
            if GT_MOD.config.ini.effects_manager.vehtaxilight then
                memory.write(12697552, 0, 1, true)--��������� �������� ����� �����
            else
                if fnc ~= "all" then
                    memory.write(12697552, 1, 1, true)--�������� �������� ����� �����
                end
            end
            --checkboxes.vehtaxilight[0] = GT_MOD.config.ini.effects_manager.vehtaxilight
    end
    if fnc == "ShowHUD" or fnc == "all" then
        if preset["Other"]["showhud"] then
            displayHud(false)
            memory.setint8(0xBA676C, 2)
        else
            if fnc ~= "all" then
                displayHud(true)
                memory.setint8(0xBA676C, 0)
            end
        end
	end
    if fnc == "ScreenOptions" or fnc == "all" then
        if GT_MOD.config.ini.settings.aspectratio_status then
            writeMemory(0xFCFAED, 4, representFloatAsInt(GT_MOD.config.ini.settings.aspectratio, false))
            writeMemory(0x6FF43F+2, 4, 0xFCFAED, false)
            writeMemory(0x6FF43D, 2, 0x9090, false)
        else
            writeMemory(0x6FF43F+2, 4, 0x008595F0, false)
        end


    end
    if fnc == "ShowCHAT" or fnc == "all" then
        if functions.get_samp_version() == "r1" then
            if preset["Other"]["showchat"] then
                memory.write(sampBase() + 0x7140F, 1, 1, true)
                sampSetChatDisplayMode(0)
            else
                memory.write(sampBase() + 0x7140F, 0, 1, true)
                sampSetChatDisplayMode(3)
            end
        elseif functions.get_samp_version() == "r3" then
            if preset["Other"]["showchat"] then
                memory.write(sampBase() + 0x752FF, 1, 1, true)
                sampSetChatDisplayMode(0)
            else
                memory.write(sampBase() + 0x752FF, 0, 1, true)
                sampSetChatDisplayMode(3)
            end
        end
	end
    if fnc == "ShowHP" or fnc == "all" then
        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.showhp then
                memory.setint16(sampBase() + 0x6FC30, 0xC390, true)
            else
                memory.setint16(sampBase() + 0x6FC30, 0x8B55, true)
            end
        elseif functions.get_samp_version() == "r3" then 
            if GT_MOD.config.ini.settings.showhp then
                memory.setint16(sampBase() + 0x73B20, 0xC390, true)
            else
                memory.setint16(sampBase() + 0x73B20, 0x8B55, true)
            end
        end
	end
    if fnc == "ShowNICKS" or fnc == "all" then
        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.shownicks then
                memory.setint16(sampBase() + 0x70D40, 0xC390, true)
            else
                memory.setint16(sampBase() + 0x70D40, 0x8B55, true)
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.shownicks then
                memory.setint16(sampBase() + 0x74C30, 0xC390, true)
            else
                memory.setint16(sampBase() + 0x74C30, 0x8B55, true)
            end
        end
	end
    if fnc == "InteriorRun" or fnc == "all" then
        if GT_MOD.config.ini.settings.intrun then
            memory.write(5630064, -1027591322, 4, true)
            memory.write(5630068, 4, 2, true)
        else
            memory.write(5630064, 69485707, 4, true)
            memory.write(5630068, 1165, 2, true)
        end
        --checkboxes.intrun[0] = GT_MOD.config.ini.settings.intrun
	end
    if fnc == "FixWaterQuadro" or fnc == "all" then
        if GT_MOD.config.ini.settings.waterfixquadro then
            functions.memory_setfloat(13101856, 0.0, true)
            memory.write(7249056, 13101856, 4, true)
            memory.write(7249115, 13101856, 4, true)
            memory.write(7249175, 13101856, 4, true)
            memory.write(7249235, 13101856, 4, true)
        else
            memory.write(7249056, 8752012, 4, true)
            memory.write(7249115, 8752012, 4, true)
            memory.write(7249175, 8752012, 4, true)
            memory.write(7249235, 8752012, 4, true)
        end
        --checkboxes.waterfixquadro[0] = GT_MOD.config.ini.settings.waterfixquadro
	end
    if fnc == "FixLongArm" or fnc == "all" then
        if GT_MOD.config.ini.settings.longarmfix then
            memory.write(7045634, 33807, 2, true)
            memory.write(7046489, 33807, 2, true)
        else
            memory.write(7045634, 59792, 2, true)
            memory.write(7046489, 59792, 2, true)
        end
        --checkboxes.longarmfix[0] = GT_MOD.config.ini.settings.longarmfix
	end
    if fnc == "FixBlackRoads" or fnc == "all" then
        if GT_MOD.config.ini.settings.fixblackroads then
            memory.write(8931716, 0, 4, true)
        else
            memory.write(8931716, 2, 4, true)
        end
        --checkboxes.fixblackroads[0] = GT_MOD.config.ini.settings.fixblackroads
	end
    if fnc == "AudioStream" or fnc == "all" then
        if functions.get_samp_version() == "r1" then
            if GT_MOD.config.ini.settings.audiostream then
                memory.write(sampBase() + 104848, 9449, 2, true)-- �������� ����������
            else
                memory.write(sampBase() + 104848, 50064, 2, true)-- ��������� ����������
            end
        elseif functions.get_samp_version() == "r3" then
            if GT_MOD.config.ini.settings.audiostream then
                memory.write(sampBase() + 0x661F3, 14708, 2, true)-- �������� ����������
            else
                memory.write(sampBase() + 0x661F3, 50064, 2, true)-- ��������� ����������
            end
        end
	end
    if fnc == "InteriorMusic" or fnc == "all" then
        if GT_MOD.config.ini.settings.intmusic then
            memory.write(5276752, -591647351, 4, true)
            memory.write(5276756, 182, 2, true)
            memory.write(5277719, -591647351, 4, true)
            memory.write(5277723, 182, 2, true)
        else
            memory.fill(5276752, 144, 6, true)
            memory.fill(5277719, 144, 6, true)
        end
	end
    if fnc == "NoSounds" or fnc == "all" then
        if GT_MOD.config.ini.settings.sounds then
            callFunction(0x507440, 0, 0)
            writeMemory(0x4D89DB, 4, 0x498D03EB, true)--on sounds 
        else
            callFunction(0x507430, 0, 0)
            writeMemory(0x4D89DB, 4, 0x3B1E9, true)--off sounds
            local bs = RakLuaBitStream.new()
            bs:emulIncomingRPC(42)
        end
    end
    if fnc == "NoRadio" or fnc == "all" then
        if GT_MOD.config.ini.settings.noradio then
            memory.write(5159328, -1947628715, 4, true)
        else
            memory.write(5159328, -1962933054, 4, true)
        end
	end
    if fnc == "BlockSampKeys" or fnc == "all" then

        
        if GT_MOD.config.ini.nop_samp_keys.key_PgUp_PgDn then
            writeMemory(sampBase() + (( functions.get_samp_version() == "r1") and 0x63700 or 0x66B50), 1, 0xC3, true)
        else
            if fnc ~= "all" then
                writeMemory(sampBase() + (( functions.get_samp_version() == "r1") and 0x63700 or 0x66B50), 1, 0x56, true)
            end
        end

       
        if GT_MOD.config.ini.nop_samp_keys.key_F4 then
            memory.setint8(sampBase() + (( functions.get_samp_version() == "r1") and 0x797E or 0x79A4), 0, true)
        else
            if fnc ~= "all" then
                memory.setint8(sampBase() + (( functions.get_samp_version() == "r1") and 0x797E or 0x79A4), 115, true)
            end
        end

        if GT_MOD.config.ini.nop_samp_keys.key_F7 then
            memory.fill(sampBase() + (( functions.get_samp_version() == "r1") and 0x5D8AD or 0x60C4D), 0xC3, 1, true)
        else
            if fnc ~= "all" then
                memory.write(sampBase() + (( functions.get_samp_version() == "r1") and 0x5D8AD or 0x60C4D), 0x8B, 1, true)
            end
        end
        if GT_MOD.config.ini.nop_samp_keys.key_T then
            memory.setint8(sampBase() + (( functions.get_samp_version() == "r1") and 0x5DB04 or 0x60EA4), 0xC3, true)
            memory.setint8(sampBase() + (( functions.get_samp_version() == "r1") and 0x5DAFA or 0x60E9A), 0xC3, true)
        else
            if fnc ~= "all" then
                memory.setint8(sampBase() + (( functions.get_samp_version() == "r1") and 0x5DB04 or 0x60EA4), 0x852F7574, true)
                memory.setint8(sampBase() + (( functions.get_samp_version() == "r1") and 0x5DAFA or 0x60E9A), 0x900A7490, true)
            end
        end
	end

    if fnc == "SunFix" or fnc == "all" then
        if GT_MOD.config.ini.settings.sunfix then
            functions.hex2bin("E865041C00", 0x53C136, 5)
        else
            memory.fill(0x53C136, 0x90, 5, true)
        end
        --checkboxes.sunfix[0] = GT_MOD.config.ini.settings.sunfix
    end

    if fnc == "SizeSunAndMoon" or fnc == "all" then
        if GT_MOD.config.ini.settings.SizeSunAndMoon then
            
            local SunSize = 0xFDC000+0xFFFFF

            writeMemory(SunSize, 4, representFloatAsInt(GT_MOD.config.ini.settings.SizeSun), true) --0-100 - ������ ������
            writeMemory(0x6FC654+2, 4, SunSize, true)
            writeMemory(0x6FC6E0+2, 4, SunSize, true)
            

            local MoonSize = 0xFDC000+0xFFFFF+0x10

            writeMemory(MoonSize, 4, GT_MOD.config.ini.settings.MoonSize, true) -- -1 - 7 ������ ����
            writeMemory(0x713C8D+2, 4, MoonSize, true)

            writeMemory(0xDDFAEC, 4, representFloatAsInt(GT_MOD.config.ini.settings.MoonHeight), true)
            writeMemory(0x713AA6+2, 4, 0xDDFAEC, true) -- ������ ����

        else
            functions.hex2bin("DCC4B700", 0x6FC654+2, 4)
            functions.hex2bin("DCC4B700", 0x6FC6E0+2, 4)
            functions.hex2bin("604B8D00", 0x713C8D+2, 4)
            functions.hex2bin("488B8500", 0x713AA6+2, 4)
        end
    end

    if fnc == "VehicleNames" or fnc == "all" then
        if preset["Other"]["vehiclenames"] then
            functions.hex2bin("E8B2B2FFFF", 0x58FBE9, 5) --return draw vehicle names
        else
            functions.hex2bin("9090909090", 0x58FBE9, 5) --return draw vehicle names
        end
    end

    if fnc == "AreaNames" or fnc == "all" then
        if preset["Other"]["areanames"] then
            functions.hex2bin('E876FEFFFF', 0x5720A5, 5)
            writeMemory(0x58D540, 1, 0x74, true)
        else
            functions.hex2bin('9090909090', 0x5720A5, 5)
        end
    end

    if fnc == "SettingsAreaNames" or fnc == "all" then
        --[AREA NAMES SETTINGS]
        if preset["Other"]["areanames"] then
            local Height = 0xFD039C+0xC30123
            local Width = 0xFD039C+0xC30128
            writeMemory(0x58AD24+2, 4, Height, true)
            writeMemory(0x58AD3A+2, 4, Width, true)

            local posX = 0xFD039C+0xC30135
            local posY = 0xFD039C+0xC30140
            writeMemory(0x58AE50+2, 4, posX, true)
            writeMemory(0x58AE38+2, 4, posY, true)

            writeMemory(Height, 4, representFloatAsInt(0.002232143 * preset["Other"]["areanamesSize"]), true)
            writeMemory(Width, 4, representFloatAsInt(0.0015625 * preset["Other"]["areanamesSize"]), true)

            writeMemory(posX, 4, representFloatAsInt(preset["Other"]["areanamesPosX"]), true)--posx 32
            writeMemory(posY, 4, representFloatAsInt(preset["Other"]["areanamesPosY"]), true)--posY 76

            writeMemory(0xBAB1D4, 4, 0, true)-- ����� _ZN4CHud15m_pLastZoneNameE
        end
    end

    if fnc == "SettingsVehicleNames" or fnc == "all" then
        --[VEHICLE NAMES SETTINGS]
        if preset["Other"]["vehiclenames"] then
            local HeightV = 0xFD039C+0xC30160
            local WidthV = 0xFD039C+0xC30168
            writeMemory(0x58B089+2, 4, HeightV, true) -- 1.5
            writeMemory(0x58B09F+2, 4, WidthV, true) -- 0.0015625

            writeMemory(HeightV, 4, representFloatAsInt(0.002232143 * preset["Other"]["vehiclenamesSize"]), true)
            writeMemory(WidthV, 4, representFloatAsInt(0.0015625 * preset["Other"]["vehiclenamesSize"]), true)

            local posXv = 0xFD039C+0xC30190
            local posYv = 0xFD039C+0xC30195
            writeMemory(0x58B147+2, 4, posXv, true)
            writeMemory(0x58B133+2, 4, posYv, true)

            writeMemory(posXv, 4, representFloatAsInt(preset["Other"]["vehiclenamesPosX"]), true)--posx 32
            writeMemory(posYv, 4, representFloatAsInt(preset["Other"]["vehiclenamesPosY"]), true)--posY 104
        end

        writeMemory(0xBAA454, 4, 0, true)-- ����� _ZN4CHud18m_pLastVehicleNameE

    end

    if fnc == "Reflections" or fnc == "all" then
        if GT_MOD.config.ini.settings.reflections then
            writeMemory(0xC7C724, 4, 0, true)
            memory.fill(0x555854, 0x90, 5, true) --InterioRreflections
        else
            functions.hex2bin('E897151D00', 0x555854, 5)
            writeMemory(0x7230C6, 2, 0x9090, true)--nop call    _ZN4Fx_c12GetFxQualityEv
        end
    end

    if fnc == "TargetBlip" or fnc == "all" then
        if GT_MOD.config.ini.settings.targetblip then
            memory.write(5497324, 116, 1, true)
        else
            memory.write(5497324, 235, 1, true)
        end
    end
    if fnc == "CleanMemory" then
       
        
        -- ������� ������� ������ �������
        local function cleanOldTimestamps()
            local currentTime = os.clock()
            for i = #cleanMemoryTimestamps, 1, -1 do
                if currentTime - cleanMemoryTimestamps[i] > 1 then
                    table.remove(cleanMemoryTimestamps, i)
                end
            end
        end
    
        -- �������� ������� ������� ������
        local safeClean = function()
            if isCleaning then return end -- ���� ��� ��� �������, ���������� ����� �����
    
            isCleaning = true
            local oldram = ("%d"):format(tonumber(get_memory()))
            
            -- ����� ������� � ������������ �����
            local success, err = pcall(function()
                callFunction(0x53C500, 1, 1, 1, 1)
                --callFunction(0x40D7C0, 1, 1, -1) --restream
                callFunction(0x53C810, 1, 1, 1)
                callFunction(0x40CF80, 0, 0)
                callFunction(0x4090A0, 0, 0)
                callFunction(0x5A18B0, 0, 0)
                callFunction(0x707770, 0, 0)
                callFunction(0x40CFD0, 0, 0)
            end)
    
            isCleaning = false -- ���������� ���� ����� ���������� �������
    
            if not success then
                functions.AddNotify(script_name .. "{FF0000} ������ ��� ������� ������: " .. err, 3000, 560)
                return
            end
    
            local newram = ("%d"):format(tonumber(get_memory()))
            if GT_MOD.config.ini.cleaner.cleaninfo then
                functions.AddNotify(script_name .. "{FFFFFF} ������ ��: {dc4747}" .. oldram .. " ��. {FFFFFF}������ �����: {dc4747}" .. newram .. " ��. {FFFFFF}�������: {dc4747}" .. (oldram - newram) .. " ��. {FFFFFF}�����: {dc4747}"..tonumber(GT_MOD.config.ini.cleaner.limit).." ��.", 3000, 560)
            end
        end
    
        -- �������� ������� �������
        local currentTime = os.clock()
        table.insert(cleanMemoryTimestamps, currentTime)
        cleanOldTimestamps()
    
        if #cleanMemoryTimestamps > 2 then
            -- ���� ������� ����� 2 �� �������, ��������� restream
            if not isCleaning then
                --callFunction(0x40D7C0, 1, 1, -1) -- restream
            end
            
            -- ������� �������������� �� ����, ��� ��� � 10 ������
            if currentTime - lastWarningTime >= 10 then
                functions.AddNotify(script_name .. "{FFFFFF} ������� ������� ������ ���������� ������� �����. {dc4747}��������, ���� ����� �������. ��������� ��������!", 5000, 560)
                lastWarningTime = currentTime -- ��������� ����� ���������� �����������
            end
        else
            -- ����� ���������� �������, ���� ��� ����������
            pcall(safeClean)
        end
    end
    
    
    
    
    if fnc == "ForceAniso" or fnc == "all" then
        if GT_MOD.config.ini.settings.forceaniso then
            if readMemory(0x730F9C, 1, true) ~= 0 then
                writeMemory(0x730F9C, 1, 0, true)
            end
        else
            if readMemory(0x730F9C, 1, true) ~= 1 then
                writeMemory(0x730F9C, 1, 1, true)
            end
        end
        --checkboxes.forceaniso[0] = GT_MOD.config.ini.settings.forceaniso
    end
    if fnc == "SetBrightness" or fnc == "all" then
        if GT_MOD.config.ini.settings.givemebrightness then

            memory.setint32(0xBA6784, GT_MOD.config.ini.settings.brightness, true)
            local brightness = ffi.cast("float", readMemory(0xBA6784, 4, true) * 0.001953100)
            local CGamma__setGamma = ffi.cast("char (__thiscall*)(void*, float, char)", 0x747200)
            CGamma__setGamma(ffi.cast("void*", 0xC92134), brightness, true)

        end
    end
    if fnc == "SetDistNickNames" then
        if GT_MOD.config.ini.settings.givemedistnames then
            if tonumber(GT_MOD.config.ini.settings.nickdistance) > tonumber(functions.memory_getfloat(0xFFFC90, true)) then
                functions.memory_setfloat(sampGetServerSettingsPtr() + 39, functions.memory_getfloat(0xFFFC90, true), true)
            else
                functions.memory_setfloat(sampGetServerSettingsPtr() + 39, GT_MOD.config.ini.settings.nickdistance)
            end
           
        else
            functions.memory_setfloat(sampGetServerSettingsPtr() + 39, functions.memory_getfloat(0xFFFC90, true), true)
        end
       
    end

    if fnc == "SetDistObjects" or fnc == "all" then
        local obj_list = {
            stolbs_and_fonars = {
                [1] = { id = 1283, sdist = 85 },
                [2] = { id = 1262, sdist = 45 },
                [3] = { id = 3516, sdist = 85 },
                [4] = { id = 3855, sdist = 50 },
                [5] = { id = 1278, sdist = 150 },
                [6] = { id = 1290, sdist = 150 },
                [7] = { id = 1307, sdist = 100 },
                [8] = { id = 1308, sdist = 100 },
                [9] = { id = 3459, sdist = 100 },
                [10] = { id = 3463, sdist = 62 },
                [11] = { id = 3503, sdist = 50 },
                [12] = { id = 3854, sdist = 100 },
                [13] = { id = 1226, sdist = 62 },
                [14] = { id = 1223, sdist = 53 },
                [15] = { id = 1231, sdist = 55 },
                [16] = { id = 1232, sdist = 55 },
                [17] = { id = 1284, sdist = 85 },
                [18] = { id = 1294, sdist = 55 },
                [19] = { id = 1315, sdist = 64 },
                [20] = { id = 1350, sdist = 60 },
                [21] = { id = 3853, sdist = 62 },
                [22] = { id = 3875, sdist = 100 },
                [23] = { id = 3460, sdist = 62 },
                [24] = { id = 1297, sdist = 59 },
            },
            musor = {
                [1] = { id = 1265, sdist = 45 },
                [2] = { id = 1440, sdist = 50 },
                [3] = { id = 1230, sdist = 40 },
                [4] = { id = 1438, sdist = 50 },
                [5] = { id = 1220, sdist = 40 },
                [6] = { id = 1221, sdist = 40 },
                [7] = { id = 1264, sdist = 45 },
                [8] = { id = 1224, sdist = 41 },
                [9] = { id = 910, sdist = 30 },
                [10] = { id = 926, sdist = 30 },
                [11] = { id = 928, sdist = 30 },
                [12] = { id = 1372, sdist = 70 },
                [13] = { id = 1357, sdist = 60 },
                [14] = { id = 3594, sdist = 80 },
                [15] = { id = 3593, sdist = 80 },
                [16] = { id = 955, sdist = 30 },
                [17] = { id = 760, sdist = 50 },
                [18] = { id = 682, sdist = 80 },
                [19] = { id = 17592, sdist = 80 },
                [20] = { id = 1415, sdist = 50 },
            },
        }
    
        if GT_MOD.config.ini.settings.givemedistobj then
            for k, v in pairs(obj_list.stolbs_and_fonars) do
                functions.memory_setfloat(getMDO(obj_list.stolbs_and_fonars[k]["id"]), GT_MOD.config.ini.settings.distobjects_stolb_fonars, true)
            end
            for k, v in pairs(obj_list.musor) do
                functions.memory_setfloat(getMDO(obj_list.musor[k]["id"]), GT_MOD.config.ini.settings.distobjects_musor, true)
            end

            for k, v in pairs(objdists) do
                if v ~= nil then
                    local id_obj = v:match("^(%d+).-$")
                    local dist_obj = v:match("^.-([-+]?%d+)$")

                    functions.memory_setfloat(getMDO(tonumber(id_obj)), tonumber(dist_obj), true)
                end
            end

        else
            for k, v in pairs(obj_list.stolbs_and_fonars) do
                functions.memory_setfloat(getMDO(obj_list.stolbs_and_fonars[k]["id"]), obj_list.stolbs_and_fonars[k]["sdist"], true)
            end
            for k, v in pairs(obj_list.musor) do
                functions.memory_setfloat(getMDO(obj_list.musor[k]["id"]), obj_list.musor[k]["sdist"], true)
            end
        end
    end
    if fnc == "MenuImage" or fnc == "all" then
        if preset["MenuPause"]["fullmenuimage"] then
            functions.memory_setfloat(0x57B7EF, preset["MenuPause"]["fullmenuwidth"], true)--��������� �������
            functions.memory_setfloat(0x57B80B, preset["MenuPause"]["fullmenuheight"]-25, true)--������
            functions.memory_setfloat(0x57B852, preset["MenuPause"]["fullmenuwidth"]+3, true)--���������
            functions.memory_setfloat(0x57B862, preset["MenuPause"]["fullmenuheight"]-25, true)--���������
            functions.memory_setfloat(0x57B877, 320, true)--��
            functions.memory_setfloat(0x57B88F, 320.0, true)--��������� �����
            functions.memory_setfloat(0x57B8BD, preset["MenuPause"]["fullmenuwidth"]+3.0, true)--����������
            functions.memory_setfloat(0x57B8D5, preset["MenuPause"]["fullmenuheight"]-25, true)--����������
            functions.memory_setfloat(0x57B917, preset["MenuPause"]["fullmenuwidth"]+3.0, true)--main menu
            functions.memory_setfloat(0x57B927, preset["MenuPause"]["fullmenuheight"]-25, true)--main menu

            writeMemory(0x57B8A8+1, 4, representFloatAsInt(448), true)--��������
          
        else
            functions.memory_setfloat(0x57B7EF, 256.0, true)
            functions.memory_setfloat(0x57B80B, 256.0, true)
            functions.memory_setfloat(0x57B852, 256.0, true)
            functions.memory_setfloat(0x57B862, 256.0, true)
            functions.memory_setfloat(0x57B877, 128.0, true)
            functions.memory_setfloat(0x57B88F, 128.0, true)
            functions.memory_setfloat(0x57B8A9, 256.0, true)
            functions.memory_setfloat(0x57B8BD, 256.0, true)
            functions.memory_setfloat(0x57B8D5, 256.0, true)
            functions.memory_setfloat(0x57B917, 300.0, true)
            functions.memory_setfloat(0x57B927, 200.0, true)
        end
    end
    if fnc == "FixBloodWood" or fnc == "all" then
        if GT_MOD.config.ini.settings.fixbloodwood then
            writeMemory(0x49EE63+1, 4, 0, true)--fix blood wood
        else
            writeMemory(0x49EE63+1, 4, 0x3F800000, true)--fix blood wood
        end
    end
    if fnc == "EditCrosshair" or fnc == "all" then
        if preset["Crosshair"]["nocrosshaireditsize"] then
            writeMemory(0x609D80, 2, 0x9090, true)
        else
            writeMemory(0x609D80, 2, 0x087A, true)
        end
        writeMemory(0xCADEDE+1083, 4, representFloatAsInt(preset["Crosshair"]["crosshairSizeX"]), true)
        writeMemory(0xCADEDE+1088, 4, representFloatAsInt(preset["Crosshair"]["crosshairSizeY"]), true)
        writeMemory(0x58E307,4, 0xCADEDE+1083, true)
        writeMemory(0x58E321,4, 0xCADEDE+1088, true)
    end
    if fnc == "SetDistLodVeh" or fnc == "all" then
        functions.memory_setfloat(0xCB0900, GT_MOD.config.ini.settings.vehloddist, true)
        memory.write(0x732924+2, 0xCB0900, 4, true)
    end
    if fnc == "HelpText" or fnc == "all" then
        if preset["MenuPause"]["helptext"] then
            memory.fill(0x57E3AE, 0x90, 5, true)-- ���������
        else
             functions.hex2bin("E86DC41900", 0x57E3AE, 5)
        end
    end
    if fnc == "BeginMenu" or fnc == "all" then
        if preset["MenuPause"]["beginmenu"] then
            memory.fill(0x579698, 0x90, 5, true)
        else
            functions.hex2bin("E863101A00", 0x579698, 5)
        end
    end
    if fnc == "TreePitching" or fnc == "all" then
        if GT_MOD.config.ini.settings.treepitching then
            memory.fill(0x535030, 0x90, 5, true) -- disable wind effects
        else
            functions.hex2bin("E8DBB82B00", 0x535030, 5)
        end
    end
    if fnc == "OvalityCorrection" or fnc == "all" then
        writeMemory(0x70CEEF, 1, GT_MOD.config.ini.settings.ovalityCorrection and 1 or 0, true)-- ������ ���� � ������ ����� ��� ������ ���� �������.
    end

    if fnc == "SwimFix" or fnc == "all" then
        
        local prog = tcc.cdef[[
            #include <windows.h>
            #include <stdint.h>
            #include <lua.h>

            void swimFixLogic(uintptr_t esp) {
                float pCTimer__ms_fTimeStep = *(float*)0xB7CB5C;
                float magic = 1.0f / (pCTimer__ms_fTimeStep / (50.0f / 30.0f));

                *(float*)(esp + 0x18) *= magic * 1.11;
                *(float*)(esp + 0x1C) *= magic * 1.11;
                *(float*)(esp + 0x20) *= magic * 1.11;
            }

            void __naked swimFix() {    
                asm(R"(
                    push %eax
                    push %ecx
                    push %edx
                    mov %esp, %eax
                    add $0xC, %eax
                    push %eax
                    call swimFixLogic
                    add $4, %esp
                    pop %edx
                    pop %ecx
                    pop %eax
                    fld    %st(1)
                    fmuls  (%eax)
                    fld    %st(2)
                    jmp 0x0068A514
                )");
            }

            void installHook() {
                uintptr_t hook_addr = 0x68A50E;

                DWORD oldProt;
                
                VirtualProtect((void*)hook_addr, 6, PAGE_EXECUTE_READWRITE, &oldProt);
                *(uint8_t*)hook_addr = 0xE9;
                *(uintptr_t*)(hook_addr + 1) = (uintptr_t)&swimFix - hook_addr - 5;
                *(uint8_t*)(hook_addr + 5) = 0x90;
                VirtualProtect((void*)hook_addr, 6, oldProt, NULL);
            }

            void removeHook() {
                uintptr_t hook_addr = 0x68A50E;
                DWORD oldProt;
                
                VirtualProtect((void*)hook_addr, 6, PAGE_EXECUTE_READWRITE, &oldProt);
                uint8_t originalBytes[] = {0xD9, 0xC1, 0xD8, 0x08, 0xD9, 0xC2};
                memcpy((void*)hook_addr, originalBytes, sizeof(originalBytes));
                VirtualProtect((void*)hook_addr, 6, oldProt, NULL);
            }
        ]]

        local s = tcc.new()
        s:compile_string(prog)
        
        s:relocate()
        ffi.gc(s, nil)

        local AcceptSwimFix = s:get_symbol("installHook", "void(*)()")
        local removeSwimFix = s:get_symbol("removeHook", "void(*)()")

        if GT_MOD.config.ini.settings.swimFix then
            AcceptSwimFix()
        else
            removeSwimFix()
        end
    end



    if fnc == "SwingingFix" or fnc == "all" then
        if GT_MOD.config.ini.settings.swingingfix then
            writeMemory(0x6AC0F0, 2, 0x9090, true)--0x0575
        else
            if fnc ~= "all" then
                writeMemory(0x6AC0F0, 2, 0x0575, true)--0x0575
            end
        end

    end

    
    if fnc == "ReturnGrass" or fnc == "all" then
        lua_thread.create(function()
            if GT_MOD.config.ini.settings.returnGrass then
                --callFunction(0x5DD910, 0, 0)--call init
                functions.hex2bin("E8420E0A00", 0x53C159, 5)
       
                --writeMemory(m_pCols(747), 1, GT_MOD.config.ini.settings.CollGrass and 0 or 80, true)--������� ������� � ������� ����� �� grass.asi
           
            else
                if fnc ~= "all" then
                    --callFunction(0x5DB940, 0, 0)--call shutd
                    functions.hex2bin("9090909090", 0x53C159, 5)
                end
            end
        end)
    
    end

    if fnc == "FixUnderBridgeForRain" or fnc == "all" then
        if GT_MOD.config.ini.settings.FixUnderBridgeForRain then
            writeMemory(0x72DDC0+1, 4, 0x8CC2D7, true)--0xC87AB8
            writeMemory(0x72DDB0+1, 4, 0x8CC2D7, true)--0xC87ABC
        else
            if fnc ~= "all" then
                writeMemory(0x72DDC0+1, 4, 0xC87AB8, true)--0xC87AB8
                writeMemory(0x72DDB0+1, 4, 0xC87ABC, true)--0xC87ABC
            end
        end
    end

    if fnc == "Refreshrate" then
        if GT_MOD.config.ini.settings.refreshratefix then
            if not doesFileExist(getGameDirectory().."/_CoreGame.asi") then
                local success, maxRefreshRate = pcall(getMaxRefreshRate)
                if success then
                    writeMemory(0xC9C040+0x30, 4, maxRefreshRate, true)

     

                    --print("RefreshRate: "..maxRefreshRate)
                end
            end
        end
    end

    if fnc == "UgenrlMode" or fnc == "all" then
        if GT_MOD.config.ini.ugenrl_main.enable then
            if GT_MOD.config.ini.ugenrl_main.mode == 0 then
                functions.hex2bin("752D", 0x503D34, 2)
                callFunction(0x507430, 0, 0)
                writeMemory(0x4D89DB, 4, 0x3B1E9, true)--off sounds
                
                local bs = RakLuaBitStream.new()
                bs:emulIncomingRPC(42)
                writeMemory(0x5030D0, 1, 0xC3, true)
            elseif GT_MOD.config.ini.ugenrl_main.mode == 1 then
                memory.fill(0x503D34, 0x90, 2, true)
                writeMemory(0x4D89DB, 4, 0x498D03EB, true)--on sounds
                callFunction(0x507430, 0, 0)
            elseif GT_MOD.config.ini.ugenrl_main.mode == 2 then
                functions.hex2bin("752D", 0x503D34, 2)
                writeMemory(0x4D89DB, 4, 0x498D03EB, true)--on sounds
                callFunction(0x507430, 0, 0)
            end
        end
    end
    
    if fnc == "Recolorer" or fnc == "all" then
            if preset["Recolorer"]["Recolorer"] then
                
                local function convert_color(value)
                    local a, r, g, b = functions.explode_argb(value)
                    return tonumber(("0xFF%06X"):format(functions.join_argb(0, b, g, r)))  -- ��������� ����� �������� � ������� ABGR � ������������� �����-�������
                end
                
                memory.write(0xBAB22C, convert_color(preset["Recolorer"]["Health"]), 4, false)
                memory.write(0xBAB230, convert_color(preset["Recolorer"]["Money"]), 4, false)
                memory.write(0xBAB244, convert_color(preset["Recolorer"]["Stars"]), 4, false)
                memory.write(0xBAB23C, convert_color(preset["Recolorer"]["Armor"]), 4, false)
                memory.write(0xBAB238, convert_color(preset["Recolorer"]["Patrons"]), 4, false)

                memory.write(sampBase() + (( functions.get_samp_version() == "r1") and 0x68B0C or 0x6CA7C), preset["Recolorer"]["PlayerHealth"], 4, true)
                memory.write(sampBase() + (( functions.get_samp_version() == "r1") and 0x68B33 or 0x6CAA3), preset["Recolorer"]["PlayerHealth2"], 4, true)

                memory.write(sampBase() + (( functions.get_samp_version() == "r1") and 0x68DD5 or 0x6CD45), preset["Recolorer"]["PlayerArmor"], 4, true)
                memory.write(sampBase() + (( functions.get_samp_version() == "r1") and 0x68E00 or 0x6CD70), preset["Recolorer"]["PlayerArmor2"], 4, true)

            
            else
                if fnc ~= "all" then
                    writeMemory(0xBAB22C, 4, -14870092, true)
                    writeMemory(0xBAB230, 4, -13866954, true)
                    writeMemory(0xBAB244, 4, -15703408, true)
                    writeMemory(0xBAB23C, 4, -1973791, true)
                    writeMemory(0xBAB238, 4, -930900, true)

                    writeMemory(sampBase() + (( functions.get_samp_version() == "r1") and 0x68B0C or 0x6CA7C), 4, -2088157, true)
                    writeMemory(sampBase() + (( functions.get_samp_version() == "r1") and 0x68B33 or 0x6CAA3), 4, -2109489, true)
                end
            end
    end



    if fnc == "PatchDuck" or fnc == "all" then
        if GT_MOD.config.ini.settings.patchduck then
            writeMemory(0x692649+1, 1, 6, true)--patch anim duck
        else
            writeMemory(0x692649+1, 1, 8, true)--patch anim duck
        end
    end
    if fnc == "AntiCrash" or fnc == "all" then
        if GT_MOD.config.ini.settings.anticrash then
            if functions.get_samp_version() == "r1" then
                local base = sampBase() + 0x5CF2C
                writeMemory(base, 4, 0x90909090, true)
                base = base + 4
                writeMemory(base, 1, 0x90, true)
                base = base + 9
                writeMemory(base, 4, 0x90909090, true)
                base = base + 4
                writeMemory(base, 1, 0x90, true)
            elseif functions.get_samp_version() == "r3" then
                local base = sampBase() + 0x602CC
                writeMemory(base, 4, 0x90909090, true)
                base = base + 4
                writeMemory(base, 1, 0x90, true)
                base = base + 9
                writeMemory(base, 4, 0x90909090, true)
                base = base + 4
                writeMemory(base, 1, 0x90, true)
            end
        end
    end
    if fnc == "FixArrowPassMotoBike" or fnc == "all" then
        if GT_MOD.config.ini.settings.FixArrowPassMotoBike then
            memory.fill(0x6B795F, 0x90, 20, true)
        else
            if fnc ~= "all" then
                functions.hex2bin("0F84FF0200008B866404000085C00F85F1020000", 0x6B795F, 20)
            end
        end
    end
    if fnc == "InterfaceElementEditor" or fnc == "all" then
        writeMemory(0xEDDFAF, 4, representFloatAsInt(preset["MenuPause"]["speedinputsmap"]), true)
        local MapOptionInputs = {
            [1] = 0x577679+2, [2] = 0x5779A8+2,
            [3] = 0x577E70+2, [4] = 0x578320+2,
            [5] = 0x5784B5+2, [6] = 0x578650+2
        }
        for i = 1, #MapOptionInputs do
            writeMemory(MapOptionInputs[i], 4, 0xEDDFAF, true)
        end

        if preset["MenuPause"]["mapzoom"] then
            functions.memory_setfloat(5719357, tonumber(preset["MenuPause"]["mapzoomvalue"]), true)
        else
            functions.memory_setfloat(5719357, 1000.0, true)
        end

        if preset["MenuPause"]["arrowicon_menu"] then
            writeMemory(0x57A5B7, 4, 0x00, true)
        else
            writeMemory(0x57A5B7, 4, 0xFF, true)--disable arrow menu icon left
        end

        writeMemory(0x5799AC+1, 1, preset["MenuPause"]["fontmenubasestyle"], true) -- ����� ��������� ������ ����
        writeMemory(0x573F6D+1, 1, preset["MenuPause"]["fontmenubasestyle"], true) -- ����� ��������� ������ ����
        writeMemory(0x57958A+1, 1, preset["MenuPause"]["fontmenuheaderstyle"], true) -- ����� ������ ��������� ����
        writeMemory(0x57A20A+1, 1, preset["MenuPause"]["fontmenutumblerstyle"], true) -- ����� ������ ��������� � ����



        if preset["MenuPause"]["gxtEntryEditor"] then
            local RusToGame = function(text)
                local convtbl = {[230]=155,[231]=159,[247]=164,[234]=107,[250]=144,[251]=168,[254]=171,[253]=170,[255]=172,[224]=97,[240]=112,[241]=99,[226]=162,[228]=154,[225]=151,[227]=153,[248]=165,[243]=121,[184]=101,[235]=158,[238]=111,[245]=120,[233]=157,[242]=166,[239]=163,[244]=63,[237]=174,[229]=101,[246]=160,[236]=175,[232]=156,[249]=161,[252]=169,[215]=141,[202]=75,[204]=77,[220]=146,[221]=147,[222]=148,[192]=65,[193]=128,[209]=67,[194]=139,[195]=130,[197]=69,[206]=79,[213]=88,[168]=69,[223]=149,[207]=140,[203]=135,[201]=133,[199]=136,[196]=131,[208]=80,[200]=133,[198]=132,[210]=143,[211]=89,[216]=142,[212]=129,[214]=137,[205]=72,[217]=138,[218]=167,[219]=145}
                local result = {}
                for i = 1, #text do
                    local c = text:byte(i)
                    result[i] = string.char(convtbl[c] or c)
                end
                return table.concat(result)
            end
            
            local beginText = preset["MenuPause"]["useMynameInBeginMenu"] and sampGetPlayerNickname(select(2, sampGetPlayerIdByCharHandle(PLAYER_PED))) or preset["MenuPause"]["beginText"]
            setGxtEntry("FET_PAU", RusToGame(beginText))
            setGxtEntry("FEP_RES", RusToGame(preset["MenuPause"]["resume"]))
            setGxtEntry("FEH_SGA", RusToGame(preset["MenuPause"]["start_new_game"]))
            setGxtEntry("FEH_MAP", RusToGame(preset["MenuPause"]["map"]))
            setGxtEntry("FEP_STA", RusToGame(preset["MenuPause"]["stats"]))
            setGxtEntry("FEH_BRI", RusToGame(preset["MenuPause"]["brief"]))
            setGxtEntry("FEP_OPT", RusToGame(preset["MenuPause"]["settings"]))
            setGxtEntry("FEP_QUI", RusToGame(preset["MenuPause"]["quitGame"]))
        end
        

        local sizeiconmap = {
            [1] = { mem = 0x586047, nmem = 0xCB0650, val = preset["Radar"]["osnov_icon"], sval = 8.0 }, --������
            [2] = { mem = 0x586060, nmem = 0xCB0655, val = preset["Radar"]["osnov_icon"], sval = 8.0 }, --������
            [3] = { mem = 0x584192, nmem = 0xCB0665, val = 0.0015625 / preset["Radar"]["quadro_icon_size"], sval = 0.0015625 }, -- X  ���������� ������
            [4] = { mem = 0x5841B2, nmem = 0xCB0670, val = 0.00203125 / preset["Radar"]["quadro_icon_size"], sval = 0.00203125 }, -- Y ���������� ������
            [5] = { mem = 0x58410D, nmem = 0xCB0675, val = 0.0016471354 / preset["Radar"]["quadro_icon_border"], sval = 0.0016471354}, -- ������� X ���������� ������
            [6] = { mem = 0x58412D, nmem = 0xCB0680, val = 0.00214843762 / preset["Radar"]["quadro_icon_border"], sval = 0.00214843762}, -- ������� Y ���������� ������
            [7] = { mem = 0x5842E8, nmem = 0xCB0685, val = 0.0015625 / preset["Radar"]["trianglen_icon_size"], sval = 0.0015625 }, -- ����������� ������ ���� X
            [8] = { mem = 0x5842C8, nmem = 0xCB0690, val = 0.00203125 / preset["Radar"]["trianglen_icon_size"], sval = 0.00203125 }, -- ����������� ������ ���� Y
            [9] = { mem = 0x58424B, nmem = 0xCB0695, val = 0.0016471354 / preset["Radar"]["trianglen_icon_border"], sval = 0.0016471354}, -- ������� X ����������� ������ ����
            [10] = { mem = 0x584209, nmem = 0xCB0700, val = 0.00214843762 / preset["Radar"]["trianglen_icon_border"], sval = 0.00214843762}, -- ������� Y ����������� ������ ����
            [11] = { mem = 0x584436, nmem = 0xCB0705, val = 0.0015625 / preset["Radar"]["trianglev_icon_size"], sval = 0.0015625 }, -- ����������� ������ ����� X
            [12] = { mem = 0x58440E, nmem = 0xCB0710, val = 0.00203125 / preset["Radar"]["trianglev_icon_size"], sval = 0.00203125}, -- ����������� ������ ����� Y
            [13] = { mem = 0x58439E, nmem = 0xCB0715, val = 0.0016471354 / preset["Radar"]["trianglev_icon_border"], sval = 0.0016471354}, -- ����������� ������ �����  ������� X
            [14] = { mem = 0x584348, nmem = 0xCB0720, val = 0.00214843762 / preset["Radar"]["trianglev_icon_border"], sval = 0.00214843762}, -- ����������� ������ �����  ������� Y
            [15] = { mem = 0x5886DC, nmem = 0xCB0725, val = preset["Radar"]["player_icon_size"], sval = 8.0 }, --����� �� �����
            [16] = { mem = 0x584A02, nmem = 0xCB0730, val = preset["Radar"]["arrowmap_size"], sval = 25.0 }, --������ arrow X 25 std
            [17] = { mem = 0x584A1A, nmem = 0xCB0735, val = preset["Radar"]["arrowmap_size"], sval = 25.0 }, --������ arrow Y 25 std
        }
        if preset["Radar"]["smalliconsradar"] then
            for i = 1, #sizeiconmap do
                functions.memory_setfloat(sizeiconmap[i]["nmem"], sizeiconmap[i]["val"], true)-- ����� �������� � ��������� ������
                memory.write(sizeiconmap[i]["mem"], sizeiconmap[i]["nmem"], 4, true)--��������� �� ��������� ������
            end
        else
            for i = 1, #sizeiconmap do
                functions.memory_setfloat(sizeiconmap[i]["nmem"], sizeiconmap[i]["sval"], true)-- ����� �������� � ��������� ������
                memory.write(sizeiconmap[i]["mem"], sizeiconmap[i]["nmem"], 4, true)--��������� �� ��������� ������
            end
        end

        if preset["Radar"]["radrarnorth"] then
            memory.fill(0x588188, 0x90, 5, true)
        else
            functions.hex2bin('E863DEFFFF', 0x588188, 5)
        end

        if preset["Money"]["fontmoneystyle"] ~= 3 then
            writeMemory(0x58F52D+1, 1, 1, true)
        else
            writeMemory(0x58F52D+1, 1, 0, true)
        end
        writeMemory(0x58F57E+1, 1, preset["Money"]["fontmoneystyle"], true)

        writeMemory(0x58F58D, 1, preset["Money"]["fontmoneyborder"], true)

        if preset["Money"]["animmoney"] == 0 then
            memory.write(5707667, 138, 1, true)
        elseif preset["Money"]["animmoney"] == 1 then
            memory.write(5707667, 137, 1, true)
        elseif preset["Money"]["animmoney"] == 2 then
            memory.write(5707667, 139, 1, true)
        end

        if preset["Money"]["moneyzerofix"] then
            if preset["Money"]["posdollar"] == 0 then
                -- ���� ������� �����
                memory.copy(0x866C94, memory.strptr('$%d'), 6, true)
                memory.copy(0x866C8C, memory.strptr('$-%d'), 6, true)
            else
                -- ���� ������� ������
                memory.copy(0x866C94, memory.strptr('%d$'), 6, true)
                memory.copy(0x866C8C, memory.strptr('%d-$'), 6, true)
            end
        else
            if preset["Money"]["posdollar"] == 0 then
                -- ���� ������� ����� � ������

                memory.copy(0x866C94, memory.strptr('$%08d'), 6, true)
                memory.copy(0x866C8C, memory.strptr('-$%08d'), 6, true)
            else
                -- ���� ������� ������ � ������
                memory.copy(0x866C94, memory.strptr('%08d$'), 6, true)
                memory.copy(0x866C8C, memory.strptr('%08d-$'), 6, true)
            end
        end
        
        
        
        if preset["Patrons"]["EditPatrons"] then
            functions.memory_setfloat(0xCF1010, preset["Patrons"]["posPatronsX"], true) -- pos patrons x 47.0
            memory.write(0x58FA10 + 2, 0xCF1010, 4, true) -- pos patrons x 47.0

            functions.memory_setfloat(0xCF1035, preset["Patrons"]["posPatronsY"], true) -- pos patrons Y 43.0
            memory.write(0x58F9E4+2, 0xCF1035, 4, true)

            functions.memory_setfloat(0xCF1230, preset["Patrons"]["sizePatronsX"], true) -- ������ ������ 0.30000001
            memory.write(0x5894CB+2, 0xCF1230, 4, true)

            functions.memory_setfloat(0xCF2125, preset["Patrons"]["sizePatronsY"], true) -- ������ ������ 0.7
            memory.write(0x5894B5+2, 0xCF2125, 4, true)
            

            if preset["Patrons"]["renderammo"] then
                writeMemory(0x589477, 2, 0x5150, true)
            else
                writeMemory(0x589477, 2, 0x5051, true)
            end

            if preset["Patrons"]["singleclip"] then
                writeMemory(0x5893DF, 4, 0x90909090, true)
            else
                writeMemory(0x5893DF, 4, 0x2040BF0F, true)
            end

            if preset["Patrons"]["EternalPatrons"] then
                writeMemory(0x5895EB, 2, 0x9090, true)
                memory.fill(0x589591, 0x90, 6, true)
                
            else
                writeMemory(0x5895EB, 2, 0x557E, true)
                functions.hex2bin("0F84AB000000", 0x589591, 6)
            end
            


            writeMemory(0x58952A+1, 1, preset["Patrons"]["fontammostyle"], true)

        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1010, 47.0, true) -- pos patrons x 47.0
                memory.write(0x58FA10+2, 0xCF1010, 4, true) -- pos patrons x 47.0
    
                functions.memory_setfloat(0xCF1035, 43.0, true) -- pos patrons Y 43.0
                memory.write(0x58F9E4+2, 0xCF1035, 4, true)
    
                functions.memory_setfloat(0xCF1230, 0.30, true) -- ������ ������ 0.30000001
                memory.write(0x5894CD, 0xCF1230, 4, true)
    
                functions.memory_setfloat(0xCF2125, 0.70, true) -- ������ ������ 0.7
                memory.write(0x5894B5+2, 0xCF2125, 4, true)
                writeMemory(0x58952A+1, 1, 1, true)
                writeMemory(0x589477, 2, 0x5051, true)
            end
        end
        if preset["Health"]["EditHealth"] then

        

            if preset["Health"]["nohealthflick"] then
                writeMemory(0x589282, 2, 0x09EB, true)
                writeMemory(0x5892AD, 2, 0x09EB, true)
            else
                writeMemory(0x589282, 2, 0x0975, true)
                writeMemory(0x5892AD, 2, 0x097D, true)
            end
            


            if preset["Health"]["oneHundredAndSixtyHPbar"] then
                writeMemory(0xB793E0, 4, representFloatAsInt(915.0), true)
            else
                writeMemory(0xB793E0, 4, representFloatAsInt(569.0), true)
            end
            functions.memory_setfloat(0xCF1045, -preset["Health"]["posHealthX"], true) -- pos health bar X 141.0
            memory.write(0x58EE85+2, 0xCF1045, 4, true)
    
            functions.memory_setfloat(0xCF1050, preset["Health"]["posHealthY"], true) -- pos health bar Y 77.0
            memory.write(0x58EE66+2, 0xCF1050, 4, true)
    
            functions.memory_setfloat(0xCF1055, preset["Health"]["sizeHealthX"], true) -- ������ ������� �� 109.0
            memory.write(0x5892D8, 0xCF1055, 4, true)
    
            functions.memory_setfloat(0xCF1060, preset["Health"]["sizeHealthY"], true) -- ������ ������� �� 9.0
            memory.write(0x589358, 0xCF1060, 4, true)

            memory.write(0x589352+1, preset["Health"]["healthborder"] and 1 or 0--[[ 1 on 0 off]], 1, true) -- ������� ��������
        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1045, 141.0, true) -- pos health bar X 141.0
                memory.write(0x58EE85+2, 0xCF1045, 4, true)
        
                functions.memory_setfloat(0xCF1050, 77.0, true) -- pos health bar Y 77.0
                memory.write(0x58EE66+2, 0xCF1050, 4, true)
        
                functions.memory_setfloat(0xCF1055, 109.0, true) -- ������ ������� �� 109.0
                memory.write(0x5892D8, 0xCF1055, 4, true)
        
                functions.memory_setfloat(0xCF1060, 9.0, true) -- ������ ������� �� 9.0
                memory.write(0x589358, 0xCF1060, 4, true)
                memory.write(0x589352+1, 1--[[ 1 on 0 off]], 1, true) -- ������� ��������
            end
        end
        
        if preset["Money"]["EditMoney"] then
            
            
            functions.memory_setfloat(0xCF1105, -preset["Money"]["posMoneyX"], true) -- ������� ����� X 32.0
            memory.write(0x58F5FA+2, 0xCF1105, 4, true)
    
            functions.memory_setfloat(0xCF1110, preset["Money"]["posMoneyY"], true) -- ������� ����� Y 89.0
            memory.write(0x58F5DA+2, 0xCF1110, 4, true)
    
            functions.memory_setfloat(0xCF1115, preset["Money"]["sizeMoneyX"], true) -- ������ ����� 0.55000001  
            memory.write(0x58F562+2, 0xCF1115, 4, true)
    
            functions.memory_setfloat(0xCF1120, preset["Money"]["sizeMoneyY"], true) -- ������ ����� 1.1
            memory.write(0x58F54C+2, 0xCF1120, 4, true)

           
        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1105, 32.0, true) -- ������� ����� X 32.0
                memory.write(0x58F5FA+2, 0xCF1105, 4, true)
        
                functions.memory_setfloat(0xCF1110, 89.0, true) -- ������� ����� Y 89.0
                memory.write(0x58F5DA+2, 0xCF1110, 4, true)
        
                functions.memory_setfloat(0xCF1115, 0.550, true) -- ������ ����� 0.55000001  
                memory.write(0x58F562+2, 0xCF1115, 4, true)
        
                functions.memory_setfloat(0xCF1120, 1.1, true) -- ������ ����� 1.1
                memory.write(0x58F54C+2, 0xCF1120, 4, true)
            end
        end
        
        if preset["Breath"]["EditBreath"] then
            functions.memory_setfloat(0xCF1125, -preset["Breath"]["posBreathX"], true) -- ������� ��������� X 94.0
            memory.write(0x58F11D+2, 0xCF1125, 4, true)

            functions.memory_setfloat(0xCF1130, preset["Breath"]["posBreathY"], true) -- ������� ��������� Y 62.0
            memory.write(0x58F0FE+2, 0xCF1130, 4, true)

            functions.memory_setfloat(0xCF1135, preset["Breath"]["sizeBreathX"], true) -- ������ ��������� X 62.0
            memory.write(0x589233+2, 0xCF1135, 4, true)

            functions.memory_setfloat(0xCF1140, preset["Breath"]["sizeBreathY"], true) -- ������ ��������� Y 9.0
            memory.write(0x58921C+2, 0xCF1140, 4, true)
            
            memory.write(0x589206+1, preset["Breath"]["breathborder"] and 1 or 0--[[ 1 on 0 off]], 1, true) -- ������� ���������

            writeMemory(0x58F0D9, 2, preset["Breath"]["eternalBreath"] and 0x9090 or 0x6474, true) -- ������ ��������
        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1130, 94.0, true) -- ������� ��������� X 94.0
                memory.write(0x58F11D+2, 0xCF1130, 4, true)

                functions.memory_setfloat(0xCF1135, 62.0, true) -- ������� ��������� Y 62.0
                memory.write(0x58F0FE+2, 0xCF1135, 4, true)

                functions.memory_setfloat(0xCF1140, 9.0, true) -- ������ ��������� Y 9.0
                memory.write(0x58921C+2, 0xCF1140, 4, true)
            end
        end
        
        if preset["Armor"]["EditArmor"] then

            if preset["Armor"]["eternalArmor"] then
                memory.fill(0x5890DC, 0x90, 6, true)
            else
                if fnc ~= "all" then
                    functions.hex2bin("0F85A1000000", 0x5890DC, 6)
                end
            end

           

            functions.memory_setfloat(0xCF1145, -preset["Armor"]["posArmorX"], true) -- ������� ����� X 94.0
            memory.write(0x58EF57+2, 0xCF1145, 4, true)

            functions.memory_setfloat(0xCF1150, preset["Armor"]["posArmorY"], true) -- ������� ����� Y 48.0
            memory.write(0x58EF38+2, 0xCF1150, 4, true)

            functions.memory_setfloat(0xCF1155, preset["Armor"]["sizeArmorX"], true) -- ������ ����� X 62.0
            memory.write(0x58915B+2, 0xCF1155, 4, true)

            functions.memory_setfloat(0xCF1160, preset["Armor"]["sizeArmorY"], true) -- ������ ����� Y 9.0
            memory.write(0x589144+2, 0xCF1160, 4, true)

            memory.write(0x589122+1, preset["Armor"]["armorborder"] and 1 or 0--[[ 1 on 0 off]], 1, true) -- ������� �����
        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1145, 94.0, true) -- ������� ����� X 94.0
                memory.write(0x58EF57+2, 0xCF1145, 4, true)
    
                functions.memory_setfloat(0xCF1150, 48.0, true) -- ������� ����� Y 48.0
                memory.write(0x58EF38+2, 0xCF1150, 4, true)

                functions.memory_setfloat(0xCF1155, 62.0, true) -- ������ ����� X 62.0
                memory.write(0x58915B+2, 0xCF1155, 4, true)

                functions.memory_setfloat(0xCF1160, 9.0, true) -- ������ ����� Y 9.0
                memory.write(0x589144+2, 0xCF1160, 4, true)
            end
        end
        
        if preset["Weapon"]["EditWeapon"] then
            functions.memory_setfloat(0xCF1000, preset["Weapon"]["sizeWeaponX"], true) -- weapon icon size X 47.0
            functions.memory_setfloat(0xCF1005, preset["Weapon"]["sizeWeaponY"], true) -- weapon icon size Y 58.0
            memory.write(0x58D8C9 + 2, 0xCF1000, 4, true) -- weapon icon size X
            memory.write(0x58D894 + 2, 0xCF1005, 4, true) -- weapon icon size Y
            memory.write(0x58D933 + 2, 0xCF1000, 4, true) -- size icon fist x 47.0
            memory.write(0x58D94B + 2, 0xCF1005, 4, true) -- size icon fist y 58.0
            
            functions.memory_setfloat(0xCF1025, -preset["Weapon"]["posWeaponX"], true) -- pos weapon&fist X 32.0
            memory.write(0x58F925+2, 0xCF1025, 4, true)
    
            functions.memory_setfloat(0xCF1030, preset["Weapon"]["posWeaponY"], true) --  pos weapon&fist Y 20.0
            memory.write(0x58F911+2, 0xCF1030, 4, true)
        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1025, 32.0, true) -- pos weapon&fist X 32.0
                memory.write(0x58F925+2, 0xCF1025, 4, true)
        
                functions.memory_setfloat(0xCF1030, 20.0, true) --  pos weapon&fist Y 20.0
                memory.write(0x58F911+2, 0xCF1030, 4, true)

                functions.memory_setfloat(0xCF1000, 47.0, true) -- weapon icon size X 47.0
                functions.memory_setfloat(0xCF1005, 58.0, true) -- weapon icon size Y 58.0
                memory.write(0x58D8C9 + 2, 0xCF1000, 4, true) -- weapon icon size X
                memory.write(0x58D894 + 2, 0xCF1005, 4, true) -- weapon icon size Y
                memory.write(0x58D933 + 2, 0xCF1000, 4, true) -- size icon fist x 47.0
                memory.write(0x58D94B + 2, 0xCF1005, 4, true) -- size icon fist y 58.0


            end
        end
        
        if preset["Wanted"]["EditWanted"] then
            if preset["Wanted"]["eternalwanted"] then
                writeMemory(0x58DD1B, 2, 0x9090, true)
            else
                if fnc ~= "all" then
                    writeMemory(0x58DD1B, 2, 0x097E, true)
                end
            end

            functions.memory_setfloat(0xCAECFA, preset["Wanted"]["spaceWanted"], true)
            writeMemory(0x58DFEB+2, 4, 0xCAECFA, true)



            writeMemory(0x58DF71+2, 4, preset["Wanted"]["emptyStars"] and 0x862B41 or 0x859520, true)--�� ���������� ������ ������


            

            functions.memory_setfloat(0xCF1250, -preset["Wanted"]["posWantedX"], true) -- ������� ������� X 29.0
            memory.write(0x58DD0D+2, 0xCF1250, 4, true)

            functions.memory_setfloat(0xCF1255, preset["Wanted"]["posWantedY"], true) -- ������� ������� Y 114.0
            memory.write(0x58DDFA+2, 0xCF1255, 4, true)
            memory.write(0x58DFB1+2, 0xCF1255, 4, true)

           


            functions.memory_setfloat(0xCF1260, preset["Wanted"]["sizeWantedX"], true) -- ������ ������� X 0.60
            memory.write(0x58DD84+2, 0xCF1260, 4, true)
            memory.write(0x58DF77+2, 0xCF1260, 4, true)
            
           
            

            functions.memory_setfloat(0xCF1265, preset["Wanted"]["sizeWantedY"], true) -- ������ ������� Y 1.21
            memory.write(0x58DD6E+2, 0xCF1265, 4, true)
            memory.write(0x58DF5B+2, 0xCF1265, 4, true)

        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1250, 29.0, true) -- ������� ������� X 29.0
                memory.write(0x58DD0D+2, 0xCF1250, 4, true)

                functions.memory_setfloat(0xCF1255, 114.0, true) -- ������� ������� Y 114.0
                memory.write(0x58DDFA+2, 0xCF1255, 4, true)

                functions.memory_setfloat(0xCF1275, 12.0, true) -- ������� ������� ������� Y 12.0
                memory.write(0x58DF29+2, 0xCF1275, 4, true)
                

                functions.memory_setfloat(0xCF1260, 0.60, true) -- ������ ������� X 0.60
                memory.write(0x58DD84+2, 0xCF1260, 4, true)

                functions.memory_setfloat(0xCF1265, 1.21, true) -- ������ ������� Y 1.21
                memory.write(0x58DD6E+2, 0xCF1265, 4, true)
    
            end
        end
        
        if preset["Clock"]["EditClock"] then
            if preset["Clock"]["DrawClock"] then
                functions.hex2bin("253032643A2530326400", 0x859A6C, 10)
                functions.hex2bin("E8DABA1800", 0x58EC21, 5)
            else
                if fnc ~= "all" then
                    functions.hex2bin("00000000000000000000", 0x859A6C, 10)
                    memory.fill(0x58EC21, 0x90, 5, true)
                end
            end

            if preset["Clock"]["PcClock"] then
                writeMemory(0x58EBA9 + 1, 4, 0xCDA772, true)
            else
                if fnc ~= "all" then
                    writeMemory(0x58EBA9 + 1, 4, 0x00859A6C, true)
                end
            end

            functions.memory_setfloat(0xCF1280, -preset["Clock"]["posClockX"], true) -- ������� X 32.0
            memory.write(0x58EC14+2, 0xCF1280, 4, true)

            functions.memory_setfloat(0xCF1285, preset["Clock"]["posClockY"], true) -- ������� Y 22.0
            memory.write(0x58EC02+2, 0xCF1285, 4, true)

            functions.memory_setfloat(0xCF1290, preset["Clock"]["sizeClockY"], true) -- ������ Y 0.55
            memory.write(0x58EB2F+2, 0xCF1290, 4, true)

            functions.memory_setfloat(0xCF1295, preset["Clock"]["sizeClockX"], true) -- ������ X 1.1
            memory.write(0x58EB45+2, 0xCF1295, 4, true)


            writeMemory(0x58EB5A+1, 1, preset["Clock"]["fontstyleclock"], true)-- font style clock

            writeMemory(0x58EB6F+1, 1, preset["Clock"]["fontoutlineclock"], true)

            writeMemory(0x0058EB53+1, 1, 1, true)

    
        else
            if fnc ~= "all" then
                functions.memory_setfloat(0xCF1280, 32.0, true) -- ������� X 32.0
                memory.write(0x58EC14+2, 0xCF1280, 4, true)

                functions.memory_setfloat(0xCF1285, 22.0, true) -- ������� Y 22.0
                memory.write(0x58EC02+2, 0xCF1285, 4, true)

                functions.memory_setfloat(0xCF1290, 1.1, true) -- ������ Y 0.55
                memory.write(0x58EB2F+2, 0xCF1290, 4, true)
    
                functions.memory_setfloat(0xCF1295, 0.55, true) -- ������ X 1.1
                memory.write(0x58EB45+2, 0xCF1295, 4, true)

            end
        end


        writeMemory(0x58694E+1, 1, 1, true)-- RwEngineInstance->dOpenDevice.fpRenderStateSet(rwRENDERSTATEVERTEXALPHAENABLE, 1)
        writeMemory(0x586432+1, 1, preset["Radar"]["radaralpha"], true)
        writeMemory(0x58647B+1, 1, preset["Radar"]["radaralpha"], true)
        writeMemory(0x5864BC+1, 1, preset["Radar"]["radaralpha"], true)

        writeMemory(0x586F34+1, 1, preset["Radar"]["radarblipA"], true)

        if preset["Radar"]["radar_color_fix"] then
            memory.write(0x58A798, 255, 1, true)
            memory.write(0x58A790, 255, 1, true)
            memory.write(0x58A78E, 255, 1, true)
            memory.write(0x58A89A, 255, 1, true)
            memory.write(0x58A896, 255, 1, true)
            memory.write(0x58A894, 255, 1, true)
            memory.write(0x58A8EE, 255, 1, true)
            memory.write(0x58A8E6, 255, 1, true)
            memory.write(0x58A8DE, 255, 1, true)
            memory.write(0x58A9A2, 255, 1, true)
            memory.write(0x58A99A, 255, 1, true)
            memory.write(0x58A996, 255, 1, true)
        else
            if fnc ~= "all" then
                memory.write(0x58A798, 0, 1, true)
                memory.write(0x58A790, 0, 1, true)
                memory.write(0x58A78E, 0, 1, true)
                memory.write(0x58A89A, 0, 1, true)
                memory.write(0x58A896, 0, 1, true)
                memory.write(0x58A894, 0, 1, true)
                memory.write(0x58A8EE, 0, 1, true)
                memory.write(0x58A8E6, 0, 1, true)
                memory.write(0x58A8DE, 0, 1, true)
                memory.write(0x58A9A2, 0, 1, true)
                memory.write(0x58A99A, 0, 1, true)
                memory.write(0x58A996, 0, 1, true)
            end
        end

        if not doesFileExist(getGameDirectory().."\\__EvolveClient.asi") then

            if preset["Radar"]["radardisc"] then
                writeMemory(0x58A788+1, 1, 0, true)
                writeMemory(0x58A8D8+1, 1, 0, true)
                writeMemory(0x58A88E+1, 1, 0, true)
                writeMemory(0X58A98E+1, 1, 0, true)
            else
                if fnc ~= "all" then
    
                    writeMemory(0x58A788+1, 1, 0xFF, true)
                    writeMemory(0x58A8D8+1, 1, 0xFF, true)
                    writeMemory(0x58A88E+1, 1, 0xFF, true)
                    writeMemory(0X58A98E+1, 1, 0xFF, true)
                end
            end
        end

        
       

        if preset["Radar"]["minimapzoom"] then
            writeMemory(0x586C0A, 4, 0x90909090, true)
            writeMemory(0x586C0A+4, 1, 0x90, true)
            writeMemory(0x586C9B, 4, representFloatAsInt(preset["Radar"]["minimapzoomvalue"]), true) -- 180 | 500
        else
            if fnc ~= "all" then
                writeMemory(0x586C9B, 4, representFloatAsInt(180), true) -- 180 | 500
                writeMemory(0x586C0A, 4, 0xFE7481E8, true)
                writeMemory(0x586C0A+4, 1, 0xFF, true)
            end
        end

        if preset["Radar"]["radarfix"] then
            --fix rounded blips in radar
            local screenX = readMemory(0xC17044, 2, true)
            local screenY = readMemory(0xC17048, 2, true)
            local resolution = getScreenResolution() * 0.0015625;
            local sizeBlips = 1.0
            local constMemX = 0xFFACFF + 15
            local constMemY = 0xFFACFF + 20

            local idealX = (sizeBlips / screenX) * resolution * 1.0
            local idealY = (sizeBlips / screenY) * resolution * 1.0
            writeMemory(constMemX, 4, representFloatAsInt(idealX), false)
            writeMemory(constMemY, 4, representFloatAsInt(idealY), false)

            --[[writeMemory(0x5876D4+2, 4, constMemX, true)--Blips X
            writeMemory(0x58774B+2, 4, constMemX, true)--Blips X
            writeMemory(0x58780A+2, 4, constMemX, true)--Blips X
            writeMemory(0x58788F+2, 4, constMemX, true)--Blips X
            writeMemory(0x58792E+2, 4, constMemX, true)--Blips X
            writeMemory(0x587A1A+2, 4, constMemX, true)--Blips X
            writeMemory(0x587AAA+2, 4, constMemX, true)--Blips X]]
            writeMemory(0x58808D+2, 4, constMemX, true)--Blips X
            writeMemory(0x5886CC+2, 4, constMemX, true)--Blips X

            --[[writeMemory(0x5876BC+2, 4, constMemY, true)--Blips Y
            writeMemory(0x587733+2, 4, constMemY, true)--Blips Y
            writeMemory(0x587916+2, 4, constMemY, true)--Blips Y
            writeMemory(0x587A02+2, 4, constMemY, true)--Blips Y
            writeMemory(0x587A92+2, 4, constMemY, true)--Blips Y
            writeMemory(0x588060+2, 4, constMemY, true)--Blips Y
            writeMemory(0x588294+2, 4, constMemY, true)--Blips Y]]
            writeMemory(0x58603F+2, 4, constMemX, true)--Blips X
            writeMemory(0x586058+2, 4, constMemY, true)--Blips Y


            --=========================================
            functions.memory_setfloat(0xCAE000, preset["Radar"]["radarPosX"], true)
            local radarPosX = {
                [1] = 0x58A79B, [2] = 0x5834D4, [3] =0x58A836, [4] = 0x58A8E9, [5] = 0x58A98A,
                [6] = 0x58A469, [7] = 0x58A5E2, [8] = 0x58A6E6, [9] = 0x58A467+2,
            }
            for i = 0, #radarPosX do
                writeMemory(radarPosX[i], 4, 0xCAE000, true)
            end

            functions.memory_setfloat(0xCAE005, preset["Radar"]["radarPosY"], true)
            local radarPosY = {
                [1] = 0x58A7C7, [2] = 0x58A868, [3] = 0x58A913, [4] = 0x58A9C7, [5] = 0x583500,
                [6] = 0x58A499, [7] = 0x58A60E, [8] = 0x58A71E, [9] = 0x58A497+2,
            }
            for i = 0, #radarPosY do
                writeMemory(radarPosY[i], 4, 0xCAE005, true)
            end

            if preset["Radar"]["Type"] ~= 1 then
                functions.memory_setfloat(0xCAE010, preset["Radar"]["radarWidth"], true)
                local radarWidth = {
                    [1] = 0x58A47D, [2] = 0x58A632, [3] = 0x58A6AB, [4] = 0x58A70E, [5] = 0x58A801,
                    [6] = 0x58A8AB, [7] = 0x58A921, [8] = 0x58A9D5, [9] = 0x5834F6, [10] = 0x58A47B+2,
                }
                for i = 0, #radarWidth do
                    writeMemory(radarWidth[i], 4, 0xCAE010, true)
                end

                functions.memory_setfloat(0xCAE015, preset["Radar"]["radarHeight"], true)
                local radarHeight = {
                    [1] = 0x5834C2, [2] = 0x58A449, [3] = 0x58A7E9, [4] = 0x58A840, [5] = 0x58A943,
                    [6] = 0x58A99D, [7] = 0x58A447+2
                }
                for i = 0, #radarHeight do
                    writeMemory(radarHeight[i], 4, 0xCAE015, true)
                end

                local constMemX = 0xFFACEF
                writeMemory(constMemX, 4, representFloatAsInt(0.0015625), false)
                writeMemory(0x5834BC, 4, constMemX, false)
                writeMemory(0x58A443, 4, constMemX, false)
                writeMemory(0x58A5DA, 4, constMemX, false)
                writeMemory(0x58A6E0, 4, constMemX, false)
                writeMemory(0x58A793, 4, constMemX, false)
                writeMemory(0x58A830, 4, constMemX, false)
                writeMemory(0x58A8E1, 4, constMemX, false)
                writeMemory(0x58A984, 4, constMemX, false)
                writeMemory(0x58A984, 4, constMemX, false)

                local constMemY = 0xFFACEF + 5
                writeMemory(constMemY, 4, representFloatAsInt(0.002232143), false)
                writeMemory(0x5834EC+2, 4, constMemY, false)
                writeMemory(0x58A473+2, 4, constMemY, false)
                writeMemory(0x58A600+2, 4, constMemY, false)
                writeMemory(0x58A69E+2, 4, constMemY, false)
                writeMemory(0x58A704+2, 4, constMemY, false)
                writeMemory(0x58A7B9+2, 4, constMemY, false)
                writeMemory(0x58A85A+2, 4, constMemY, false)
                writeMemory(0x58A909+2, 4, constMemY, false)
                writeMemory(0x58A9BD+2, 4, constMemY, false)
                writeMemory(0x58A9BD+2, 4, constMemY, false)
                --=====================================================================================
            end
            if preset["Radar"]["Type"] == 2 then
                writeMemory(0x58585A, 4, 0x40180DD8, true)
            else
                writeMemory(0x58585A, 4, 0x8F1C0DD8, true)
            end

            if preset["Radar"]["Type"] == 1 then
                local screenX, screenY = getScreenResolution()
                local resolution = getScreenResolution() * 0.0015625;

                --================================ [ Radar ] ============================================

                local idealX = (preset["Radar"]["roundedRadarSize"] / screenX) * resolution * 0.8
                local constMemX = 0xFFACEF
                writeMemory(constMemX, 4, representFloatAsInt(idealX), false)
                writeMemory(0x5834BC, 4, constMemX, false)
                writeMemory(0x58A443, 4, constMemX, false)
                writeMemory(0x58A5DA, 4, constMemX, false)
                writeMemory(0x58A6E0, 4, constMemX, false)
                writeMemory(0x58A793, 4, constMemX, false)
                writeMemory(0x58A830, 4, constMemX, false)
                writeMemory(0x58A8E1, 4, constMemX, false)
                writeMemory(0x58A984, 4, constMemX, false)
                writeMemory(0x58A984, 4, constMemX, false)

                local constMemY = 0xFFACEF + 5
                local idealY = (preset["Radar"]["roundedRadarSize"] / screenY) * resolution * 1
                writeMemory(constMemY, 4, representFloatAsInt(idealY), false)
                writeMemory(0x5834EC+2, 4, constMemY, false)
                writeMemory(0x58A473+2, 4, constMemY, false)
                writeMemory(0x58A600+2, 4, constMemY, false)
                writeMemory(0x58A69E+2, 4, constMemY, false)
                writeMemory(0x58A704+2, 4, constMemY, false)
                writeMemory(0x58A7B9+2, 4, constMemY, false)
                writeMemory(0x58A85A+2, 4, constMemY, false)
                writeMemory(0x58A909+2, 4, constMemY, false)
                writeMemory(0x58A9BD+2, 4, constMemY, false)
                writeMemory(0x58A9BD+2, 4, constMemY, false)
                --=====================================================================================

                functions.memory_setfloat(0xCAE010, 76.0, true)
                local radarWidth = {
                    [1] = 0x58A47D, [2] = 0x58A632, [3] = 0x58A6AB, [4] = 0x58A70E, [5] = 0x58A801,
                    [6] = 0x58A8AB, [7] = 0x58A921, [8] = 0x58A9D5, [9] = 0x5834F6, [10] = 0x58A47B+2,
                }
                for i = 0, #radarWidth do
                    writeMemory(radarWidth[i], 4, 0xCAE010, true)
                end

                functions.memory_setfloat(0xCAE015, 94.0, true)
                local radarHeight = {
                    [1] = 0x5834C2, [2] = 0x58A449, [3] = 0x58A7E9, [4] = 0x58A840, [5] = 0x58A943,
                    [6] = 0x58A99D, [7] = 0x58A447+2
                }
                for i = 0, #radarHeight do
                    writeMemory(radarHeight[i], 4, 0xCAE015, true)
                end

            end
        

        else
            if fnc ~= "all" then

                functions.memory_setfloat(0xCAE000, 40.0, true)
                local radarPosX = {
                    [1] = 0x58A79B, [2] = 0x5834D4, [3] = 0x58A836, [4] = 0x58A8E9, [5] = 0x58A98A,
                    [6] = 0x58A469, [7] = 0x58A5E2, [8] = 0x58A6E6, [9] = 0x58A467+2,
                }
                for i = 0, #radarPosX do
                    writeMemory(radarPosX[i], 4, 0xCAE000, true)
                end

                functions.memory_setfloat(0xCAE005, 104.0, true)
                local radarPosY = {
                    [1] = 0x58A7C7, [2] = 0x58A868, [3] = 0x58A913, [4] = 0x58A9C7, [5] = 0x583500,
                    [6] = 0x58A499, [7] = 0x58A60E, [8] = 0x58A71E, [9] = 0x58A497+2,
                }
                for i = 0, #radarPosY do
                    writeMemory(radarPosY[i], 4, 0xCAE005, true)
                end

                functions.memory_setfloat(0xCAE010, 76.0, true)
                local radarWidth = {
                    [1] = 0x58A47D, [2] = 0x58A632, [3] = 0x58A6AB, [4] = 0x58A70E, [5] = 0x58A801,
                    [6] = 0x58A8AB, [7] = 0x58A921, [8] = 0x58A9D5, [9] = 0x5834F6, [10] = 0x58A47B+2,
                }
                for i = 0, #radarWidth do
                    writeMemory(radarWidth[i], 4, 0xCAE010, true)
                end

                functions.memory_setfloat(0xCAE015, 94.0, true)
                local radarHeight = {
                    [1] = 0x5834C2, [2] = 0x58A449, [3] = 0x58A7E9, [4] = 0x58A840, [5] = 0x58A943,
                    [6] = 0x58A99D, [7] = 0x58A447+2
                }
                for i = 0, #radarHeight do
                    writeMemory(radarHeight[i], 4, 0xCAE015, true)
                end
    
            end
        end
        --checkboxes.radarfix[0] = preset["Radar"]["radarfix"]
    end

    if fnc == "FixTimecyc" or fnc == "all" then
       
        if GT_MOD.config.ini.fixtimecyc.active then
            memory.write(6359759, 144, 1, false)
            memory.write(6359760, 144, 1, false)
            memory.write(6359761, 144, 1, false)
            memory.write(6359762, 144, 1, false)
            memory.write(6359763, 144, 1, false)
            memory.write(6359764, 144, 1, false)

            memory.write(6359778, 144, 1, false)
            memory.write(6359779, 144, 1, false)
            memory.write(6359780, 144, 1, false)
            memory.write(6359781, 144, 1, false)
            memory.write(6359782, 144, 1, false)
            memory.write(6359783, 144, 1, false)
            memory.write(6359784, 144, 1, false)
            memory.write(6359785, 144, 1, false)
            memory.write(6359786, 144, 1, false)
            memory.write(6359787, 144, 1, false)
            
            memory.write(5637016, 12044024, 4, false)
            memory.write(5637032, 12044024, 4, false)
            memory.write(5637048, 12044024, 4, false)
            memory.write(5636920, 12044048, 4, false)
            memory.write(5636936, 12044072, 4, false)
            memory.write(5636952, 12044096, 4, false)

            functions.memory_setfloat(12044024, GT_MOD.config.ini.fixtimecyc.objambient, false)
            functions.memory_setfloat(9228384, GT_MOD.config.ini.fixtimecyc.allambient, false)
        
            functions.memory_setfloat(12044048, GT_MOD.config.ini.fixtimecyc.worldambientR, false)
            functions.memory_setfloat(12044072, GT_MOD.config.ini.fixtimecyc.worldambientG, false)
            functions.memory_setfloat(12044096, GT_MOD.config.ini.fixtimecyc.worldambientB, false)

        
        else
            if fnc ~= "all" then
                memory.write(6359759, 217, 1, false)
                memory.write(6359760, 21, 1, false)
                memory.write(6359761, 96, 1, false)
                memory.write(6359762, 208, 1, false)
                memory.write(6359763, 140, 1, false)
                memory.write(6359764, 0, 1, false)
                memory.write(6359778, 199, 1, false)
                memory.write(6359779, 5, 1, false)
                memory.write(6359780, 96, 1, false)
                memory.write(6359781, 208, 1, false)
                memory.write(6359782, 140, 1, false)
                memory.write(6359783, 0, 1, false)
                memory.write(6359784, 0, 1, false)
                memory.write(6359785, 0, 1, false)
                memory.write(6359786, 128, 1, false)
                memory.write(6359787, 63, 1, false)
                memory.write(5637016, 12043448, 4, false)
                memory.write(5637032, 12043452, 4, false)
                memory.write(5637048, 12043456, 4, false)
                memory.write(5636920, 12043424, 4, false)
                memory.write(5636936, 12043428, 4, false)
                memory.write(5636952, 12043432, 4, false)
            end
        end
    end

    if fnc == "InputFixEX" then
        if not FixedInput then
            if functions.get_samp_version() == "r1" then

                
                local offsets = {
                    {val = 231612, key = 12345},
                    {val = 231616, key = 12345},
                    {val = 231874, key = 67890},
                    {val = 231878, key = 67890},
                    {val = 241439, key = 54321},
                    {val = 241443, key = 54321}
                }
                
                local function dbuff(offset)
                    return ((offset.val + offset.key) - offset.key) * 1
                end
                
                for i, offset in ipairs(offsets) do
                    local addr = sampBase() + dbuff(offset)
                    if i == 1 or i == 3 or i == 5 then
                        local values = {0xFFEBCFE8, 0xFFEAC9E8, 0xFFC56CE8}
                        writeMemory(addr, 4, values[math.ceil(i/2)], true)
                    else
                        writeMemory(addr, 1, 0xFF, true)
                    end
                end
                
                FixedInput = true
            end
        end
    end


    if fnc == "StaticLight" or fnc == "all" then
        
        --local brValue = GT_MOD.config.ini.effects_manager.postfx and 1.2 or 0.3
        writeMemory(0xFF7377, 4, representFloatAsInt(GT_MOD.config.ini.settings.staticLightBrightness), true)
        if GT_MOD.config.ini.settings.staticLight then
            writeMemory(0x5603B6+2, 4, 0xFF7377, true)
            writeMemory(0x560396+2, 4, 0xFF7377, true)
            writeMemory(0x5603A6+2, 4, 0xFF7377, true)
        else
            if fnc ~= "all" then
                writeMemory(0x5603B6+2, 4, 0xB7C4C0, true)
                writeMemory(0x560396+2, 4, 0xB7C4B8, true)
                writeMemory(0x5603A6+2, 4, 0xB7C4BC, true)
            end
        end
    end
    
end


return functions


end