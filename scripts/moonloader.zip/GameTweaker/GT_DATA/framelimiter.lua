return function(GT_MOD)
    local framelimiter = {} -- module

    local checkboxes, sliders, buffers = GT_MOD.UI.checkboxes, GT_MOD.UI.sliders, GT_MOD.UI.buffers

    local FPSManager = {}
    FPSManager.__index = FPSManager

    function FPSManager.new(config)
        local self = setmetatable({}, FPSManager)
        self.config = config
        self.currentFPS = -1
        self.lastVehicleType = nil
        self.lastWeapon = nil
        self.lastState = nil
        
        -- �������� ����� ������������ �������
        self.funcs = {
            isPauseMenuActive = isPauseMenuActive,
            isCharOnFoot = isCharOnFoot,
            isCharSwimming = isCharSwimming,
            getCurrentCharWeapon = getCurrentCharWeapon,
            isCharInAnyHeli = isCharInAnyHeli,
            isCharInAnyPlane = isCharInAnyPlane,
            isCharInAnyCar = isCharInAnyCar,
            isCharInAnyBoat = isCharInAnyBoat,
            isCharSittingInAnyCar = isCharSittingInAnyCar,
            storeCarCharIsInNoSave = storeCarCharIsInNoSave,
            getCarModel = getCarModel
        }
        
        -- ��� ������� ����������
        self.vehicleTypes = {
            moto = {[461] = true, [462] = true, [463] = true, [468] = true, 
                   [521] = true, [522] = true, [523] = true, [581] = true, [586] = true},
            bike = {[481] = true, [509] = true, [510] = true}
        }
        
        return self
    end

    function FPSManager:isCharInAnyMotoBike(handle)
        local vehicle = self.funcs.storeCarCharIsInNoSave(handle)
        if vehicle == 0 then return false end
        local modelid = self.funcs.getCarModel(vehicle)
        return self.vehicleTypes.moto[modelid] or false
    end

    function FPSManager:isCharInAnyBike(handle)
        local vehicle = self.funcs.storeCarCharIsInNoSave(handle)
        if vehicle == 0 then return false end
        local modelid = self.funcs.getCarModel(vehicle)
        return self.vehicleTypes.bike[modelid] or false
    end

    function FPSManager:getCurrentState()
        local f = self.funcs
        
        if f.isPauseMenuActive() then
            return 'pause', 500
        end
        
        if f.isCharSwimming(PLAYER_PED) then
            return 'swim', self.config.smart_fps.swimfps
        end
        
        if f.isCharInAnyHeli(PLAYER_PED) then
            return 'heli', self.config.smart_fps.helifps
        end
        
        if f.isCharInAnyPlane(PLAYER_PED) then
            return 'plane', self.config.smart_fps.planefps
        end
        
        if f.isCharInAnyBoat(PLAYER_PED) then
            return 'boat', self.config.smart_fps.boatfps
        end
        
        if f.isCharInAnyCar(PLAYER_PED) then
            if self:isCharInAnyMotoBike(PLAYER_PED) then
                return 'moto', self.config.smart_fps.motofps
            elseif self:isCharInAnyBike(PLAYER_PED) then
                return 'bike', self.config.smart_fps.bikefps
            else
                return 'vehicle', self.config.smart_fps.vehfps
            end
        end
        
        if f.isCharOnFoot(PLAYER_PED) then
            local weapon = f.getCurrentCharWeapon(PLAYER_PED)
            if weapon == 34 then
                return 'sniper', self.config.smart_fps.snipergunfps
            elseif weapon == 41 then
                return 'spray', self.config.smart_fps.spraygunfps
            else
                return 'foot', self.config.smart_fps.pedfps
            end
        end
        
        return 'unknown', self.currentFPS
    end

    function FPSManager:updateFPS()
        if not self.config.settings.framelimiter then
            return
        end
        
        local newState, newFPS = self:getCurrentState()
        
        -- ��������� ������ ��� ��������� ���������
        if newState ~= self.lastState or newFPS ~= self.currentFPS then
            self.lastState = newState
            self.currentFPS = newFPS
            return newFPS
        end
        
        return nil
    end

    -- �������������� ��������
    local fpsManager = FPSManager.new(GT_MOD.config.ini)


    function setFPSvalue()
        local newFPS = fpsManager:updateFPS()
        if newFPS then
            TARGET_FRAMERATE = newFPS
        end
    end


    local imgui = require("mimgui")
    local ffi = require("ffi")
    local encoding = require("encoding")
    encoding.default = "CP1251"
    local u8 = encoding.UTF8
    local kernel32 = ffi.load("kernel32")

    ffi.cdef[[
        typedef long long INT64;
        typedef union _LARGE_INTEGER {
            struct {
                long LowPart;
                long HighPart;
            };
            INT64 QuadPart;
        } LARGE_INTEGER;

        int __stdcall QueryPerformanceCounter(LARGE_INTEGER* lpPerformanceCount);
        int __stdcall QueryPerformanceFrequency(LARGE_INTEGER* lpFrequency);
        void __stdcall Sleep(unsigned long dwMilliseconds);
    ]]

    local frequency_large = ffi.new("LARGE_INTEGER")
    kernel32.QueryPerformanceFrequency(frequency_large)
    local performance_frequency = tonumber(frequency_large.QuadPart)

    local function get_current_ms()
        local ticks_large = ffi.new("LARGE_INTEGER")
        kernel32.QueryPerformanceCounter(ticks_large)
        return tonumber(ticks_large.QuadPart) * (1000 / performance_frequency)
    end

    local function precise_sleep(ms)
        local start_time = get_current_ms()
        local end_time = start_time + ms
        
        while get_current_ms() < end_time - 1 do
            kernel32.Sleep(0)
        end
        
        while get_current_ms() < end_time do
            -- busy wait for precision
        end
    end

    local _last_frame_time = 0

    function framelimiter.D3D9Present()
        setFPSvalue()
        if TARGET_FRAMERATE >= 4 and TARGET_FRAMERATE <= 500 then
            local current_time = get_current_ms()

            if _last_frame_time ~= 0 then
                local time_elapsed = current_time - _last_frame_time
                local frame_time = 1000 / TARGET_FRAMERATE
                
                if time_elapsed < frame_time then
                    precise_sleep(frame_time - time_elapsed)
                end
            end

            _last_frame_time = get_current_ms()
        end
    end

    -- ���������������� ��������� UI
    local sliderConfigs = {
        {key = "pedfps", label = u8"������: %d FPS", desc = u8"##������"},
        {key = "vehfps", label = u8"� ������: %d FPS", desc = u8"##� ������"},
        {key = "boatfps", label = u8"� �����: %d FPS", desc = u8"##� �����"},
        {key = "motofps", label = u8"� ����������: %d FPS", desc = u8"##� ����������"},
        {key = "bikefps", label = u8"� �����������: %d FPS", desc = u8"##� �����������"},
        {key = "swimfps", label = u8"�� ����� ��������: %d FPS", desc = u8"##�� ����� ��������"},
        {key = "helifps", label = u8"� ����������: %d FPS", desc = u8"##� ����������"},
        {key = "planefps", label = u8"� ���������: %d FPS", desc = u8"##� ���������"},
        {key = "snipergunfps", label = u8"�� ����������: %d FPS", desc = u8"##sniper"},
        {key = "spraygunfps", label = u8"� ���������� ������: %d FPS", desc = u8"##spray"}
    }

    function framelimiter.ImGui_Draw()
        if imgui.Checkbox(u8"�������� ������������ ������", checkboxes.framelimiter) then
            GT_MOD.config.ini.settings.framelimiter = checkboxes.framelimiter[0]
            GT_MOD.config.save()
        end
        
        if GT_MOD.config.ini.settings.framelimiter then
            imgui.Text(u8"����������:")
            imgui.BulletText(u8"�������� ���� 500 ������ ����� �������� ��� ��� �����������.")
            imgui.PushItemWidth(480)
            
            for i, slider in ipairs(sliderConfigs) do
                imgui.SetCursorPosY(imgui.GetCursorPosY() + 10)
                if GT_MOD.UI.CustomSlider(slider.desc, sliders[slider.key], 5, 510, slider.label, 350) then
                    GT_MOD.config.ini.smart_fps[slider.key] = sliders[slider.key][0]
                    GT_MOD.config.save()
                end
            end
            
            imgui.PopItemWidth()
        end
    end

    return framelimiter
end