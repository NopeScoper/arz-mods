
return function(GT_MOD)


local imgui = require("mimgui")
local ffi = require("ffi")
local new = imgui.new

local encoding = require("encoding")
encoding.default = "CP1251"
local u8 = encoding.UTF8
local fa = require("fAwesome5")

local new, str, sizeof = imgui.new, ffi.string, ffi.sizeof

local UI = {
    main = imgui.new.bool(false),
    tcyc = imgui.new.bool(false),
    tws = imgui.new.bool(false),
    settingsCLR = imgui.new.bool(false),
    buffers = {},
    sliders = {},
    checkboxes = {},
    icolors = {},
    fonts = {},
    mimRenderFonts = {},
} -- module


imgui.OnInitialize(function()
    imgui.GetIO().IniFilename = nil
    imgui.GetIO().ConfigFlags = imgui.ConfigFlags.NoMouseCursorChange
    local config = imgui.ImFontConfig()
    config.MergeMode = true
    local glyph_ranges = imgui.GetIO().Fonts:GetGlyphRangesCyrillic()

    local path = getFolderPath(0x14) .. '\\arialbd.TTF'
    local iconRanges = new.ImWchar[3](fa.min_range, fa.max_range, 0)

    --============================= font custom nametags ===========================================
    local mimRenderFontsPath = getFolderPath(0x14) .. '\\seguibl.ttf'
    UI.mimRenderFonts = {
        hp = imgui.GetIO().Fonts:AddFontFromFileTTF(mimRenderFontsPath, 15, nil, glyph_ranges),
        nickname = imgui.GetIO().Fonts:AddFontFromFileTTF(mimRenderFontsPath, 20, nil, glyph_ranges),
        id = imgui.GetIO().Fonts:AddFontFromFileTTF(mimRenderFontsPath, 21, nil, glyph_ranges),
        ["�������"] = imgui.GetIO().Fonts:AddFontFromFileTTF(mimRenderFontsPath, 17, nil, glyph_ranges),
    }
    --==============================================================================================

    UI.fonts = {
        menufont = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 18, nil, glyph_ranges),
        navbar = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 16, nil, glyph_ranges),
        icons_17 = imgui.GetIO().Fonts:AddFontFromFileTTF('moonloader/GameTweaker/fonts/fa-solid-900.ttf', 17, config, iconRanges),
        icons_18 = imgui.GetIO().Fonts:AddFontFromFileTTF('moonloader/GameTweaker/fonts/fa-solid-900.ttf', 18, config, iconRanges),
        fonts_30 = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 30, nil, glyph_ranges),
        
    }

    UI.fonts[35] = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 35, nil, glyph_ranges)
    UI.fonts[50] = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 50, nil, glyph_ranges)
    UI.fonts[25] = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 25, nil, glyph_ranges)

    UI.fonts["����"] = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 18, nil, glyph_ranges)
    UI.fonts["������������"] = imgui.GetIO().Fonts:AddFontFromFileTTF(path, 30, nil, glyph_ranges)


    UI.imageGORSKIN = imgui.CreateTextureFromFile(getGameDirectory() .. '\\moonloader\\GameTweaker\\gorskin.png')


    imgui.GetIO().Fonts:Build()
    collectgarbage()
end)


UI.navigations = {
    --====[[����� ������� �������?]]====--
    activeTab = {
        home = new.int(3),
        fixesandpatches = new.int(1),
        graphics = new.int(1),
        optimization = new.int(1),
        gameinterface = new.int(1),
    },
    
    --===================================--
    home = {
        fa.ICON_FA_INFO..u8'\t   Information',
        fa.ICON_FA_WRENCH..u8'\tFixes & Patches',
        fa.ICON_FA_DESKTOP..u8'\tGraphics',
        fa.ICON_FA_CHART_AREA..u8'\tOptimization',
        fa.ICON_FA_USER..u8'\tNametags',
        fa.ICON_FA_TACHOMETER_ALT..u8'\tFrame Limiter',
        fa.ICON_FA_VOLUME_UP..u8'\tSounds',
        fa.ICON_FA_EDIT..u8'\tInterface',
        fa.ICON_FA_ALIGN_LEFT..u8'\tCommands',

        --fa.ICON_FA_COG..u8"\tSettings",
    },
    fixesandpatches = {
        u8"�����������",
        u8"�����",
    },
    current_fixesandpatches = 1,
    graphics = {
        u8'������ � �����',
        u8'����������',
        u8'����',
        u8'�������',
        u8'��������',
        u8'��������� ������',
    },
    current_graphics = 1,
    optimization = {
        u8'������� ������',
        u8'������',
    },
    current_optimization = 1,
    gameinterface = {
        u8'�������',
        u8'��������',
        u8'������',
        u8'�����',
        u8'���� ����',
        u8'������',
        u8'��������',
        u8'�����',
        u8'������',
        u8'������',
        u8'����',
    },
    sounds = {
        u8'Ultimate Genrl',
        u8'Game Sounds',
        u8'Interactive Audio',
    },
    current_sounds = 1,
    interface_elemets = {
        u8"�������� ����������",
        u8"����� ���������",
        u8"����������",
        u8"�������",
        u8"������",
    },
    current_elemets = 1,
}

-- ������� ��� ����������� ��������� ��������
UI.ImGetValue = function(type, cfgvalue, default)
    if cfgvalue == nil then
        print("������ �������: �� ������� �������� ��� ���� '" .. type .. "'")
        if default ~= nil then
            return default
        end
        if type == "bool" then
            return new.bool(false)
        elseif type == "int" then
            return new.int(0)
        elseif type == "float" then
            return new.float(0.0)
        end
    end
    
    if type == "bool" then
        return new.bool(cfgvalue)
    elseif type == "int" then
        return new.int(tonumber(cfgvalue) or 0)
    elseif type == "float" then
        return new.float(tonumber(cfgvalue) or 0.0)
    else
        print("������ ����: ����������� ��� '" .. type .. "'")
        return new.bool(false)
    end
end

function UI.LoadData()
    -- Custom nametags
    UI.buffers.cnt_fontname = new.char[64](GT_MOD.config.ini.custom_nametags.fontName)
    UI.sliders.custom_nametags_fontSize = UI.ImGetValue("int", GT_MOD.config.ini.custom_nametags.fontSize)
    UI.sliders.custom_nametags_mimFontSize = UI.ImGetValue("float", GT_MOD.config.ini.custom_nametags.mimFontSize)
    UI.checkboxes.whiteId = UI.ImGetValue("bool", GT_MOD.config.ini.custom_nametags.whiteId)
    UI.checkboxes.renderFon = UI.ImGetValue("bool", GT_MOD.config.ini.custom_nametags.renderFon)
    UI.checkboxes.renderFonMimNameTags = UI.ImGetValue("bool", GT_MOD.config.ini.custom_nametags.renderFonMimNameTags)
    
    -- FPS settings
    UI.checkboxes.framelimiter = UI.ImGetValue("bool", GT_MOD.config.ini.settings.framelimiter)
    UI.sliders.pedfps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.pedfps)
    UI.sliders.vehfps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.vehfps)
    UI.sliders.boatfps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.boatfps)
    UI.sliders.motofps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.motofps)
    UI.sliders.bikefps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.bikefps)
    UI.sliders.swimfps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.swimfps)
    UI.sliders.helifps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.helifps)
    UI.sliders.planefps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.planefps)
    UI.sliders.snipergunfps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.snipergunfps)
    UI.sliders.spraygunfps = UI.ImGetValue("int", GT_MOD.config.ini.smart_fps.spraygunfps)

    -- Weather and time
    UI.sliders.weather = UI.ImGetValue("int", GT_MOD.config.ini.settings.weather)
    UI.sliders.doweather = UI.ImGetValue("int", GT_MOD.config.ini.settings.doweather)
    UI.sliders.otweather = UI.ImGetValue("int", GT_MOD.config.ini.settings.otweather)
    UI.sliders.miliseconds = UI.ImGetValue("int", GT_MOD.config.ini.settings.miliseconds)
    UI.sliders.hours = UI.ImGetValue("int", GT_MOD.config.ini.settings.hours)
    UI.sliders.min = UI.ImGetValue("int", GT_MOD.config.ini.settings.min)
    UI.checkboxes.blockweather = UI.ImGetValue("bool", GT_MOD.config.ini.settings.blockweather)
    UI.checkboxes.blocktime = UI.ImGetValue("bool", GT_MOD.config.ini.settings.blocktime)
    UI.checkboxes.sync_time = UI.ImGetValue("bool", GT_MOD.config.ini.settings.sync_time)
    UI.checkboxes.gtatime = UI.ImGetValue("bool", GT_MOD.config.ini.settings.gtatime)
    UI.checkboxes.gtaweather = UI.ImGetValue("bool", GT_MOD.config.ini.settings.gtaweather)
    UI.checkboxes.noRain = UI.ImGetValue("bool", GT_MOD.config.ini.settings.noRain)
    UI.checkboxes.noFog = UI.ImGetValue("bool", GT_MOD.config.ini.settings.noFog)
    UI.checkboxes.noSandstorm = UI.ImGetValue("bool", GT_MOD.config.ini.settings.noSandstorm)
    UI.checkboxes.noWeatherFlash = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.noweatherflash)
    UI.checkboxes.noRainyFog = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.noRainyFog)

    UI.checkboxes.SizeSunAndMoon = UI.ImGetValue("bool", GT_MOD.config.ini.settings.SizeSunAndMoon)

    UI.sliders.SizeSun = UI.ImGetValue("float", GT_MOD.config.ini.settings.SizeSun)
    UI.sliders.MoonSize = UI.ImGetValue("int", GT_MOD.config.ini.settings.MoonSize)
    UI.sliders.MoonHeight = UI.ImGetValue("float", GT_MOD.config.ini.settings.MoonHeight)
    
    -- Draw distances
    UI.sliders.drawdist = UI.ImGetValue("float", GT_MOD.config.ini.settings.drawdist)
    UI.sliders.drawdistair = UI.ImGetValue("float", GT_MOD.config.ini.settings.drawdistair)
    UI.sliders.drawdistpara = UI.ImGetValue("float", GT_MOD.config.ini.settings.drawdistpara)
    UI.sliders.fog = UI.ImGetValue("float", GT_MOD.config.ini.settings.fog)
    UI.sliders.lod = UI.ImGetValue("float", GT_MOD.config.ini.settings.lod)
    UI.sliders.playersDist = UI.ImGetValue("float", GT_MOD.config.ini.settings.playersDist)
    UI.sliders.drawweapondist = UI.ImGetValue("float", GT_MOD.config.ini.settings.drawweapondist)
    UI.sliders.distobjects_stolb_fonars = UI.ImGetValue("float", GT_MOD.config.ini.settings.distobjects_stolb_fonars)
    UI.sliders.distobjects_musor = UI.ImGetValue("float", GT_MOD.config.ini.settings.distobjects_musor)
    UI.sliders.nickdistance = UI.ImGetValue("float", GT_MOD.config.ini.settings.nickdistance)
    UI.sliders.vehloddist = UI.ImGetValue("float", GT_MOD.config.ini.settings.vehloddist)
    UI.checkboxes.givemedist = UI.ImGetValue("bool", GT_MOD.config.ini.settings.givemedist)
    UI.checkboxes.givemedistnames = UI.ImGetValue("bool", GT_MOD.config.ini.settings.givemedistnames)
    UI.checkboxes.givemedistobj = UI.ImGetValue("bool", GT_MOD.config.ini.settings.givemedistobj)

    -- Visual effects
    UI.sliders.allambient = UI.ImGetValue("float", GT_MOD.config.ini.fixtimecyc.allambient)
    UI.sliders.objambient = UI.ImGetValue("float", GT_MOD.config.ini.fixtimecyc.objambient)
    UI.sliders.shadowcp = UI.ImGetValue("int", GT_MOD.config.ini.settings.shadowcp)
    UI.sliders.shadowlight = UI.ImGetValue("int", GT_MOD.config.ini.settings.shadowlight)
    UI.sliders.aspectratio = UI.ImGetValue("float", GT_MOD.config.ini.settings.aspectratio)
    UI.sliders.brightness = UI.ImGetValue("int", GT_MOD.config.ini.settings.brightness)
    UI.sliders.MotionBlurIntensity = UI.ImGetValue("int", GT_MOD.config.ini.effects_manager.MotionBlurIntensity)
    UI.checkboxes.staticLight = UI.ImGetValue("bool", GT_MOD.config.ini.settings.staticLight)
    UI.checkboxes.aspectratio_status = UI.ImGetValue("bool", GT_MOD.config.ini.settings.aspectratio_status)
    UI.checkboxes.givemebrightness = UI.ImGetValue("bool", GT_MOD.config.ini.settings.givemebrightness)
    UI.checkboxes.MotionBlur = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.MotionBlur)
    UI.checkboxes.postfx = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.postfx)
    UI.checkboxes.noPointLight = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.noPointLight)
    UI.checkboxes.reflections = UI.ImGetValue("bool", GT_MOD.config.ini.settings.reflections)
    UI.checkboxes.sunfix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.sunfix)
    UI.checkboxes.fixtimecyc = UI.ImGetValue("bool", GT_MOD.config.ini.fixtimecyc.active)
    UI.checkboxes.shadowedit = UI.ImGetValue("bool", GT_MOD.config.ini.settings.shadowedit)
    UI.checkboxes.pedshadows = UI.ImGetValue("bool", GT_MOD.config.ini.settings.pedshadows)
    UI.checkboxes.vehshadows = UI.ImGetValue("bool", GT_MOD.config.ini.settings.vehshadows)
    UI.checkboxes.poleshadows = UI.ImGetValue("bool", GT_MOD.config.ini.settings.poleshadows)
    UI.checkboxes.bestshadows = UI.ImGetValue("bool", GT_MOD.config.ini.settings.bestshadows)

    UI.checkboxes.returnGrass =  UI.ImGetValue("bool", GT_MOD.config.ini.settings.returnGrass)
    UI.checkboxes.CollGrass =  UI.ImGetValue("bool", GT_MOD.config.ini.settings.CollGrass)
    

    -- Menu pause
    UI.checkboxes.MenuPauseSound = UI.ImGetValue("bool", GT_MOD.config.ini.settings.MenuPauseSound)

    -- Sound settings
    UI.checkboxes.sounds = UI.ImGetValue("bool", GT_MOD.config.ini.settings.sounds)
    UI.checkboxes.noradio = UI.ImGetValue("bool", GT_MOD.config.ini.settings.noradio)
    UI.checkboxes.intmusic = UI.ImGetValue("bool", GT_MOD.config.ini.settings.intmusic)
    UI.checkboxes.audiostream = UI.ImGetValue("bool", GT_MOD.config.ini.settings.audiostream)
    UI.checkboxes.bladeSound = UI.ImGetValue("bool", GT_MOD.config.ini.settings.bladeSound)
    UI.checkboxes.heliEngineSound = UI.ImGetValue("bool", GT_MOD.config.ini.settings.heliEngineSound)
    UI.checkboxes.connectedSound = UI.ImGetValue("bool", GT_MOD.config.ini.settings.connectedSound)
    UI.checkboxes.disconnectSound = UI.ImGetValue("bool", GT_MOD.config.ini.settings.disconnectSound)
    UI.checkboxes.opendialogSound = UI.ImGetValue("bool", GT_MOD.config.ini.settings.opendialogSound)

    -- Effects
    UI.checkboxes.nocloudsmall = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nocloudsmall)
    UI.checkboxes.nocloudbig = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nocloudbig)
    UI.checkboxes.nocloudhorizont = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nocloudhorizont)
    UI.checkboxes.nobirds = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nobirds)
    UI.checkboxes.nowind = UI.ImGetValue("bool", GT_MOD.config.ini.settings.nowind)
    UI.checkboxes.noplaneline = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.noplaneline)
    UI.checkboxes.tiretracks = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.tiretracks)
    UI.checkboxes.vehspec = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.vehspec)
    UI.checkboxes.nosparks = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nosparks)
    UI.checkboxes.nowaterfog = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nowaterfog)
    UI.checkboxes.nogunfire = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nogunfire)
    UI.checkboxes.nogunsmoke = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nogunsmoke)
    UI.checkboxes.nofxsystem = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nofxsystem)
    UI.checkboxes.noblood = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.noblood)
    UI.checkboxes.noexhaust = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.noexhaust)
    UI.checkboxes.noSmokeCplane = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.noSmokeCplane)
    UI.checkboxes.wheelsand = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.wheelsand)
    UI.checkboxes.wheeldust = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.wheeldust)
    UI.checkboxes.wheelmud = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.wheelmud)
    UI.checkboxes.wheelgravel = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.wheelgravel)
    UI.checkboxes.wheelgrass = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.wheelgrass)
    UI.checkboxes.wheelspray = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.wheelspray)
    UI.checkboxes.vehsparks = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.vehsparks)
    UI.checkboxes.nodust = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nodust)
    UI.checkboxes.gunshell = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.gunshell)
    UI.checkboxes.teargas = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.teargas)
    UI.checkboxes.footprints = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.footprints)
    UI.checkboxes.swim = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.swim)
    UI.checkboxes.vehdust = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.vehdust)
    UI.checkboxes.vehdmgdust = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.vehdmgdust)
    UI.checkboxes.footdust = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.footdust)
    UI.checkboxes.vehdmgsmoke = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.vehdmgsmoke)
    UI.checkboxes.breakobject = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.breakobject)
    UI.checkboxes.nomorehaze = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.nomorehaze)
    UI.checkboxes.reflectionwater = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.reflectionwater)
    UI.checkboxes.fireworld = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.fireworld)
    UI.checkboxes.vehtaxilight = UI.ImGetValue("bool", GT_MOD.config.ini.effects_manager.vehtaxilight)

    -- Game fixes
    UI.checkboxes.paralandingfix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.paralandingfix)
    UI.checkboxes.sightObjectsFix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.sightObjectsFix)
    UI.checkboxes.swingingfix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.swingingfix)
    UI.checkboxes.aisens = UI.ImGetValue("bool", GT_MOD.config.ini.settings.aisens)
    UI.checkboxes.fastquit = UI.ImGetValue("bool", GT_MOD.config.ini.settings.fastquit)
    UI.checkboxes.vehCameraTweak = UI.ImGetValue("bool", GT_MOD.config.ini.settings.vehCameraTweak)
    UI.checkboxes.swimFix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.swimFix)
    UI.checkboxes.ovalityCorrection = UI.ImGetValue("bool", GT_MOD.config.ini.settings.ovalityCorrection)
    UI.checkboxes.anticrash = UI.ImGetValue("bool", GT_MOD.config.ini.settings.anticrash)
    UI.checkboxes.antiblockedplayer = UI.ImGetValue("bool", GT_MOD.config.ini.settings.antiblockedplayer)
    UI.checkboxes.fixblackroads = UI.ImGetValue("bool", GT_MOD.config.ini.settings.fixblackroads)
    UI.checkboxes.longarmfix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.longarmfix)
    UI.checkboxes.waterfixquadro = UI.ImGetValue("bool", GT_MOD.config.ini.settings.waterfixquadro)
    UI.checkboxes.intrun = UI.ImGetValue("bool", GT_MOD.config.ini.settings.intrun)
    UI.checkboxes.treepitching = UI.ImGetValue("bool", GT_MOD.config.ini.settings.treepitching)
    UI.checkboxes.fixbloodwood = UI.ImGetValue("bool", GT_MOD.config.ini.settings.fixbloodwood)
    UI.checkboxes.refreshratefix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.refreshratefix)
    UI.checkboxes.vsync = UI.ImGetValue("bool", GT_MOD.config.ini.settings.vsync)
    --UI.checkboxes.areanames = UI.ImGetValue("bool", GT_MOD.config.ini.settings.areanames)
    --UI.checkboxes.vehiclenames = UI.ImGetValue("bool", GT_MOD.config.ini.settings.vehiclenames)
    UI.checkboxes.patchduck = UI.ImGetValue("bool", GT_MOD.config.ini.settings.patchduck)
    UI.checkboxes.FixArrowPassMotoBike = UI.ImGetValue("bool", GT_MOD.config.ini.settings.FixArrowPassMotoBike)
    UI.checkboxes.forceaniso = UI.ImGetValue("bool", GT_MOD.config.ini.settings.forceaniso)
    UI.checkboxes.dual_monitor_fix = UI.ImGetValue("bool", GT_MOD.config.ini.settings.dual_monitor_fix)

    UI.checkboxes.no3dTextPlayers = UI.ImGetValue("bool", GT_MOD.config.ini.settings.no3dTextPlayers)
    UI.checkboxes.no3dTextVehicles = UI.ImGetValue("bool", GT_MOD.config.ini.settings.no3dTextVehicles)

    -- Other UI elements
    UI.checkboxes.shownicks = UI.ImGetValue("bool", GT_MOD.config.ini.settings.shownicks)
    UI.checkboxes.showhp = UI.ImGetValue("bool", GT_MOD.config.ini.settings.showhp)
    UI.checkboxes.unlimitfps = UI.ImGetValue("bool", GT_MOD.config.ini.settings.unlimitfps)
    UI.checkboxes.chatt = UI.ImGetValue("bool", GT_MOD.config.ini.settings.chatt)
    UI.checkboxes.KillListChange = UI.ImGetValue("bool", GT_MOD.config.ini.settings.KillListChange)
    UI.checkboxes.FixUnderBridgeForRain = UI.ImGetValue("bool", GT_MOD.config.ini.settings.FixUnderBridgeForRain)
    UI.checkboxes.inputPatch = UI.ImGetValue("bool", GT_MOD.config.ini.settings.inputPatch)
    UI.checkboxes.NetStatsWithHud = UI.ImGetValue("bool", GT_MOD.config.ini.settings.NetStatsWithHud)
    UI.checkboxes.timecyc_creator = UI.ImGetValue("bool", false)

    UI.sliders.staticLightBrightness = UI.ImGetValue("float", GT_MOD.config.ini.settings.staticLightBrightness)
    -- Memory cleaner
    UI.sliders.limitmem = UI.ImGetValue("int", GT_MOD.config.ini.cleaner.limit)
    UI.checkboxes.cleaninfo = UI.ImGetValue("bool", GT_MOD.config.ini.cleaner.cleaninfo)
    UI.checkboxes.autoclean = UI.ImGetValue("bool", GT_MOD.config.ini.cleaner.autoclean)

    -- Camera settings
    UI.sliders.camera = UI.ImGetValue("float", GT_MOD.config.ini.settings.camera)
    UI.sliders.aiming = UI.ImGetValue("float", GT_MOD.config.ini.settings.aiming)
    UI.sliders.aimingSniper = UI.ImGetValue("float", GT_MOD.config.ini.settings.aimingSniper)

    -- Kill list
    UI.sliders.KillListPosX = UI.ImGetValue("float", GT_MOD.config.ini.settings.KillListPosX)
    UI.sliders.KillListPosY = UI.ImGetValue("float", GT_MOD.config.ini.settings.KillListPosY)

    -- Key blocking
    UI.checkboxes.nop_samp_keys_F4 = UI.ImGetValue("bool", GT_MOD.config.ini.nop_samp_keys.key_F4)
    UI.checkboxes.nop_samp_keys_F7 = UI.ImGetValue("bool", GT_MOD.config.ini.nop_samp_keys.key_F7)
    UI.checkboxes.nop_samp_keys_T = UI.ImGetValue("bool", GT_MOD.config.ini.nop_samp_keys.key_T)
    UI.checkboxes.nop_samp_keys_ALTENTER = UI.ImGetValue("bool", GT_MOD.config.ini.nop_samp_keys.key_ALTENTER)
    UI.checkboxes.nop_samp_keys_PgUp_PgDn = UI.ImGetValue("bool", GT_MOD.config.ini.nop_samp_keys.key_PgUp_PgDn)

    -- ugenrl settings
    UI.checkboxes.ugenrl_enable = UI.ImGetValue("bool", GT_MOD.config.ini.ugenrl_main.enable)
    UI.checkboxes.weapon_checkbox = UI.ImGetValue("bool", GT_MOD.config.ini.ugenrl_main.weapon)
    UI.checkboxes.enemyweapon_checkbox = UI.ImGetValue("bool", GT_MOD.config.ini.ugenrl_main.enemyWeapon)
    UI.checkboxes.hit_checkbox = UI.ImGetValue("bool", GT_MOD.config.ini.ugenrl_main.hit)
    UI.checkboxes.pain_checkbox = UI.ImGetValue("bool", GT_MOD.config.ini.ugenrl_main.pain)
    UI.checkboxes.kill_checkbox = UI.ImGetValue("bool", GT_MOD.config.ini.ugenrl_main.kill)
    UI.sliders.weapon_volume_slider = UI.ImGetValue("float", GT_MOD.config.ini.ugenrl_volume.weapon)
    UI.sliders.hit_volume_slider = UI.ImGetValue("float", GT_MOD.config.ini.ugenrl_volume.hit)
    UI.sliders.pain_volume_slider = UI.ImGetValue("float", GT_MOD.config.ini.ugenrl_volume.pain)
    UI.sliders.kill_volume_slider = UI.ImGetValue("float", GT_MOD.config.ini.ugenrl_volume.kill)
    UI.sliders.enemyweapon_dist = UI.ImGetValue("int", GT_MOD.config.ini.ugenrl_main.enemyWeaponDist)
    UI.sliders.connected_volume_slider = UI.ImGetValue("float", GT_MOD.config.ini.ugenrl_volume.connected)
    UI.sliders.disconnected_volume_slider = UI.ImGetValue("float", GT_MOD.config.ini.ugenrl_volume.disconnected)
    UI.sliders.opendialog_volume_slider = UI.ImGetValue("float", GT_MOD.config.ini.ugenrl_volume.opendialog)
    UI.gmodevar = UI.ImGetValue("int", GT_MOD.config.ini.ugenrl_main.mode)

    --nametags
    UI.sliders.custom_nametags_fov = UI.ImGetValue("float", GT_MOD.config.ini.custom_nametags.fov)

    -- Buffers (��������� ��� ����, ��� ��� ��� ��������� ������)
    UI.buffers.cmd_openmenu = new.char[64](GT_MOD.config.ini.commands.openmenu)
    UI.buffers.cmd_settime = new.char[64](GT_MOD.config.ini.commands.settime)
    UI.buffers.cmd_setweather = new.char[64](GT_MOD.config.ini.commands.setweather)
    UI.buffers.cmd_blockservertime = new.char[64](GT_MOD.config.ini.commands.blockservertime)
    UI.buffers.cmd_blockserverweather = new.char[64](GT_MOD.config.ini.commands.blockserverweather)
    UI.buffers.cmd_givemedist = new.char[64](GT_MOD.config.ini.commands.givemedist)
    UI.buffers.cmd_givemedistnames = new.char[64](GT_MOD.config.ini.commands.givemedistnames)
    UI.buffers.cmd_drawdistance = new.char[64](GT_MOD.config.ini.commands.drawdistance)
    UI.buffers.cmd_drawdistanceair = new.char[64](GT_MOD.config.ini.commands.drawdistanceair)
    UI.buffers.cmd_drawdistancepara = new.char[64](GT_MOD.config.ini.commands.drawdistancepara)
    UI.buffers.cmd_fogdistance = new.char[64](GT_MOD.config.ini.commands.fogdistance)
    UI.buffers.cmd_loddistance = new.char[64](GT_MOD.config.ini.commands.loddistance)
    UI.buffers.cmd_shownicks = new.char[64](GT_MOD.config.ini.commands.shownicks)
    UI.buffers.cmd_showhp = new.char[64](GT_MOD.config.ini.commands.showhp)
    UI.buffers.cmd_showchat = new.char[64](GT_MOD.config.ini.commands.showchat)
    UI.buffers.cmd_showhud = new.char[64](GT_MOD.config.ini.commands.showhud)
    UI.buffers.cmd_fpslock = new.char[64](GT_MOD.config.ini.commands.fpslock)
    UI.buffers.cmd_postfx = new.char[64](GT_MOD.config.ini.commands.postfx)
    UI.buffers.cmd_ntgs = new.char[64](GT_MOD.config.ini.commands.ntgs)
    UI.buffers.cmd_autocleaner = new.char[64](GT_MOD.config.ini.commands.autocleaner)
    UI.buffers.cmd_cleanmemory = new.char[64](GT_MOD.config.ini.commands.cleanmemory)
    UI.buffers.cmd_cleaninfo = new.char[64](GT_MOD.config.ini.commands.cleaninfo)
    UI.buffers.cmd_setmbforautocleaner = new.char[64](GT_MOD.config.ini.commands.setmbforautocleaner)
    UI.buffers.cmd_opentimecyccreator = new.char[64](GT_MOD.config.ini.commands.opentimecyccreator)
    UI.buffers.cmd_givemedistobj = new.char[64](GT_MOD.config.ini.commands.givemedistobj)
    UI.buffers.cmd_tws = new.char[64](GT_MOD.config.ini.commands.tws)
    UI.buffers.cmd_fpsc = new.char[64](GT_MOD.config.ini.commands.fpsc)
    UI.buffers.cmd_setfps = new.char[64](GT_MOD.config.ini.commands.setfps)
    UI.buffers.cmd_vehfps = new.char[64](GT_MOD.config.ini.commands.vehfps)
    UI.buffers.cmd_bikefps = new.char[64](GT_MOD.config.ini.commands.bikefps)
    UI.buffers.cmd_motofps = new.char[64](GT_MOD.config.ini.commands.motofps)
    UI.buffers.cmd_boatfps = new.char[64](GT_MOD.config.ini.commands.boatfps)
    UI.buffers.cmd_planefps = new.char[64](GT_MOD.config.ini.commands.planefps)
    UI.buffers.cmd_helifps = new.char[64](GT_MOD.config.ini.commands.helifps)
    UI.buffers.cmd_swimfps = new.char[64](GT_MOD.config.ini.commands.swimfps)
    UI.buffers.cmd_snipergunfps = new.char[64](GT_MOD.config.ini.commands.snipergunfps)
    UI.buffers.cmd_spraygunfps = new.char[64](GT_MOD.config.ini.commands.spraygunfps)

    -- const data
    UI.buffers.multilineText = new.char[100000]()
    UI.buffers.IEpresetName = new.char[128]()

    -- Colors (��������� ��� ����, ��� ��� ��� �������)
    UI.icolors.wamb = new.float[3](GT_MOD.config.ini.fixtimecyc.worldambientR, GT_MOD.config.ini.fixtimecyc.worldambientG, GT_MOD.config.ini.fixtimecyc.worldambientB)
    UI.icolors.PLeftUp = new.float[4](GT_MOD.config.ini.PLeftUp.r, GT_MOD.config.ini.PLeftUp.g, GT_MOD.config.ini.PLeftUp.b, GT_MOD.config.ini.PLeftUp.a)
    UI.icolors.PLeftDown = new.float[4](GT_MOD.config.ini.PLeftDown.r, GT_MOD.config.ini.PLeftDown.g, GT_MOD.config.ini.PLeftDown.b, GT_MOD.config.ini.PLeftDown.a)
    UI.icolors.PRightUp = new.float[4](GT_MOD.config.ini.PRightUp.r, GT_MOD.config.ini.PRightUp.g, GT_MOD.config.ini.PRightUp.b, GT_MOD.config.ini.PRightUp.a)
    UI.icolors.PRightDown = new.float[4](GT_MOD.config.ini.PRightDown.r, GT_MOD.config.ini.PRightDown.g, GT_MOD.config.ini.PRightDown.b, GT_MOD.config.ini.PRightDown.a)
    UI.icolors.WindowBG = new.float[4](GT_MOD.config.ini.WindowBG.r, GT_MOD.config.ini.WindowBG.g, GT_MOD.config.ini.WindowBG.b, GT_MOD.config.ini.WindowBG.a)
    UI.icolors.Text = new.float[4](GT_MOD.config.ini.Text.r, GT_MOD.config.ini.Text.g, GT_MOD.config.ini.Text.b, GT_MOD.config.ini.Text.a)
    UI.icolors.BaseColor = new.float[4](GT_MOD.config.ini.BaseColor.r, GT_MOD.config.ini.BaseColor.g, GT_MOD.config.ini.BaseColor.b, GT_MOD.config.ini.BaseColor.a)
    UI.icolors.ColorChildMenu = new.float[4](GT_MOD.config.ini.ColorChildMenu.r, GT_MOD.config.ini.ColorChildMenu.g, GT_MOD.config.ini.ColorChildMenu.b, GT_MOD.config.ini.ColorChildMenu.a)
    UI.icolors.ColorNavi = new.float[4](GT_MOD.config.ini.ColorNavi.r, GT_MOD.config.ini.ColorNavi.g, GT_MOD.config.ini.ColorNavi.b, GT_MOD.config.ini.ColorNavi.a)
    UI.icolors.ActiveText = new.float[4](GT_MOD.config.ini.ActiveText.r, GT_MOD.config.ini.ActiveText.g, GT_MOD.config.ini.ActiveText.b, GT_MOD.config.ini.ActiveText.a)
    UI.icolors.PassiveText = new.float[4](GT_MOD.config.ini.PassiveText.r, GT_MOD.config.ini.PassiveText.g, GT_MOD.config.ini.PassiveText.b, GT_MOD.config.ini.PassiveText.a)

    UI.icolors.FrameBg = new.float[4](GT_MOD.config.ini.FrameBg.r, GT_MOD.config.ini.FrameBg.g, GT_MOD.config.ini.FrameBg.b, GT_MOD.config.ini.FrameBg.a)
    UI.icolors.FrameBgHovered = new.float[4](GT_MOD.config.ini.FrameBgHovered.r, GT_MOD.config.ini.FrameBgHovered.g, GT_MOD.config.ini.FrameBgHovered.b, GT_MOD.config.ini.FrameBgHovered.a)
    UI.icolors.FrameBgActive = new.float[4](GT_MOD.config.ini.FrameBgActive.r, GT_MOD.config.ini.FrameBgActive.g, GT_MOD.config.ini.FrameBgActive.b, GT_MOD.config.ini.FrameBgActive.a)
    UI.icolors.CheckMark = new.float[4](GT_MOD.config.ini.CheckMark.r, GT_MOD.config.ini.CheckMark.g, GT_MOD.config.ini.CheckMark.b, GT_MOD.config.ini.CheckMark.a)
    UI.icolors.SliderGrab = new.float[4](GT_MOD.config.ini.SliderGrab.r, GT_MOD.config.ini.SliderGrab.g, GT_MOD.config.ini.SliderGrab.b, GT_MOD.config.ini.SliderGrab.a)
    UI.icolors.SliderGrabActive = new.float[4](GT_MOD.config.ini.SliderGrabActive.r, GT_MOD.config.ini.SliderGrabActive.g, GT_MOD.config.ini.SliderGrabActive.b, GT_MOD.config.ini.SliderGrabActive.a)
    UI.icolors.Button = new.float[4](GT_MOD.config.ini.Button.r, GT_MOD.config.ini.Button.g, GT_MOD.config.ini.Button.b, GT_MOD.config.ini.Button.a)
    UI.icolors.ButtonHovered = new.float[4](GT_MOD.config.ini.ButtonHovered.r, GT_MOD.config.ini.ButtonHovered.g, GT_MOD.config.ini.ButtonHovered.b, GT_MOD.config.ini.ButtonHovered.a)
    UI.icolors.ButtonActive = new.float[4](GT_MOD.config.ini.ButtonActive.r, GT_MOD.config.ini.ButtonActive.g, GT_MOD.config.ini.ButtonActive.b, GT_MOD.config.ini.ButtonActive.a)
    UI.icolors.Header = new.float[4](GT_MOD.config.ini.Header.r, GT_MOD.config.ini.Header.g, GT_MOD.config.ini.Header.b, GT_MOD.config.ini.Header.a)
    UI.icolors.HeaderHovered = new.float[4](GT_MOD.config.ini.HeaderHovered.r, GT_MOD.config.ini.HeaderHovered.g, GT_MOD.config.ini.HeaderHovered.b, GT_MOD.config.ini.HeaderHovered.a)
    UI.icolors.HeaderActive = new.float[4](GT_MOD.config.ini.HeaderActive.r, GT_MOD.config.ini.HeaderActive.g, GT_MOD.config.ini.HeaderActive.b, GT_MOD.config.ini.HeaderActive.a)
    UI.icolors.ScrollbarBg = new.float[4](GT_MOD.config.ini.ScrollbarBg.r, GT_MOD.config.ini.ScrollbarBg.g, GT_MOD.config.ini.ScrollbarBg.b, GT_MOD.config.ini.ScrollbarBg.a)
    UI.icolors.ScrollbarGrab = new.float[4](GT_MOD.config.ini.ScrollbarGrab.r, GT_MOD.config.ini.ScrollbarGrab.g, GT_MOD.config.ini.ScrollbarGrab.b, GT_MOD.config.ini.ScrollbarGrab.a)
    UI.icolors.ScrollbarGrabHovered = new.float[4](GT_MOD.config.ini.ScrollbarGrabHovered.r, GT_MOD.config.ini.ScrollbarGrabHovered.g, GT_MOD.config.ini.ScrollbarGrabHovered.b, GT_MOD.config.ini.ScrollbarGrabHovered.a)
    UI.icolors.ScrollbarGrabActive = new.float[4](GT_MOD.config.ini.ScrollbarGrabActive.r, GT_MOD.config.ini.ScrollbarGrabActive.g, GT_MOD.config.ini.ScrollbarGrabActive.b, GT_MOD.config.ini.ScrollbarGrabActive.a)
    UI.icolors.LogoColor = new.float[4](GT_MOD.config.ini.logocolor.r, GT_MOD.config.ini.logocolor.g, GT_MOD.config.ini.logocolor.b, GT_MOD.config.ini.logocolor.a)
    UI.icolors.BeginColor = new.float[4](GT_MOD.config.ini.BeginColor.r, GT_MOD.config.ini.BeginColor.g, GT_MOD.config.ini.BeginColor.b, GT_MOD.config.ini.BeginColor.a)

    UI.icolors.mainBoxColor1 = new.float[4](GT_MOD.config.ini.mainBoxColor1.r, GT_MOD.config.ini.mainBoxColor1.g, GT_MOD.config.ini.mainBoxColor1.b, GT_MOD.config.ini.mainBoxColor1.a)
    UI.icolors.mainBoxColor2 = new.float[4](GT_MOD.config.ini.mainBoxColor2.r, GT_MOD.config.ini.mainBoxColor2.g, GT_MOD.config.ini.mainBoxColor2.b, GT_MOD.config.ini.mainBoxColor2.a)
    UI.icolors.mainBoxColor3 = new.float[4](GT_MOD.config.ini.mainBoxColor3.r, GT_MOD.config.ini.mainBoxColor3.g, GT_MOD.config.ini.mainBoxColor3.b, GT_MOD.config.ini.mainBoxColor3.a)
    UI.icolors.mainBoxColor4 = new.float[4](GT_MOD.config.ini.mainBoxColor4.r, GT_MOD.config.ini.mainBoxColor4.g, GT_MOD.config.ini.mainBoxColor4.b, GT_MOD.config.ini.mainBoxColor4.a)

    -- Other variables
    UI.selectedPriorityIndex = UI.ImGetValue("int", GT_MOD.config.ini.settings.PriorityClass)
end
UI.LoadData()

local checkboxes, sliders, buffers, icolors = UI.checkboxes, UI.sliders, UI.buffers, UI.icolors

UI.typerender = {-- ����� ����� ����� ������� ������ �����
    u8"�����������",
    u8"ImGui",
    u8"MoonLoader",
}
UI.typerenderVar = new.int(tonumber(GT_MOD.config.ini.custom_nametags.typerender))

-- ������ ������ ������ (������ ����)
UI.fontFlagsText = {
    u8"NONE",
    u8"BOLD",
    u8"ITALICS",
    u8"BORDER",
    u8"SHADOW",
    u8"UNDERLINE",
    u8"STRIKEOUT",
}
UI.fontFlag = new.int(tonumber(GT_MOD.config.ini.custom_nametags.fontFlag - 1))

UI.typebarsforma = {--��� ����������� �� � �����
    u8"������",
    u8"�������",
}
UI.typebarsformavar = new.int(tonumber(GT_MOD.config.ini.custom_nametags.typeFormaMimNameTags))

UI.typebarstext = {
    u8"�������",
    u8"������� + ������",
    u8"����������",
    u8"���������� + ������",
}

UI.typebarsvar = new.int(tonumber(GT_MOD.config.ini.custom_nametags.typebars))


UI.gmodetext = {
    u8"Only Genrl",
    u8"Game Sounds + Genrl",
    u8"Game Sounds + Bell + Kill",
}


UI.fontstyletext = {
    u8"FONT_GOTHIC",
    u8"FONT_SUBTITLES",
    u8"FONT_MENU",
    u8"FONT_PRICEDOWN",
}

UI.tbmtext = {
    u8"�������",
    u8"��� ��������",
    u8"�����������",
}


UI.fontmoneybordertext = {
    u8"��� �������",
    u8"������",
    u8"C����������",
}

UI.posdollartext = {
    u8"�����",
    u8"������",
}

UI.radarTypeText = {
    u8"�����������",
    u8"�������",
    u8"����������",
    u8"Definitive Edition (� ����������!)",
}

local priorityClasses = {
    {name = u8"������", value = 0x00004000},
    {name = u8"���� ��������", value = 0x00008000},
    {name = u8"����������", value = 0x00000020},
    {name = u8"�������", value = 0x00000080},
    --{name = u8"��������� �������", value = 0x00000100} -- ������! (����� ������� ����� ����� ������)
}

UI.priorityNames = {}

for _, priority in ipairs(priorityClasses) do
    table.insert(UI.priorityNames, priority.name)
end


UI.CloseButton = function(text, pos)
    imgui.SetCursorPos(pos)
    local result = imgui.InvisibleButton("##closebtn", imgui.ImVec2(20, 20))
    local hovered = imgui.IsItemHovered()
    local col = hovered and imgui.GetStyle().Colors[imgui.Col.Button] or imgui.GetStyle().Colors[imgui.Col.Text]
    
    imgui.SetCursorPos(pos)
    imgui.PushStyleColor(imgui.Col.Text, col)
    imgui.Text(fa.ICON_FA_SIGN_OUT_ALT)
    imgui.PopStyleColor()

    return result
end

function UI.Hint(text, delay, action)
    if imgui.IsItemHovered() then
        if go_hint == nil then go_hint = os.clock() + (delay and delay or 0.0) end
        local alpha = (os.clock() - go_hint) * 5
        if os.clock() >= go_hint then
            imgui.PushStyleVarVec2(imgui.StyleVar.WindowPadding, imgui.ImVec2(10, 10))
            imgui.PushStyleVarFloat(imgui.StyleVar.Alpha, (alpha <= 1.0 and alpha or 1.0))
                imgui.PushStyleColor(imgui.Col.PopupBg, imgui.ImVec4(0.11, 0.11, 0.11, 1.00))
                    imgui.BeginTooltip()
                    imgui.PushTextWrapPos(460)

                    imgui.TextColored(imgui.GetStyle().Colors[imgui.Col.ButtonHovered], u8'���������:')
                   
                    imgui.TextUnformatted(text)
                    if action ~= nil then
                        imgui.TextColored(imgui.GetStyle().Colors[imgui.Col.TextDisabled], u8'\n '..action)
                    end
                    if not imgui.IsItemVisible() and imgui.GetStyle().Alpha == 1.0 then go_hint = nil end
                    imgui.PopTextWrapPos()
                    imgui.EndTooltip()
                imgui.PopStyleColor()
            imgui.PopStyleVar(2)
        end
    end
end

local active_slider_id, alt_active_slider_id = nil, nil

function UI.CustomSlider(str_id, value, min, max, sformat, width)
    local width = width or 100
    local DL = imgui.GetWindowDrawList()
    imgui.SetCursorPosX(imgui.GetCursorPos().x + 10)
    local p = imgui.GetCursorScreenPos()

    -- ������������� ��������� ��������
    UI_CUSTOM_SLIDER = UI_CUSTOM_SLIDER or {}
    UI_CUSTOM_SLIDER[str_id] = UI_CUSTOM_SLIDER[str_id] or {
        active = false,
        hovered = false,
        start = 0,
        smooth_value = value[0]
    }

    -- ����������� �������� ���� �� ������ � ��������� ������� �� �����
    local active_area_padding = 7 -- ����������� �������� ���� �� 20 �������� � ������ �������
    local active_area_height = 15  -- ����������� ������ �������� ����
    
    -- ������� ��������� ������ � ����������� ��������
    imgui.SetCursorPosY(imgui.GetCursorPos().y - active_area_padding/2)
    imgui.InvisibleButton(str_id, imgui.ImVec2(width + active_area_padding * 2, active_area_height))
    imgui.SetCursorPosY(imgui.GetCursorPos().y + 10)
    
    local isActive, isHovered = imgui.IsItemActive(), imgui.IsItemHovered()
    UI_CUSTOM_SLIDER[str_id].active = isActive
    UI_CUSTOM_SLIDER[str_id].hovered = isHovered

    -- ���������� ��������� ����������
    if isActive then
        if imgui.GetIO().KeyAlt then 
            alt_active_slider_id = str_id 
        else 
            active_slider_id = str_id 
        end
    else
        if active_slider_id == str_id then active_slider_id = nil end
        if alt_active_slider_id == str_id and not imgui.GetIO().KeyAlt then alt_active_slider_id = nil end
    end

    -- ���������� ��� �������� (����� ��� �������)
    local isInteger = (math.floor(min) == min) and (math.floor(max) == max)
    local step = (max - min) / (width * (isInteger and 10 or 80))

    -- ��������� ����� � ��������� ������� ���
    local isAltPressed = imgui.GetIO().KeyAlt
    local mouseDown = imgui.IsMouseDown(0)
    
    -- ������� ���������: ��������� ���������� ��������� ���� ������ �������� � ��������
    if ((str_id == active_slider_id and not isAltPressed) or 
        (str_id == alt_active_slider_id and isAltPressed)) and mouseDown then
        
        local mousePos = imgui.GetMousePos()
        local delta = imgui.GetIO().MouseDelta.x
        
        if isAltPressed then
            -- ������� ��������� ��� ������� Alt
            UI_CUSTOM_SLIDER[str_id].smooth_value = UI_CUSTOM_SLIDER[str_id].smooth_value + delta * step
            UI_CUSTOM_SLIDER[str_id].smooth_value = math.max(min, math.min(max, UI_CUSTOM_SLIDER[str_id].smooth_value))
            value[0] = isInteger and math.floor(UI_CUSTOM_SLIDER[str_id].smooth_value + 0.5) or UI_CUSTOM_SLIDER[str_id].smooth_value
        else
            -- ������ �������������� - ���������� ���������� ������� ����
            -- ������������ ������� ���� ����������� ��������� ��������
            local clampedX = math.max(p.x, math.min(p.x + width, mousePos.x))
            UI_CUSTOM_SLIDER[str_id].smooth_value = min + (max - min) * (clampedX - p.x) / width
            UI_CUSTOM_SLIDER[str_id].smooth_value = math.max(min, math.min(max, UI_CUSTOM_SLIDER[str_id].smooth_value))
            value[0] = isInteger and math.floor(UI_CUSTOM_SLIDER[str_id].smooth_value + 0.5) or UI_CUSTOM_SLIDER[str_id].smooth_value
        end
    else
        -- ������� ����������� � ����������� ��������
        if math.abs(UI_CUSTOM_SLIDER[str_id].smooth_value - value[0]) > 0.001 then
            UI_CUSTOM_SLIDER[str_id].smooth_value = UI_CUSTOM_SLIDER[str_id].smooth_value + (value[0] - UI_CUSTOM_SLIDER[str_id].smooth_value) * 0.3
        else
            UI_CUSTOM_SLIDER[str_id].smooth_value = value[0]
        end
    end

    -- ������������ �������� (�������� ��� ���������)
    local posSliderX = p.x + (width) * (UI_CUSTOM_SLIDER[str_id].smooth_value - min) / (max - min)
    local eCol, brightness = imgui.GetStyle().Colors[imgui.Col.FrameBg], 0.1
    local sliderColor = imgui.ImVec4(eCol.x, eCol.y, eCol.z, 1.0)
    if isHovered then sliderColor = imgui.ImVec4(eCol.x + brightness, eCol.y + brightness, eCol.z + brightness, 1.0) end

    if (str_id == active_slider_id and isAltPressed) or (str_id == alt_active_slider_id and isAltPressed) then
        DL:AddRectFilledMultiColor(
            imgui.ImVec2(p.x, p.y + 6 + active_area_padding/2), imgui.ImVec2(p.x + width, p.y + 14 + active_area_padding/2), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button])
        )
        local arrowSize, halfArrowSize, midY, leftX, rightX = 10, 5, p.y + 10 + active_area_padding/2, p.x, p.x + width

        DL:AddLine(imgui.ImVec2(leftX, midY - halfArrowSize), imgui.ImVec2(leftX + arrowSize, midY), imgui.GetColorU32Vec4(sliderColor), 1)
        DL:AddLine(imgui.ImVec2(leftX, midY + halfArrowSize), imgui.ImVec2(leftX + arrowSize, midY), imgui.GetColorU32Vec4(sliderColor), 1)
        DL:AddLine(imgui.ImVec2(leftX, midY - halfArrowSize), imgui.ImVec2(leftX, midY + halfArrowSize), imgui.GetColorU32Vec4(sliderColor), 1)
        DL:AddLine(imgui.ImVec2(rightX, midY - halfArrowSize), imgui.ImVec2(rightX - arrowSize, midY), imgui.GetColorU32Vec4(sliderColor), 1)
        DL:AddLine(imgui.ImVec2(rightX, midY + halfArrowSize), imgui.ImVec2(rightX - arrowSize, midY), imgui.GetColorU32Vec4(sliderColor), 1)
        DL:AddLine(imgui.ImVec2(rightX, midY - halfArrowSize), imgui.ImVec2(rightX, midY + halfArrowSize), imgui.GetColorU32Vec4(sliderColor), 1)
    else
        DL:AddRectFilledMultiColor(
            imgui.ImVec2(p.x, p.y + 2 + active_area_padding/2), imgui.ImVec2(p.x + width, p.y + 14 + active_area_padding/2), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.ButtonHovered]), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.ButtonHovered]), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.ButtonHovered]), 
            imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.ButtonHovered])
        )
        -- ������ ���������� ����������
        local squareSize = 17
        local squarePos = imgui.ImVec2(posSliderX - squareSize/2, p.y + active_area_padding/2)
        DL:AddRectFilled(
            squarePos, 
            imgui.ImVec2(squarePos.x + squareSize, squarePos.y + squareSize), 
            imgui.GetColorU32Vec4(sliderColor)
        )
        DL:AddRect(
            squarePos, 
            imgui.ImVec2(squarePos.x + squareSize, squarePos.y + squareSize), 
            imgui.GetColorU32Vec4(imgui.ImVec4(1.0, 1.0, 1.0, 0.5)), 
            1.0
        )
    end

    -- ����������� ��������
    DL:AddText(
        imgui.ImVec2(p.x + width + 10, p.y + active_area_padding/2), 
        imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Text]), 
        string.format(sformat, value[0])
    )

    return isActive
end

function UI.BetterInput(name, hint_text, buffer, color, text_color, width)
    -- ��������� ������� ��� ��������
    local function bringVec4To(from, to, start_time, duration)
        local timer = os.clock() - start_time
        if timer >= 0.00 and timer <= duration then
            local count = timer / (duration / 100)
            return imgui.ImVec4(
                from.x + (count * (to.x - from.x) / 100),
                from.y + (count * (to.y - from.y) / 100),
                from.z + (count * (to.z - from.z) / 100),
                from.w + (count * (to.w - from.w) / 100)
            ), true
        end
        return (timer > duration) and to or from, false
    end

    local function bringFloatTo(from, to, start_time, duration)
        local timer = os.clock() - start_time
        if timer >= 0.00 and timer <= duration then
            local count = timer / (duration / 100)
            return from + (count * (to - from) / 100), true
        end
        return (timer > duration) and to or from, false
    end

    -- ������������� UI_BETTERINPUT
    UI_BETTERINPUT = UI_BETTERINPUT or {}
    UI_BETTERINPUT[name] = UI_BETTERINPUT[name] or {
        buffer = buffer or imgui.ImBuffer(256),
        width = width or math.max(150, imgui.CalcTextSize(hint_text).x + 50),
        hint = { pos = imgui.ImVec2(imgui.GetCursorPos()), old_pos = imgui.GetCursorPos().y, scale = 1.0 },
        color = imgui.GetStyle().Colors[imgui.Col.TextDisabled],
        old_color = imgui.GetStyle().Colors[imgui.Col.TextDisabled],
        active = { false, nil },
        inactive = { true, nil }
    }

    local pool = UI_BETTERINPUT[name]
    color = color or imgui.GetStyle().Colors[imgui.Col.ButtonActive]

    -- ��������� ������
    imgui.PushStyleColor(imgui.Col.FrameBg, imgui.ImVec4(1, 1, 1, 0))
    imgui.PushStyleColor(imgui.Col.Text, text_color or imgui.ImVec4(1, 1, 1, 1))
    imgui.PushStyleColor(imgui.Col.TextSelectedBg, color)
    imgui.PushStyleVarVec2(imgui.StyleVar.FramePadding, imgui.ImVec2(0, imgui.GetStyle().FramePadding.y))
    imgui.PushItemWidth(pool.width)

    -- ������������ �����
    local draw_list = imgui.GetWindowDrawList()
    local line_y = imgui.GetCursorPos().y + imgui.GetWindowPos().y + (2 * imgui.GetStyle().FramePadding.y) + imgui.CalcTextSize(hint_text).y
    draw_list:AddLine(
        imgui.ImVec2(imgui.GetCursorPos().x + imgui.GetWindowPos().x, line_y),
        imgui.ImVec2(imgui.GetCursorPos().x + imgui.GetWindowPos().x + pool.width, line_y),
        imgui.GetColorU32Vec4(pool.color), 2.0
    )

    -- ���� �����

    local resins = imgui.InputText("##" .. name, pool.buffer, sizeof(pool.buffer))

    -- ������������ ���������
    if not imgui.IsItemActive() then
        pool.inactive[2] = pool.inactive[2] or os.clock()
        pool.inactive[1], pool.active[1], pool.active[2] = true, false, nil
    elseif imgui.IsItemActive() or imgui.IsItemClicked() then
        pool.inactive[1], pool.inactive[2], pool.active[2] = false, nil, pool.active[2] or os.clock()
        pool.active[1] = true
    end

    -- �������� ���������
    local target_scale = (pool.active[1] or sizeof(pool.buffer) > 0) and 1.0 or 3.0
    local target_y = (pool.active[1] or sizeof(pool.buffer) > 0) and (pool.hint.old_pos - (imgui.GetFontSize() * 0.7) - 2) or pool.hint.old_pos
    pool.color = bringVec4To(pool.color, (pool.active[1] and color or pool.old_color), (pool.active[1] and pool.active[2] or pool.inactive[2]), 0.75)
    pool.hint.scale = bringFloatTo(pool.hint.scale, target_scale, (pool.active[1] and pool.active[2] or pool.inactive[2]), 0.55)
    pool.hint.pos.y = bringFloatTo(pool.hint.pos.y, target_y, (pool.active[1] and pool.active[2] or pool.inactive[2]), 0.25)

    -- ����������� ���������
    imgui.SetWindowFontScale(pool.hint.scale)
    draw_list:AddText(
        imgui.ImVec2(pool.hint.pos.x + imgui.GetWindowPos().x + imgui.GetStyle().FramePadding.x, pool.hint.pos.y + imgui.GetWindowPos().y + imgui.GetStyle().FramePadding.y),
        imgui.GetColorU32Vec4(pool.color), hint_text
    )

    -- �������������� ������
    imgui.SetWindowFontScale(1.0)
    imgui.PopItemWidth()
    imgui.PopStyleColor(3)
    imgui.PopStyleVar()
    return resins
end

function UI.CustomSelectable(labels, selected, size, speed, centering)
    local bool = false
    speed = speed and speed or 0.500
    local radius = size.y * 0.50
    local draw_list = imgui.GetWindowDrawList()
    if LastActiveTime == nil then LastActiveTime = {} end
    if LastActive == nil then LastActive = {} end
    local function ImSaturate(f)
        return f < 0.0 and 0.0 or (f > 1.0 and 1.0 or f)
    end
    for i, v in ipairs(labels) do
        local c = imgui.GetCursorPos()
        local p = imgui.GetCursorScreenPos()
        if imgui.InvisibleButton(v..'##'..i, size) then
            selected[0] = i
            LastActiveTime[v] = os.clock()
            LastActive[v] = true
            bool = true
        end
        imgui.SetCursorPos(c)
        local t = selected[0] == i and 1.0 or 0.0
        if LastActive[v] then
            local time = os.clock() - LastActiveTime[v]
            if time <= 0.3 then
                local t_anim = ImSaturate(time / speed)
                t = selected[0] == i and t_anim or 1.0 - t_anim
            else
                LastActive[v] = false
            end
        end
            local col_bg = imgui.GetColorU32Vec4(selected[0] == i and imgui.ImVec4(0.10, 0.10, 0.10, 0.60) or imgui.ImVec4(0,0,0,0))
            local col_box = imgui.GetColorU32Vec4(selected[0] == i and imgui.ImVec4(icolors.ActiveText[0], icolors.ActiveText[1], icolors.ActiveText[2], icolors.ActiveText[3]) or imgui.ImVec4(0,0,0,0))
            local col_hovered = imgui.GetStyle().Colors[imgui.Col.ButtonHovered]
            local col_hovered = imgui.GetColorU32Vec4(imgui.ImVec4(col_hovered.x, col_hovered.y, col_hovered.z, (imgui.IsItemHovered() and 0.2 or 0)))
            
            if selected[0] == i then draw_list:AddRectFilledMultiColor(imgui.ImVec2(p.x-size.x/6, p.y), imgui.ImVec2(p.x + (radius * 0.65) + t * size.x, p.y + size.y), imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button])) end
            --if selected[0] == i then draw_list:AddRectFilled(imgui.ImVec2(p.x-size.x, p.y), imgui.ImVec2(p.x + size.x, p.y + size.y), imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), 0.0) end
            draw_list:AddRectFilled(imgui.ImVec2(p.x-size.x/6, p.y), imgui.ImVec2(p.x + size.x+10, p.y + size.y), col_hovered, 0.0)
            imgui.SetCursorPos(imgui.ImVec2(c.x+(centering and (size.x-imgui.CalcTextSize(v).x)/2 or 15), c.y+(size.y-imgui.CalcTextSize(v).y)/2))
            imgui.TextColored(imgui.ImVec4(imgui.GetStyle().Colors[imgui.Col.Text]), v)
            --draw_list:AddRectFilled(imgui.ImVec2(p.x, p.y), imgui.ImVec2(p.x+3.5, p.y + size.y), col_box)
            imgui.SetCursorPos(imgui.ImVec2(c.x, c.y+size.y))
    end
    return bool
end


function UI.MainBox(str_id, size, rounding)
    local DL = imgui.GetWindowDrawList()
    local pos = imgui.GetCursorScreenPos()
    local segments = math.max(32, rounding / 3)
    local headerHeight = rounding

   -- ����� ��������� �� �������
    local color_top_left = imgui.GetColorU32Vec4(imgui.ImVec4(
        GT_MOD.config.ini.mainBoxColor1.r,
        GT_MOD.config.ini.mainBoxColor1.g,
        GT_MOD.config.ini.mainBoxColor1.b,
        GT_MOD.config.ini.mainBoxColor1.a
    ))
    local color_top_right = imgui.GetColorU32Vec4(imgui.ImVec4(
        GT_MOD.config.ini.mainBoxColor2.r,
        GT_MOD.config.ini.mainBoxColor2.g,
        GT_MOD.config.ini.mainBoxColor2.b,
        GT_MOD.config.ini.mainBoxColor2.a
    ))
    local color_bottom_left = imgui.GetColorU32Vec4(imgui.ImVec4(
        GT_MOD.config.ini.mainBoxColor3.r,
        GT_MOD.config.ini.mainBoxColor3.g,
        GT_MOD.config.ini.mainBoxColor3.b,
        GT_MOD.config.ini.mainBoxColor3.a
    ))
    local color_bottom_right = imgui.GetColorU32Vec4(imgui.ImVec4(
        GT_MOD.config.ini.mainBoxColor4.r,
        GT_MOD.config.ini.mainBoxColor4.g,
        GT_MOD.config.ini.mainBoxColor4.b,
        GT_MOD.config.ini.mainBoxColor4.a
    ))

    -- ������������� �����
    imgui.PushStyleColor(imgui.Col.ChildBg, imgui.ImVec4(0, 0, 0, 0))
    imgui.PushStyleVarFloat(imgui.StyleVar.ChildRounding, 0)
    imgui.PushStyleColor(imgui.Col.Border, imgui.ImVec4(0, 0, 0, 0))

    -- �������� ����������
    local min = pos
    local max = imgui.ImVec2(pos.x + size.x, pos.y + size.y)

    if rounding > 0 then
        -- ������� ��� ��������� ������������� �������������� � ����������
        local function DrawRoundedRectWithGradient(rect_min, rect_max, round, segs)
            -- �������� ����������� ����� � ����������
            local center_min = imgui.ImVec2(rect_min.x + round, rect_min.y + round)
            local center_max = imgui.ImVec2(rect_max.x - round, rect_max.y - round)
            
            -- ������ ����������� ������������� � ����������
            DL:AddRectFilledMultiColor(
                center_min,
                center_max,
                color_top_left,      -- ����� ����
                color_top_right,     -- ������ ����
                color_bottom_right,  -- ������ ���
                color_bottom_left    -- ����� ���
            )
            
            -- ������� �������������� ��� ���������� ������������ ����� ������
            -- ������� ������
            DL:AddRectFilledMultiColor(
                imgui.ImVec2(center_min.x, rect_min.y),
                imgui.ImVec2(center_max.x, center_min.y),
                color_top_left,
                color_top_right,
                color_top_right,
                color_top_left
            )
            
            -- ������ ������
            DL:AddRectFilledMultiColor(
                imgui.ImVec2(center_min.x, center_max.y),
                imgui.ImVec2(center_max.x, rect_max.y),
                color_bottom_left,
                color_bottom_right,
                color_bottom_right,
                color_bottom_left
            )
            
            -- ����� ������
            DL:AddRectFilledMultiColor(
                imgui.ImVec2(rect_min.x, center_min.y),
                imgui.ImVec2(center_min.x, center_max.y),
                color_top_left,
                color_top_left,
                color_bottom_left,
                color_bottom_left
            )
            
            -- ������ ������
            DL:AddRectFilledMultiColor(
                imgui.ImVec2(center_max.x, center_min.y),
                imgui.ImVec2(rect_max.x, center_max.y),
                color_top_right,
                color_top_right,
                color_bottom_right,
                color_bottom_right
            )
            
            -- ������� ��� ��������� ������������� ����
            local function DrawRoundedCorner(center, radius, start_angle, end_angle, corner_color)
                local points = imgui.new("ImVec2[?]", segs + 2)
                
                -- ����������� �����
                points[0] = center
                
                -- ����� ����
                for i = 0, segs do
                    local t = i / segs
                    local angle = start_angle + (end_angle - start_angle) * t
                    points[i + 1] = imgui.ImVec2(
                        center.x + radius * math.cos(angle),
                        center.y + radius * math.sin(angle)
                    )
                end
                
                -- ������� � ���������� ������
                DL:AddConvexPolyFilled(points, segs + 2, corner_color)
            end
            
            -- ����� ������� ���� 
            DrawRoundedCorner(
                imgui.ImVec2(rect_min.x + round, rect_min.y + round),
                round,
                math.pi,
                math.pi * 1.5,
                color_top_left
            )
            
            -- ������ ������� ���� 
            DrawRoundedCorner(
                imgui.ImVec2(rect_max.x - round, rect_min.y + round),
                round,
                math.pi * 1.5,
                math.pi * 2,
                color_top_right
            )
            
            -- ������ ������ ���� 
            DrawRoundedCorner(
                imgui.ImVec2(rect_max.x - round, rect_max.y - round),
                round,
                0,
                math.pi * 0.5,
                color_bottom_right
            )
            
            -- ����� ������ ����
            DrawRoundedCorner(
                imgui.ImVec2(rect_min.x + round, rect_max.y - round),
                round,
                math.pi * 0.5,
                math.pi,
                color_bottom_left
            )
        end
        
        -- �������� ������������ ������������� � ����������
        DrawRoundedRectWithGradient(min, max, rounding, segments)
        
    else
        -- ������ ������������� � ���������� ���� ���������� 0
        DL:AddRectFilledMultiColor(
            min,
            max,
            color_top_left,
            color_top_right,
            color_bottom_right,
            color_bottom_left
        )
    end

    -- ������� ��������� Child
    imgui.BeginChild(str_id, size, true)
    
    -- ��������������� �����
    imgui.PopStyleColor(2)
    imgui.PopStyleVar()
end

function UI.DrawEye(centerX, centerY, eyeRadius, pupilRadius, useStyleColors)
    local drawList = imgui.GetWindowDrawList()
    
    -- �������� ����� �� ������ ��� ���������� �������� �� ���������
    local outerColor, innerColor, pupilColor, highlightColor
    
    if useStyleColors then
        -- ���������� ����� �� ������ ImGui
        local style = imgui.GetStyle()
        local buttonColor = style.Colors[imgui.Col.Button]
        local buttonHovered = style.Colors[imgui.Col.ButtonHovered]
        local buttonActive = style.Colors[imgui.Col.ButtonActive]
        local textColor = style.Colors[imgui.Col.Text]
        
        outerColor = imgui.GetColorU32Vec4(imgui.ImVec4(
            buttonColor.x * 0.8,
            buttonColor.y * 0.8,
            buttonColor.z * 0.8,
            buttonColor.w
        ))
        innerColor = imgui.GetColorU32Vec4(imgui.ImVec4(
            buttonHovered.x,
            buttonHovered.y,
            buttonHovered.z,
            buttonHovered.w
        ))
        pupilColor = imgui.GetColorU32Vec4(imgui.ImVec4(
            textColor.x * 0.2,
            textColor.y * 0.2,
            textColor.z * 0.2,
            textColor.w
        ))
        highlightColor = imgui.GetColorU32Vec4(imgui.ImVec4(1, 1, 1, 0.9))
    else
        -- ����� �� ���������
        outerColor = imgui.GetColorU32Vec4(imgui.ImVec4(0.7, 0.5, 0.9, 1.0))
        innerColor = imgui.GetColorU32Vec4(imgui.ImVec4(0.9, 0.8, 1.0, 1.0))
        pupilColor = imgui.GetColorU32Vec4(imgui.ImVec4(0.1, 0.08, 0.06, 1.0))
        highlightColor = imgui.GetColorU32Vec4(imgui.ImVec4(1, 1, 1, 0.9))
    end
    
    -- ������� ��� ��������� ����������� ������ �����
    local function DrawEyeGradient()
        local segments = 120
        
        -- ���������� ������� �����
        drawList:AddCircleFilled(
            imgui.ImVec2(centerX, centerY),
            eyeRadius,
            innerColor,
            segments
        )
        
        -- ������� ������ � ����������� �������������
        local ringThickness = eyeRadius - pupilRadius * 2
        local ringSteps = 80
        
        for i = 0, ringSteps - 1 do
            local progress = i / ringSteps
            local outerRadius = pupilRadius * 2 + ringThickness * progress
            local innerRadius = pupilRadius * 2 + ringThickness * ((i - 1) / ringSteps)
            
            if innerRadius < pupilRadius * 2 then
                innerRadius = pupilRadius * 2
            end
            
            local alpha = progress * 0.8
            local color = outerColor
            color = imgui.GetColorU32Vec4(imgui.ImVec4(
                imgui.ImColor(color).Value.x,
                imgui.ImColor(color).Value.y,
                imgui.ImColor(color).Value.z,
                alpha
            ))
            
            if outerRadius > innerRadius then
                drawList:AddCircle(
                    imgui.ImVec2(centerX, centerY),
                    outerRadius,
                    color,
                    segments,
                    outerRadius - innerRadius
                )
            end
        end
    end
    
    -- ������� ��� ��������� ������������� ������
    local function DrawPupil()
        -- �������� ������
        drawList:AddCircleFilled(
            imgui.ImVec2(centerX, centerY),
            pupilRadius,
            pupilColor,
            64
        )
        
        -- �������� �������� (������� �������)
        local irisRadius = pupilRadius * 0.9
        local irisColor = imgui.GetColorU32Vec4(imgui.ImVec4(
            imgui.ImColor(pupilColor).Value.x * 1.3,
            imgui.ImColor(pupilColor).Value.y * 1.3,
            imgui.ImColor(pupilColor).Value.z * 1.3,
            1.0
        ))
        drawList:AddCircleFilled(
            imgui.ImVec2(centerX, centerY),
            irisRadius,
            irisColor,
            64
        )
        
        -- ���������� ����� �������
        local innerIrisRadius = pupilRadius * 0.7
        drawList:AddCircleFilled(
            imgui.ImVec2(centerX, centerY),
            innerIrisRadius,
            pupilColor,
            64
        )
        
        -- �������� ����
        local highlight1Radius = pupilRadius * 0.4
        local highlight1X = centerX - pupilRadius * 0.25
        local highlight1Y = centerY - pupilRadius * 0.25
        drawList:AddCircleFilled(
            imgui.ImVec2(highlight1X, highlight1Y),
            highlight1Radius,
            highlightColor,
            32
        )
        
        -- ��������� ����
        local highlight2Radius = pupilRadius * 0.2
        local highlight2X = centerX - pupilRadius * 0.15
        local highlight2Y = centerY - pupilRadius * 0.4
        drawList:AddCircleFilled(
            imgui.ImVec2(highlight2X, highlight2Y),
            highlight2Radius,
            highlightColor,
            24
        )
        
        -- ������ �������� ������ ������
        drawList:AddCircle(
            imgui.ImVec2(centerX, centerY),
            pupilRadius * 1.1,
            imgui.GetColorU32Vec4(imgui.ImVec4(
                imgui.ImColor(pupilColor).Value.x,
                imgui.ImColor(pupilColor).Value.y,
                imgui.ImColor(pupilColor).Value.z,
                0.2
            )),
            64,
            2.0
        )
    end
    
    -- ������ ����
    DrawEyeGradient()
    DrawPupil()
    
    -- ������� ������
    drawList:AddCircle(
        imgui.ImVec2(centerX, centerY),
        eyeRadius,
        outerColor,
        120,
        2.0
    )
end

UI.HeaderButton = function(bool, str_id)
    local DL = imgui.GetWindowDrawList()
    local ToU32 = imgui.ColorConvertFloat4ToU32
    local result = false
    local label = string.gsub(str_id, "##.*$", "")
    local duration = { 0.5, 0.3 }
    local cols = {
        idle = imgui.GetStyle().Colors[imgui.Col.Text],
        hovr = imgui.GetStyle().Colors[imgui.Col.Text],
        slct = imgui.GetStyle().Colors[imgui.Col.FrameBgHovered]
    }

    if not AI_HEADERBUT then AI_HEADERBUT = {} end
     if not AI_HEADERBUT[str_id] then
        AI_HEADERBUT[str_id] = {
            color = bool and cols.slct or cols.idle,
            clock = os.clock() + duration[1],
            h = {
                state = bool,
                alpha = bool and 1.00 or 0.00,
                clock = os.clock() + duration[2],
            }
        }
    end
    local pool = AI_HEADERBUT[str_id]

    local degrade = function(before, after, start_time, duration)
        local result = before
        local timer = os.clock() - start_time
        if timer >= 0.00 then
            local offs = {
                x = after.x - before.x,
                y = after.y - before.y,
                z = after.z - before.z,
                w = after.w - before.w
            }

            result.x = result.x + ( (offs.x / duration) * timer )
            result.y = result.y + ( (offs.y / duration) * timer )
            result.z = result.z + ( (offs.z / duration) * timer )
            result.w = result.w + ( (offs.w / duration) * timer )
        end
        return result
    end

    local pushFloatTo = function(p1, p2, clock, duration)
        local result = p1
        local timer = os.clock() - clock
        if timer >= 0.00 then
            local offs = p2 - p1
            result = result + ((offs / duration) * timer)
        end
        return result
    end

    local set_alpha = function(color, alpha)
        return imgui.ImVec4(color.x, color.y, color.z, alpha or 1.00)
    end

    imgui.BeginGroup()
        local pos = imgui.GetCursorPos()
        local p = imgui.GetCursorScreenPos()
      
        imgui.TextColored(pool.color, label)
        local s = imgui.GetItemRectSize()
        local hovered = imgui.IsItemHovered()
        local clicked = imgui.IsItemClicked()
      
        if pool.h.state ~= hovered and not bool then
            pool.h.state = hovered
            pool.h.clock = os.clock()
        end
      
        if clicked then
            pool.clock = os.clock()
            result = true
        end

        if os.clock() - pool.clock <= duration[1] then
            pool.color = degrade(
                imgui.ImVec4(pool.color),
                bool and cols.slct or (hovered and cols.hovr or cols.idle),
                pool.clock,
                duration[1]
            )
        else
            pool.color = bool and cols.slct or (hovered and cols.hovr or cols.idle)
        end

        if pool.h.clock ~= nil then
            if os.clock() - pool.h.clock <= duration[2] then
                pool.h.alpha = pushFloatTo(
                    pool.h.alpha,
                    pool.h.state and 1.00 or 0.00,
                    pool.h.clock,
                    duration[2]
                )
            else
                pool.h.alpha = pool.h.state and 1.00 or 0.00
                if not pool.h.state then
                    pool.h.clock = nil
                end
            end

            local max = s.x / 2
            local Y = p.y + s.y + 3
            local mid = p.x + max

            DL:AddLine(imgui.ImVec2(mid, Y), imgui.ImVec2(mid + (max * pool.h.alpha), Y), ToU32(set_alpha(pool.color, pool.h.alpha)), 3)
            DL:AddLine(imgui.ImVec2(mid, Y), imgui.ImVec2(mid - (max * pool.h.alpha), Y), ToU32(set_alpha(pool.color, pool.h.alpha)), 3)
        end

    imgui.EndGroup()
    return result
end

function UI.Link(link, text)
    text = text or link
    local tSize = imgui.CalcTextSize(text)
    local p = imgui.GetCursorScreenPos()
    local DL = imgui.GetWindowDrawList()
    local col = { imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Button]), imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.ButtonHovered]) }
    if imgui.InvisibleButton("##" .. link, tSize) then os.execute("explorer " .. link) end
    local color = imgui.IsItemHovered() and col[1] or col[2]
    DL:AddText(p, color, text)
    --DL:AddLine(imgui.ImVec2(p.x, p.y + tSize.y), imgui.ImVec2(p.x + tSize.x, p.y + tSize.y), color)
end

function UI.CustomMenu(labels, selected, size, speed, centering)
    local bool = false
    speed = speed or 0.600
    local draw_list = imgui.GetWindowDrawList()
    local rounding = 20
    local segments = 120
    local vertical_padding = 2
    local adjusted_size = imgui.ImVec2(size.x - 10, size.y + vertical_padding * 2)

    if LastActiveTime == nil then LastActiveTime = {} end
    if LastActive == nil then LastActive = {} end
    if AnimStartTime == nil then AnimStartTime = {} end
    if AnimCompleted == nil then AnimCompleted = {} end
    
    local function ImSaturate(f)
        return f < 0.0 and 0.0 or (f > 1.0 and 1.0 or f)
    end
    
    local function DrawFlawlessRoundedLeftWithGradient(p_min, p_max, col_left, col_right)
        local adjusted_min = imgui.ImVec2(p_min.x, p_min.y + vertical_padding)
        local adjusted_max = imgui.ImVec2(p_max.x - 1, p_max.y - vertical_padding)
        local adjusted_rounding = rounding - 1
        
        local mid_point = (adjusted_max.x - adjusted_min.x) * 0.4
        
        if mid_point > adjusted_rounding then
            draw_list:AddRectFilled(
                imgui.ImVec2(adjusted_min.x + adjusted_rounding, adjusted_min.y),
                imgui.ImVec2(adjusted_min.x + mid_point, adjusted_max.y),
                col_left
            )
        end
        
        draw_list:AddRectFilledMultiColor(
            imgui.ImVec2(adjusted_min.x + mid_point, adjusted_min.y),
            adjusted_max,
            col_left,
            col_right,
            col_right,
            col_left
        )
        
        local center_y = adjusted_min.y + (adjusted_max.y - adjusted_min.y)/2
        local center = imgui.ImVec2(adjusted_min.x + adjusted_rounding, center_y)
        
        draw_list:PathClear()
        draw_list:PathArcTo(center, adjusted_rounding, math.pi/2, math.pi*1.5, segments/2)
        draw_list:PathFillConvex(col_left)
        
        draw_list:AddRectFilled(
            imgui.ImVec2(adjusted_min.x + adjusted_rounding, adjusted_min.y),
            imgui.ImVec2(adjusted_min.x + adjusted_rounding + 1, center_y - adjusted_rounding),
            col_left
        )
        
        draw_list:AddRectFilled(
            imgui.ImVec2(adjusted_min.x + adjusted_rounding, center_y + adjusted_rounding),
            imgui.ImVec2(adjusted_min.x + adjusted_rounding + 1, adjusted_max.y),
            col_left
        )
    end

    local function DrawAnimatedFill(p_min, p_max, item_id, is_selected)
        if not is_selected then return end
        
        if not AnimStartTime[item_id] then
            AnimStartTime[item_id] = os.clock()
            AnimCompleted[item_id] = false
        end
        
        if AnimCompleted[item_id] then
            local fill_color_left = imgui.GetColorU32Vec4(imgui.ImVec4(
                GT_MOD.config.ini.ColorNavi.r,
                GT_MOD.config.ini.ColorNavi.g,
                GT_MOD.config.ini.ColorNavi.b,
                GT_MOD.config.ini.ColorNavi.a
            ))
            local fill_color_right = imgui.GetColorU32Vec4(imgui.ImVec4(
                GT_MOD.config.ini.ColorNavi.r,
                GT_MOD.config.ini.ColorNavi.g,
                GT_MOD.config.ini.ColorNavi.b,
                0.0
            ))
            DrawFlawlessRoundedLeftWithGradient(p_min, p_max, fill_color_left, fill_color_right)
            return
        end
        
        local current_time = os.clock()
        local elapsed = current_time - AnimStartTime[item_id]
        local progress = ImSaturate(elapsed / speed)
        
        if progress >= 1.0 then
            AnimCompleted[item_id] = true
            progress = 1.0
        end
        
        local fill_color_left = imgui.GetColorU32Vec4(imgui.ImVec4(
            GT_MOD.config.ini.ColorNavi.r,
            GT_MOD.config.ini.ColorNavi.g,
            GT_MOD.config.ini.ColorNavi.b,
            GT_MOD.config.ini.ColorNavi.a * progress
        ))
        local fill_color_right = imgui.GetColorU32Vec4(imgui.ImVec4(
            GT_MOD.config.ini.ColorNavi.r,
            GT_MOD.config.ini.ColorNavi.g,
            GT_MOD.config.ini.ColorNavi.b,
            0.0
        ))
        
        local total_width = p_max.x - p_min.x
        local fill_width = total_width * progress
        
        if fill_width > 0 then
            local adjusted_min = imgui.ImVec2(p_min.x, p_min.y + vertical_padding)
            local adjusted_max = imgui.ImVec2(p_min.x + fill_width, p_max.y - vertical_padding)
            local adjusted_rounding = rounding - 1
            
            if fill_width >= adjusted_rounding then
                local center_y = adjusted_min.y + (adjusted_max.y - adjusted_min.y)/2
                local center = imgui.ImVec2(adjusted_min.x + adjusted_rounding, center_y)
                
                draw_list:PathClear()
                draw_list:PathArcTo(center, adjusted_rounding, math.pi/2, math.pi*1.5, segments/2)
                draw_list:PathFillConvex(fill_color_left)
                
                if fill_width > adjusted_rounding then
                    local rect_min_x = adjusted_min.x + adjusted_rounding
                    local rect_max_x = math.min(p_min.x + fill_width, p_max.x)
                    
                    local mid_point = rect_min_x + (rect_max_x - rect_min_x) * 0.4
                    
                    if mid_point > rect_min_x then
                        draw_list:AddRectFilled(
                            imgui.ImVec2(rect_min_x, adjusted_min.y),
                            imgui.ImVec2(mid_point, adjusted_max.y),
                            fill_color_left
                        )
                    end
                    
                    draw_list:AddRectFilledMultiColor(
                        imgui.ImVec2(mid_point, adjusted_min.y),
                        imgui.ImVec2(rect_max_x, adjusted_max.y),
                        fill_color_left,
                        fill_color_right,
                        fill_color_right,
                        fill_color_left
                    )
                end
            else
                local center_y = adjusted_min.y + (adjusted_max.y - adjusted_min.y)/2
                local center = imgui.ImVec2(adjusted_min.x + adjusted_rounding, center_y)
                
                local angle = math.pi/2 + (math.pi * (fill_width / adjusted_rounding))
                
                draw_list:PathClear()
                draw_list:PathArcTo(center, adjusted_rounding, math.pi/2, angle, segments/2)
                draw_list:PathLineTo(center)
                draw_list:PathFillConvex(fill_color_left)
            end
        end
    end

    for i, v in ipairs(labels) do
        local c = imgui.GetCursorPos()
        local p = imgui.GetCursorScreenPos()
        local item_id = v..'##'..i
        
        if imgui.InvisibleButton(item_id, adjusted_size) then
            if selected[0] == i then
                AnimStartTime[item_id] = nil
                AnimCompleted[item_id] = nil
            else
                selected[0] = i
                for _, label in ipairs(labels) do
                    local id = label..'##'..i
                    AnimStartTime[id] = nil
                    AnimCompleted[id] = nil
                end
            end
            LastActiveTime[v] = os.clock()
            LastActive[v] = true
            bool = true
        end
        
        imgui.SetCursorPos(c)
        local t = selected[0] == i and 1.0 or 0.0
        
        if LastActive[v] then
            local time = os.clock() - LastActiveTime[v]
            if time <= 0.3 then
                local t_anim = ImSaturate(time / speed)
                t = selected[0] == i and t_anim or 1.0 - t_anim
            else
                LastActive[v] = false
            end
        end
        
        local is_selected = selected[0] == i
        local is_hovered = imgui.IsItemHovered()
        
        local bg_color_left = imgui.GetColorU32Vec4(imgui.ImVec4(0.15, 0.15, 0.15, 0.3))
        local bg_color_right = imgui.GetColorU32Vec4(imgui.ImVec4(0.15, 0.15, 0.15, 0.0))
        
        local hover_color = imgui.GetStyle().Colors[imgui.Col.ButtonHovered]
        local hover_color_left = imgui.GetColorU32Vec4(imgui.ImVec4(
            hover_color.x, 
            hover_color.y, 
            hover_color.z, 
            is_hovered and 0.2 or 0
        ))
        local hover_color_right = imgui.GetColorU32Vec4(imgui.ImVec4(
            hover_color.x, 
            hover_color.y, 
            hover_color.z, 
            0.0
        ))
        
        DrawAnimatedFill(p, imgui.ImVec2(p.x + adjusted_size.x, p.y + adjusted_size.y), item_id, is_selected)
        
        if is_hovered then
            DrawFlawlessRoundedLeftWithGradient(p, imgui.ImVec2(p.x + adjusted_size.x, p.y + adjusted_size.y), hover_color_left, hover_color_right)
        end
        
 
        local text_size = imgui.CalcTextSize(v)
        local item_height = adjusted_size.y
        local vertical_center = (item_height - text_size.y) / 2
        
        -- ������������� ������� ��� ������/������
        if centering then
            local horizontal_center = (adjusted_size.x - text_size.x) / 2
            imgui.SetCursorPos(imgui.ImVec2(c.x + horizontal_center, c.y + vertical_center))
        else
            -- ��� ������ ������������ � ������������� ��������
            imgui.SetCursorPos(imgui.ImVec2(c.x + 15, c.y + vertical_center))
        end
        
        -- ������ ����� � �������
        if is_selected then
            imgui.TextColored(imgui.ImVec4(1, 1, 1, 1), v)
        else
            imgui.TextColored(imgui.ImVec4(0.9, 0.9, 0.9, 0.9), v)
        end
        
        imgui.SetCursorPos(imgui.ImVec2(c.x, c.y + adjusted_size.y))
    end
    
    return bool
end

function UI.drawFolder(drawList, pos, size, color, rounding, segments, headerHeight, headerRounding, headerWidth)
    -- ���� ������ ������ ���������, ������ ���
    if headerHeight and headerHeight > 0 then
        local headerPos = imgui.ImVec2(pos.x, pos.y)
        
        -- ������ ������� ����� ��������� � �������������
        -- ������� ������ ���������
        drawList:AddRectFilled(
            imgui.ImVec2(headerPos.x + headerRounding, headerPos.y),
            imgui.ImVec2(headerPos.x + headerWidth - headerRounding, headerPos.y + headerRounding),
            color
        )
        
        -- �������� ������������� ��������� (��� ������� �����)
        drawList:AddRectFilled(
            imgui.ImVec2(headerPos.x, headerPos.y + headerRounding),
            imgui.ImVec2(headerPos.x + headerWidth, headerPos.y + headerHeight),
            color
        )
        
        -- ������� ��� ��������� �������� ����� (������ ������� �����)
        local function AddTopQuarterCircle(center, start_angle)
            local points = imgui.new("ImVec2[?]", segments + 2)
            points[0] = center
            for i = 0, segments do
                local angle = start_angle + (math.pi * 0.5) * (i / segments)
                points[i+1] = imgui.ImVec2(
                    center.x + headerRounding * math.cos(angle),
                    center.y + headerRounding * math.sin(angle)
                )
            end
            drawList:AddConvexPolyFilled(points, segments + 2, color)
        end
        
        -- ������ ������ ������� ����������� ���� ���������
        AddTopQuarterCircle(imgui.ImVec2(headerPos.x + headerRounding, headerPos.y + headerRounding), math.pi)       -- ����� ����
        AddTopQuarterCircle(imgui.ImVec2(headerPos.x + headerWidth - headerRounding, headerPos.y + headerRounding), math.pi * 1.5) -- ������ ����
        
        -- ������� �������� ����� ���� �� ������ ���������
        pos.y = pos.y + headerHeight
        size.y = size.y - headerHeight  -- ��������� ������ �������� �����
    end


    -- ������� ������ (���������� �� ������ ���� ��� ����������)
    drawList:AddRectFilled(
        imgui.ImVec2(pos.x, pos.y),  -- �������� �� ������ ���� �����
        imgui.ImVec2(pos.x + size.x - rounding, pos.y + rounding),
        color
    )
    -- ������ ������
    drawList:AddRectFilled(
        imgui.ImVec2(pos.x + rounding, pos.y + size.y - rounding),
        imgui.ImVec2(pos.x + size.x - rounding, pos.y + size.y),
        color
    )
    -- ����������� ������������� (��� �������/������ ������)
    drawList:AddRectFilled(
        imgui.ImVec2(pos.x, pos.y + rounding),
        imgui.ImVec2(pos.x + size.x, pos.y + size.y - rounding),
        color
    )

    -- ������� ��� ��������� �������� �����
    local function AddQuarterCircle(center, start_angle)
        local points = imgui.new("ImVec2[?]", segments + 2)
        points[0] = center
        for i = 0, segments do
            local angle = start_angle + (math.pi * 0.5) * (i / segments)
            points[i+1] = imgui.ImVec2(
                center.x + rounding * math.cos(angle),
                center.y + rounding * math.sin(angle)
            )
        end
        drawList:AddConvexPolyFilled(points, segments + 2, color)
    end

    -- ������ ������ 3 ����������� ���� (��� ������ ��������)
    AddQuarterCircle(imgui.ImVec2(pos.x + size.x - rounding, pos.y + rounding), math.pi * 1.5) -- ������ ����
    AddQuarterCircle(imgui.ImVec2(pos.x + size.x - rounding, pos.y + size.y - rounding), 0)    -- ������ ���
    AddQuarterCircle(imgui.ImVec2(pos.x + rounding, pos.y + size.y - rounding), math.pi * 0.5) -- ����� ���
    
    
end


UI.EskimoStick_Animations = {}

function UI.EskimoStick(id, pos, size, image_radius, image_texture, bg_color, hover_color, buttons)
    local draw_list = imgui.GetWindowDrawList()
    local image_size = image_radius * 2
    
    -- ������������� ��������
    if not UI.EskimoStick_Animations[id] then
        UI.EskimoStick_Animations[id] = {
            progress = 0,
            last_time = os.clock(),
            last_hover_state = false
        }
    end
    
    local anim = UI.EskimoStick_Animations[id]
    local current_time = os.clock()
    local delta_time = current_time - anim.last_time
    anim.last_time = current_time
    
    -- ������� ��������
    local image_min = imgui.ImVec2(
        pos.x + size.x - image_size - 5 - (size.x * 0.3 * anim.progress),
        pos.y + (size.y - image_size) / 2
    )
    local image_max = imgui.ImVec2(image_min.x + image_size, image_min.y + image_size)
    
    -- ���������� ���������
    local image_hovered = imgui.IsMouseHoveringRect(image_min, image_max)
    local stick_hovered = false
    
    if anim.progress > 0 then
        local stick_start = image_max.x + 5
        local stick_end = pos.x + size.x
        if stick_end > stick_start then
            stick_hovered = imgui.IsMouseHoveringRect(
                imgui.ImVec2(stick_start, pos.y),
                imgui.ImVec2(stick_end, pos.y + size.y)
            )
        end
    end
    
    local is_hovered = image_hovered or stick_hovered
    
    -- ������� ��������� ���������
    if is_hovered ~= anim.last_hover_state then
        anim.last_hover_state = is_hovered
    end
    
    local target = anim.last_hover_state and 1.0 or 0.0
    anim.progress = anim.progress + (target - anim.progress) * math.min(delta_time * 8, 1.0)
    
    -- ������ �������
    local stick_rect = nil
    if anim.progress > 0 then
        local stick_start = image_max.x + 5
        local stick_end = pos.x + size.x
        
        if stick_end > stick_start then
            local bg_alpha = 0.1 * anim.progress
            local bg_u32 = imgui.GetColorU32Vec4(imgui.ImVec4(bg_color.x, bg_color.y, bg_color.z, bg_alpha))
            
            draw_list:AddRectFilled(
                imgui.ImVec2(stick_start, pos.y),
                imgui.ImVec2(stick_end, pos.y + size.y),
                bg_u32, 12, imgui.ImDrawFlags_RoundCornersRight
            )
            
            stick_rect = {
                min = imgui.ImVec2(stick_start, pos.y),
                max = imgui.ImVec2(stick_end, pos.y + size.y)
            }
        end
    end
    
    -- ������ ��������
    if image_texture then
        draw_list:AddImage(
            image_texture,
            image_min,
            image_max,
            imgui.ImVec2(0, 0),
            imgui.ImVec2(1, 1),
            imgui.GetColorU32Vec4(imgui.ImVec4(GT_MOD.config.ini.logocolor.r, GT_MOD.config.ini.logocolor.g, GT_MOD.config.ini.logocolor.b, GT_MOD.config.ini.logocolor.a))
        )
    end
    
    -- ��������� ������ ����� InvisibleButton
    local any_button_pressed = false
    if stick_rect and buttons and anim.progress > 0.7 then
        local button_size = 24
        local spacing = 15
        local total_width = (#buttons * (button_size + spacing)) - spacing
        local button_y = stick_rect.min.y + (stick_rect.max.y - stick_rect.min.y - button_size) / 2
        local button_x = stick_rect.max.x - total_width - 10
        
        for i, button in ipairs(buttons) do
            if button.func and button.icon then
                local btn_pos = imgui.ImVec2(button_x + (i-1)*(button_size + spacing), button_y)
                local btn_min = btn_pos
                local btn_max = imgui.ImVec2(btn_pos.x + button_size, btn_pos.y + button_size)
                
                -- ��������� ������ ��� ��������� ������
                imgui.SetCursorScreenPos(btn_min)
                imgui.InvisibleButton("btn_"..id..i, imgui.ImVec2(button_size, button_size))
                
                if imgui.IsItemHovered() then
                    -- ������ ������ � hover-��������
                    if button.font then
                        imgui.PushFont(button.font)
                        local text_size = imgui.CalcTextSize(button.icon)
                        local text_pos = imgui.ImVec2(
                            btn_pos.x + (button_size - text_size.x) * 0.5,
                            btn_pos.y + (button_size - text_size.y) * 0.5
                        )
                        draw_list:AddText(
                            text_pos,
                            imgui.GetColorU32Vec4(imgui.ImVec4(1, 1, 1, 1)),
                            button.icon
                        )
                        imgui.PopFont()
                    else
                        local text_size = imgui.CalcTextSize(button.icon)
                        local text_pos = imgui.ImVec2(
                            btn_pos.x + (button_size - text_size.x) * 0.5,
                            btn_pos.y + (button_size - text_size.y) * 0.5
                        )
                        draw_list:AddText(
                            text_pos,
                            imgui.GetColorU32Vec4(imgui.ImVec4(1, 1, 1, 1)),
                            button.icon
                        )
                    end
                    
                    -- ���������
                    if button.tooltip then
                        imgui.BeginTooltip()
                        imgui.Text(button.tooltip)
                        imgui.EndTooltip()
                    end
                    
                    -- ��������� �����
                    if imgui.IsItemClicked(0) then
                        any_button_pressed = true
                        button.func()
                    end
                else
                    -- ������ ������� ������
                    if button.font then
                        imgui.PushFont(button.font)
                        local text_size = imgui.CalcTextSize(button.icon)
                        local text_pos = imgui.ImVec2(
                            btn_pos.x + (button_size - text_size.x) * 0.5,
                            btn_pos.y + (button_size - text_size.y) * 0.5
                        )
                        draw_list:AddText(
                            text_pos,
                            imgui.GetColorU32Vec4(imgui.ImVec4(1, 1, 1, 0.7)),
                            button.icon
                        )
                        imgui.PopFont()
                    else
                        local text_size = imgui.CalcTextSize(button.icon)
                        local text_pos = imgui.ImVec2(
                            btn_pos.x + (button_size - text_size.x) * 0.5,
                            btn_pos.y + (button_size - text_size.y) * 0.5
                        )
                        draw_list:AddText(
                            text_pos,
                            imgui.GetColorU32Vec4(imgui.ImVec4(1, 1, 1, 0.7)),
                            button.icon
                        )
                    end
                end
            end
        end
    end
    
    return is_hovered and not any_button_pressed
end

function UI.AddTextColoredHex(DL, pos, color, text, out, outcol, fontsize, font)
    local function explode_argb(argb)
        local a = bit.band(bit.rshift(argb, 24), 0xFF)
        local r = bit.band(bit.rshift(argb, 16), 0xFF)
        local g = bit.band(bit.rshift(argb, 8), 0xFF)
        local b = bit.band(argb, 0xFF)
        return a, r, g, b
    end
    local DL, fontsize, out, outcol = DL or imgui.GetWindowDrawList(), fontsize or 14, out or 0, outcol or imgui.ImVec4(0, 0, 0, 0.5)
    local charIndex, lastColorCharIndex, lastColor = 0, -100, color
    if font then
        imgui.PushFont(font)
    end
    for Char in text:gmatch('.') do
        charIndex = charIndex + 1
        if Char == '{' and text:sub(charIndex + 7, charIndex + 7) == '}' then
            lastColorCharIndex, lastColor = charIndex, text:sub(charIndex + 1, charIndex + 6)
        end
        if charIndex < lastColorCharIndex or charIndex > lastColorCharIndex+7 then
            local a,r,g,b = explode_argb(type(lastColor) == 'string' and '0xFF'..lastColor or color)
            if out > 0 then
                DL:AddTextFontPtr(font, fontsize, imgui.ImVec2(pos.x + out, pos.y + out), imgui.GetColorU32Vec4(outcol), u8(Char))
                DL:AddTextFontPtr(font, fontsize, imgui.ImVec2(pos.x - out, pos.y - out), imgui.GetColorU32Vec4(outcol), u8(Char))
                DL:AddTextFontPtr(font, fontsize, imgui.ImVec2(pos.x + out, pos.y - out), imgui.GetColorU32Vec4(outcol), u8(Char))
                DL:AddTextFontPtr(font, fontsize, imgui.ImVec2(pos.x - out, pos.y + out), imgui.GetColorU32Vec4(outcol), u8(Char))
            end
            DL:AddTextFontPtr(font, fontsize, pos, imgui.GetColorU32Vec4(imgui.ImVec4(r / 255, g / 255, b / 255, 1)), u8(Char))          
            pos.x = pos.x + imgui.CalcTextSize(u8(Char)).x + (Char == ' ' and 2 or 0)
        end
    end
    if font then
        imgui.PopFont()
    end
end

return UI

end