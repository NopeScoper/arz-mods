return function(GT_MOD)

local TimecycEditor = {} -- module

local imgui = require("mimgui")
local ffi = require("ffi")

local new, sizeof, str = imgui.new, ffi.sizeof, ffi.string
local fa = require("fAwesome5")
local encoding = require("encoding")
encoding.default = "CP1251"
local u8 = encoding.UTF8

local checkboxes, sliders, buffers = GT_MOD.UI.checkboxes, GT_MOD.UI.sliders, GT_MOD.UI.buffers

local weather = {
	[0]  = u8"�KC�PACO��E��A� LA",
	[1]  = u8"CO��E��A� LA",
	[2]  = u8"�KC�PACO��E��A� C�O� LA",
	[3]  = u8"CO��E��A� � C�O� LA",
	[4]  = u8"�E�PE��A� LA",
	[5]  = u8"CO��E��A� SF",
	[6]  = u8"�KC�PACO��E��A� SF",
	[7]  = u8"O��A��A� SF",
	[8]  = u8"�O�����A� SF",
	[9]  = u8"�Y�A��A� SF",
	[10] = u8"CO��E��A� VEGAS",
	[11] = u8"�KC�PACO��E��A� VEGAS",
	[12] = u8"O��A��A� VEGAS",
	[13] = u8"�KC�PACO��E��A� �A�OPO��A�",
	[14] = u8"CO��E��A� �A�OPO��A�",
	[15] = u8"�E�PE��A� �A�OPO��A�",
	[16] = u8"�O�����A� �A�OPO��A�",
	[17] = u8"�KC�PA CO��E��A� �YC����",
	[18] = u8"CO��E��A� �YC����",
	[19] = u8"�YP� � �YC����",
	[20] = u8"�O� �O�O�",
	[21] = u8"�O�. ��E�A 1",
	[22] = u8"�O�. ��E�A 2"
}
local weatherchar = imgui.new['const char*'][#weather+1](weather)

local CTimeCycle = {}

local function getuint32(adr)
    return readMemory(adr, 4, true)
end


function CTimeCycle_DATA()
	CTimeCycle.m_nAmbientRed 				= ffi.cast("unsigned char*", getuint32(0x560C61))
	CTimeCycle.m_nAmbientGreen 			    = ffi.cast("unsigned char*", getuint32(0x55F4D6))
	CTimeCycle.m_nAmbientBlue 				= ffi.cast("unsigned char*", getuint32(0x55F4E8))
	CTimeCycle.m_nAmbientRed_Obj 			= ffi.cast("unsigned char*", getuint32(0x55F4FA))
	CTimeCycle.m_nAmbientGreen_Obj 		    = ffi.cast("unsigned char*", getuint32(0x55F50C))
	CTimeCycle.m_nAmbientBlue_Obj 			= ffi.cast("unsigned char*", getuint32(0x55F51E))
	CTimeCycle.m_nSkyTopRed 				= ffi.cast("unsigned char*", getuint32(0x55F531))
	CTimeCycle.m_nSkyTopGreen 				= ffi.cast("unsigned char*", getuint32(0x55F53D))
	CTimeCycle.m_nSkyTopBlue 				= ffi.cast("unsigned char*", getuint32(0x55F549))
	CTimeCycle.m_nSkyBottomRed				= ffi.cast("unsigned char*", getuint32(0x55F555))
	CTimeCycle.m_nSkyBottomGreen 			= ffi.cast("unsigned char*", getuint32(0x55F561))
	CTimeCycle.m_nSkyBottomBlue 			= ffi.cast("unsigned char*", getuint32(0x55F56D))
	CTimeCycle.m_nSunCoreRed 				= ffi.cast("unsigned char*", getuint32(0x55F579))
	CTimeCycle.m_nSunCoreGreen 			    = ffi.cast("unsigned char*", getuint32(0x55F585))
	CTimeCycle.m_nSunCoreBlue 				= ffi.cast("unsigned char*", getuint32(0x55F591))
	CTimeCycle.m_nSunCoronaRed 			    = ffi.cast("unsigned char*", getuint32(0x55F59D))
	CTimeCycle.m_nSunCoronaGreen 			= ffi.cast("unsigned char*", getuint32(0x55F5A9))
	CTimeCycle.m_nSunCoronaBlue 			= ffi.cast("unsigned char*", getuint32(0x55F5B5))
	CTimeCycle.m_fSunSize 					= ffi.cast("unsigned char*", getuint32(0x55F5C0))
	CTimeCycle.m_fSpriteSize 				= ffi.cast("unsigned char*", getuint32(0x55F5D2))
	CTimeCycle.m_fSpriteBrightness 		    = ffi.cast("unsigned char*", getuint32(0x55F5E4))
	CTimeCycle.m_nShadowStrength 			= ffi.cast("unsigned char*", getuint32(0x55F5F7))
	CTimeCycle.m_nLightShadowStrength		= ffi.cast("unsigned char*", getuint32(0x55F603))
	CTimeCycle.m_nPoleShadowStrength 		= ffi.cast("unsigned char*", getuint32(0x55F60F))
	CTimeCycle.m_fFarClip 					= ffi.cast("short*", getuint32(0x55F61B))
	CTimeCycle.m_fFogStart 				    = ffi.cast("short*", getuint32(0x55F62E))
	CTimeCycle.m_fLightsOnGroundBrightness  = ffi.cast("unsigned char*", getuint32(0x55F640))
	CTimeCycle.m_nLowCloudsRed 			    = ffi.cast("unsigned char*", getuint32(0x55F653))
	CTimeCycle.m_nLowCloudsGreen 			= ffi.cast("unsigned char*", getuint32(0x55F65F))
	CTimeCycle.m_nLowCloudsBlue 			= ffi.cast("unsigned char*", getuint32(0x55F66B))
	CTimeCycle.m_nFluffyCloudsBottomRed 	= ffi.cast("unsigned char*", getuint32(0x55F677))
	CTimeCycle.m_nFluffyCloudsBottomGreen 	= ffi.cast("unsigned char*", getuint32(0x55F683))
	CTimeCycle.m_nFluffyCloudsBottomBlue 	= ffi.cast("unsigned char*", getuint32(0x55F690))
	CTimeCycle.m_fWaterRed 				    = ffi.cast("unsigned char*", getuint32(0x55F69C))
	CTimeCycle.m_fWaterGreen 				= ffi.cast("unsigned char*", getuint32(0x55F6B0))
	CTimeCycle.m_fWaterBlue 				= ffi.cast("unsigned char*", getuint32(0x55F6C3))
	CTimeCycle.m_fWaterAlpha 				= ffi.cast("unsigned char*", getuint32(0x55F6D6))
	CTimeCycle.m_fPostFx1Red 				= ffi.cast("unsigned char*", getuint32(0x55F6E9))
	CTimeCycle.m_fPostFx1Green 			    = ffi.cast("unsigned char*", getuint32(0x55F6FC))
	CTimeCycle.m_fPostFx1Blue 				= ffi.cast("unsigned char*", getuint32(0x55F70F))
	CTimeCycle.m_fPostFx1Alpha 			    = ffi.cast("unsigned char*", getuint32(0x55F725))
	CTimeCycle.m_fPostFx2Red 				= ffi.cast("unsigned char*", getuint32(0x55F73B))
	CTimeCycle.m_fPostFx2Green 			    = ffi.cast("unsigned char*", getuint32(0x55F751))
	CTimeCycle.m_fPostFx2Blue 				= ffi.cast("unsigned char*", getuint32(0x55F767))
	CTimeCycle.m_fPostFx2Alpha 			    = ffi.cast("unsigned char*", getuint32(0x55F77D))
	CTimeCycle.m_fCloudAlpha 				= ffi.cast("unsigned char*", getuint32(0x55F793))
	CTimeCycle.m_nHighLightMinIntensity 	= ffi.cast("unsigned char*", getuint32(0x55F7A9))
	CTimeCycle.m_nWaterFogAlpha 			= ffi.cast("unsigned char*", getuint32(0x55F7B8))
	CTimeCycle.m_nDirectionalMult 			= ffi.cast("unsigned char*", getuint32(0x55F7C7))

	CTimeCycle.Initialise 					= ffi.cast("void (__cdecl*)(void)", 0x5BBAC0)
end
CTimeCycle_DATA()

CTimeCycle.Initialise()

local CurrWeather 	= ffi.cast("short*", 0xC81320)
local NextWeather 	= ffi.cast("short*", 0xC8131C)
local Hours 		= ffi.cast("unsigned char*", 0xB70153)
local Minutes 		= ffi.cast("unsigned char*", 0xB70152)
local Seconds 		= ffi.cast("unsigned short*", 0xB70150)
local TimeScale 	= ffi.cast("unsigned int*", 0xB7015C)
local NUMWEATHERS 	= 23

TimecycEditor.Im = {
	CurrWeather 		= imgui.new.int(CurrWeather[0]),
	NextWeather 		= imgui.new.int(NextWeather[0]),
}

if getModuleHandle("timecycle24.asi") ~= 0 or getModuleHandle("timecycle24") ~= 0 then
    NUMHOURS = 24
    bTimecyc24h = true
else
    NUMHOURS = 8
    bTimecyc24h = false
end


--
local sizeX, sizeY = getScreenResolution()

function TimecycEditor.ImGui_Draw()
	TimecycEditor.Im = {
		CurrWeather 		= imgui.new.int(CurrWeather[0]),
		NextWeather 		= imgui.new.int(NextWeather[0]),
	}
	imgui.SetNextWindowPos(imgui.ImVec2(sizeX / 2, sizeY / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
	imgui.SetNextWindowSize(imgui.ImVec2(665, 920), imgui.Cond.FirstUseEver)
	imgui.PushStyleColor(imgui.Col.WindowBg, imgui.ImVec4(0.0, 0.0, 0.0, 1.0))
	imgui.Begin(u8"�������� ���������", GT_MOD.UI.tcyc)

	if not GT_MOD.config.ini.settings.blocktime or not GT_MOD.config.ini.settings.blockweather then
		imgui.Text(u8"������� �� �������� �� ������ ������.\n�������� ���������� ������ � �������.")
	else

		if GT_MOD.config.ini.settings.gtatime or GT_MOD.config.ini.settings.sync_time or GT_MOD.config.ini.settings.gtaweather then
			imgui.Text(u8"������� �� �������� �� ������ ������.\n��������� ���� ������� � ������, ������������� �������� ������� � ��.")
		elseif GT_MOD.config.ini.fixtimecyc.active then
			imgui.Text(u8"��������� ����������� ���������!")
			if imgui.Checkbox(u8"��������� ��������� ��� ����������� ����-���������", checkboxes.fixtimecyc) then
				GT_MOD.config.ini.fixtimecyc.active = checkboxes.fixtimecyc[0]
				GT_MOD.config.save()
				GT_MOD.functions.gotofunc("FixTimecyc")
			end
		else
			if imgui.Button(u8"�������� ��������") then
				CTimeCycle.Initialise()
			end
			imgui.NewLine()
			Im_Update()
		
			imgui.PushItemWidth(400)
			local i = NUMWEATHERS * CTimeCycle.GetCurrentHourTimeId() + CurrWeather[0]
		
			CurrWeather[0] = TimecycEditor.Im.CurrWeather[0]
			NextWeather[0] = TimecycEditor.Im.NextWeather[0]


			if imgui.Combo(u8"������� ������", TimecycEditor.Im.CurrWeather, weatherchar, #weather) then
				CurrWeather[0] = TimecycEditor.Im.CurrWeather[0]
				GT_MOD.config.ini.settings.weather = TimecycEditor.Im.CurrWeather[0]
				GT_MOD.config.save()
			end

			if imgui.Combo(u8"��������� ������", TimecycEditor.Im.NextWeather, weatherchar, #weather) then
				NextWeather[0] = TimecycEditor.Im.NextWeather[0]
			end

			if imgui.SliderInt(u8"����", sliders.hours, 0, 23, "%.0f") then GT_MOD.config.ini.settings.hours = sliders.hours[0] GT_MOD.config.save() GT_MOD.functions.gotofunc("SetTime") end

			if imgui.SliderInt(u8"������", sliders.min, 0, 59, "%.0f") then GT_MOD.config.ini.settings.min = sliders.min[0] GT_MOD.config.save() GT_MOD.functions.gotofunc("SetTime") end

			if imgui.ColorEdit3(u8"���������", TimecycEditor.Im.AmbRGB) then
				CTimeCycle.m_nAmbientRed[i], CTimeCycle.m_nAmbientGreen[i], CTimeCycle.m_nAmbientBlue[i] = TimecycEditor.Im.AmbRGB[0] * 255, TimecycEditor.Im.AmbRGB[1] * 255, TimecycEditor.Im.AmbRGB[2] * 255
			end
			
			if imgui.ColorEdit3(u8"��������� �����. ��������", TimecycEditor.Im.AmbObjRGB) then
				CTimeCycle.m_nAmbientRed_Obj[i], CTimeCycle.m_nAmbientGreen_Obj[i], CTimeCycle.m_nAmbientBlue_Obj[i] = TimecycEditor.Im.AmbObjRGB[0] * 255, TimecycEditor.Im.AmbObjRGB[1] * 255, TimecycEditor.Im.AmbObjRGB[2] * 255
			end
	
			if imgui.ColorEdit3(u8"���� ����", TimecycEditor.Im.SkyTopRGB) then
				CTimeCycle.m_nSkyTopRed[i], CTimeCycle.m_nSkyTopGreen[i], CTimeCycle.m_nSkyTopBlue[i] = TimecycEditor.Im.SkyTopRGB[0] * 255, TimecycEditor.Im.SkyTopRGB[1] * 255, TimecycEditor.Im.SkyTopRGB[2] * 255
			end
	
			if imgui.ColorEdit3(u8"���� ���", TimecycEditor.Im.SkyBottomRGB) then
				CTimeCycle.m_nSkyBottomRed[i], CTimeCycle.m_nSkyBottomGreen[i], CTimeCycle.m_nSkyBottomBlue[i] = TimecycEditor.Im.SkyBottomRGB[0] * 255, TimecycEditor.Im.SkyBottomRGB[1] * 255, TimecycEditor.Im.SkyBottomRGB[2] * 255
			end
	
			if imgui.ColorEdit3(u8"��������� ����", TimecycEditor.Im.SunCoreRGB) then
				CTimeCycle.m_nSunCoreRed[i], CTimeCycle.m_nSunCoreGreen[i], CTimeCycle.m_nSunCoreBlue[i] = TimecycEditor.Im.SunCoreRGB[0] * 255, TimecycEditor.Im.SunCoreRGB[1] * 255, TimecycEditor.Im.SunCoreRGB[2] * 255
			end
	
			if imgui.ColorEdit3(u8"��������� ������", TimecycEditor.Im.SunCoronaRGB) then
				CTimeCycle.m_nSunCoronaRed[i], CTimeCycle.m_nSunCoronaGreen[i], CTimeCycle.m_nSunCoronaBlue[i] = TimecycEditor.Im.SunCoronaRGB[0] * 255, TimecycEditor.Im.SunCoronaRGB[1] * 255, TimecycEditor.Im.SunCoronaRGB[2] * 255
			end

			if imgui.SliderInt(u8"������ ������", TimecycEditor.Im.SunSz, 0, 127) then
				CTimeCycle.m_fSunSize[i] = TimecycEditor.Im.SunSz[0]
			end
	
			if imgui.SliderInt(u8"������ �������", TimecycEditor.Im.SpriteSz, 0, 127) then
				CTimeCycle.m_fSpriteSize[i] = TimecycEditor.Im.SpriteSz[0]
			end
	
			if imgui.InputInt(u8"������� �������", TimecycEditor.Im.SpriteBrght, 1, 10) then
				CTimeCycle.m_fSpriteBrightness[i] = TimecycEditor.Im.SpriteBrght[0]
			end
	
			if imgui.SliderInt(u8"��������� �����", TimecycEditor.Im.ShadowStr, 0, 255) then
				CTimeCycle.m_nShadowStrength[i] = TimecycEditor.Im.ShadowStr[0]
			end
	
			if imgui.SliderInt(u8"�������� ����� �����", TimecycEditor.Im.PoleShadowStr, 0, 255) then
				CTimeCycle.m_nPoleShadowStrength[i] = TimecycEditor.Im.PoleShadowStr[0]
			end
	
			if imgui.SliderInt(u8"���� ��������� �� ��������", TimecycEditor.Im.LightShadowStrength, 0, 255) then
				CTimeCycle.m_nLightShadowStrength[i] = TimecycEditor.Im.LightShadowStrength[0]
			end
	
			if imgui.InputInt(u8"���������� �� ��������", TimecycEditor.Im.FarClip, 1, 10) then
				CTimeCycle.m_fFarClip[i] = TimecycEditor.Im.FarClip[0]
			end
	
			if imgui.InputInt(u8"���������� �� ������", TimecycEditor.Im.FogStart, 1, 10) then
				CTimeCycle.m_fFogStart[i] = TimecycEditor.Im.FogStart[0]
			end
	
			if imgui.SliderInt(u8"������� ����� �� �����", TimecycEditor.Im.LightsOnGroundBrightness, 0, 255) then
				CTimeCycle.m_fLightsOnGroundBrightness[i] = TimecycEditor.Im.LightsOnGroundBrightness[0]
			end
	
			if imgui.ColorEdit3(u8"������ ������", TimecycEditor.Im.LowCloudsRGB) then
				CTimeCycle.m_nLowCloudsRed[i], CTimeCycle.m_nLowCloudsGreen[i], CTimeCycle.m_nLowCloudsBlue[i] = TimecycEditor.Im.LowCloudsRGB[0] * 255, TimecycEditor.Im.LowCloudsRGB[1] * 255, TimecycEditor.Im.LowCloudsRGB[2] * 255
			end
			if imgui.ColorEdit3(u8"������� ������", TimecycEditor.Im.FluffyCloudsBotttomRGB) then
				CTimeCycle.m_nFluffyCloudsBottomRed[i], CTimeCycle.m_nFluffyCloudsBottomGreen[i], CTimeCycle.m_nFluffyCloudsBottomBlue[i] = TimecycEditor.Im.FluffyCloudsBotttomRGB[0] * 255, TimecycEditor.Im.FluffyCloudsBotttomRGB[1] * 255, TimecycEditor.Im.FluffyCloudsBotttomRGB[2] * 255
			end
	
			if imgui.ColorEdit4(u8"����", TimecycEditor.Im.WaterRGBA, imgui.ColorEditFlags.AlphaBar) then
				CTimeCycle.m_fWaterRed[i], CTimeCycle.m_fWaterGreen[i], CTimeCycle.m_fWaterBlue[i], CTimeCycle.m_fWaterAlpha[i] = TimecycEditor.Im.WaterRGBA[0] * 255, TimecycEditor.Im.WaterRGBA[1] * 255, TimecycEditor.Im.WaterRGBA[2] * 255, TimecycEditor.Im.WaterRGBA[3] * 255
			end
	
			if imgui.ColorEdit4("PostFx1", TimecycEditor.Im.PostFx1RGBA, imgui.ColorEditFlags.AlphaBar) then
				CTimeCycle.m_fPostFx1Red[i], CTimeCycle.m_fPostFx1Green[i], CTimeCycle.m_fPostFx1Blue[i], CTimeCycle.m_fPostFx1Alpha[i] = TimecycEditor.Im.PostFx1RGBA[0] * 255, TimecycEditor.Im.PostFx1RGBA[1] * 255, TimecycEditor.Im.PostFx1RGBA[2] * 255, TimecycEditor.Im.PostFx1RGBA[3] * 255
			end
	
			if imgui.ColorEdit4("PostFx2", TimecycEditor.Im.PostFx2RGBA, imgui.ColorEditFlags.AlphaBar) then
				CTimeCycle.m_fPostFx2Red[i], CTimeCycle.m_fPostFx2Green[i], CTimeCycle.m_fPostFx2Blue[i], CTimeCycle.m_fPostFx2Alpha[i] = TimecycEditor.Im.PostFx2RGBA[0] * 255, TimecycEditor.Im.PostFx2RGBA[1] * 255, TimecycEditor.Im.PostFx2RGBA[2] * 255, TimecycEditor.Im.PostFx2RGBA[3] * 255
			end
	
			if imgui.SliderInt(u8"������������ �������", TimecycEditor.Im.CloudAlpha, 0, 255) then
				CTimeCycle.m_fCloudAlpha[i] = TimecycEditor.Im.CloudAlpha[0]
			end
	
			if imgui.SliderInt(u8"���. ������������� ���������", TimecycEditor.Im.HighLightMinIntensity, 0 ,255) then
				CTimeCycle.m_nHighLightMinIntensity[i] = TimecycEditor.Im.HighLightMinIntensity[0]
			end
	
			if imgui.SliderInt(u8"������������ ������ �� ����", TimecycEditor.Im.WaterFogAlpha, 0, 255) then
				CTimeCycle.m_nWaterFogAlpha[i] = TimecycEditor.Im.WaterFogAlpha[0]
			end

			if imgui.SliderInt(u8"���� ���������", TimecycEditor.Im.DirectionalMult, 0, 255) then
				CTimeCycle.m_nDirectionalMult[i] = TimecycEditor.Im.DirectionalMult[0]
			end
	
			if imgui.Button(u8"��������� ��������") then
				CTimeCycle.SaveToFile("timecyc")
				printStringNow("Timecyc created!", 1000)
			end
	
			
			
			imgui.PopItemWidth()
		end
	end
	imgui.PopStyleColor()
	imgui.End()
end

--


function Im_Update()
	local i = NUMWEATHERS * CTimeCycle.GetCurrentHourTimeId() + CurrWeather[0]
	TimecycEditor.Im.Hours 					= imgui.new.int(Hours[0])
	TimecycEditor.Im.Mins 					= imgui.new.int(Minutes[0])
	TimecycEditor.Im.Seconds 					= imgui.new.int(Seconds[0])
	TimecycEditor.Im.TimeScale 				= imgui.new.int(TimeScale[0])
	TimecycEditor.Im.AmbRGB 					= imgui.new.float[3](CTimeCycle.m_nAmbientRed[i] /255, CTimeCycle.m_nAmbientGreen[i] /255, CTimeCycle.m_nAmbientBlue[i] /255)
	TimecycEditor.Im.AmbObjRGB 				= imgui.new.float[3](CTimeCycle.m_nAmbientRed_Obj[i] / 255, CTimeCycle.m_nAmbientGreen_Obj[i] / 255, CTimeCycle.m_nAmbientBlue_Obj[i] / 255)
	TimecycEditor.Im.SkyTopRGB 				= imgui.new.float[3](CTimeCycle.m_nSkyTopRed[i] / 255, CTimeCycle.m_nSkyTopGreen[i] / 255, CTimeCycle.m_nSkyTopBlue[i] / 255)
	TimecycEditor.Im.SkyBottomRGB 			= imgui.new.float[3](CTimeCycle.m_nSkyBottomRed[i] / 255, CTimeCycle.m_nSkyBottomGreen[i] / 255, CTimeCycle.m_nSkyBottomBlue[i] / 255)
	TimecycEditor.Im.SunCoreRGB 				= imgui.new.float[3](CTimeCycle.m_nSunCoreRed[i] / 255, CTimeCycle.m_nSunCoreGreen[i] / 255, CTimeCycle.m_nSunCoreBlue[i] / 255)
	TimecycEditor.Im.SunCoronaRGB 			= imgui.new.float[3](CTimeCycle.m_nSunCoronaRed[i] / 255, CTimeCycle.m_nSunCoronaGreen[i] / 255, CTimeCycle.m_nSunCoronaBlue[i] / 255)
	TimecycEditor.Im.SunSz 					= imgui.new.int(CTimeCycle.m_fSunSize[i])
	TimecycEditor.Im.SpriteSz 				= imgui.new.int(CTimeCycle.m_fSpriteSize[i])
	TimecycEditor.Im.SpriteBrght 				= imgui.new.int(CTimeCycle.m_fSpriteBrightness[i])
	TimecycEditor.Im.ShadowStr 				= imgui.new.int(CTimeCycle.m_nShadowStrength[i])
	TimecycEditor.Im.PoleShadowStr 			= imgui.new.int(CTimeCycle.m_nPoleShadowStrength[i])
	TimecycEditor.Im.LightShadowStrength 		= imgui.new.int(CTimeCycle.m_nLightShadowStrength[i])
	TimecycEditor.Im.FarClip 					= imgui.new.int(CTimeCycle.m_fFarClip[i])
	TimecycEditor.Im.FogStart 				= imgui.new.int(CTimeCycle.m_fFogStart[i])
	TimecycEditor.Im.LightsOnGroundBrightness = imgui.new.int(CTimeCycle.m_fLightsOnGroundBrightness[i])
	TimecycEditor.Im.LowCloudsRGB 			= imgui.new.float[3](CTimeCycle.m_nLowCloudsRed[i] / 255, CTimeCycle.m_nLowCloudsGreen[i] / 255, CTimeCycle.m_nLowCloudsBlue[i] / 255)
	TimecycEditor.Im.FluffyCloudsBotttomRGB 	= imgui.new.float[3](CTimeCycle.m_nFluffyCloudsBottomRed[i] / 255, CTimeCycle.m_nFluffyCloudsBottomGreen[i] / 255, CTimeCycle.m_nFluffyCloudsBottomBlue[i] / 255)
	TimecycEditor.Im.WaterRGBA 				= imgui.new.float[4](CTimeCycle.m_fWaterRed[i] / 255, CTimeCycle.m_fWaterGreen[i] / 255, CTimeCycle.m_fWaterBlue[i] / 255, CTimeCycle.m_fWaterAlpha[i] / 255)
	TimecycEditor.Im.PostFx1RGBA 				= imgui.new.float[4](CTimeCycle.m_fPostFx1Red[i] / 255, CTimeCycle.m_fPostFx1Green[i] / 255, CTimeCycle.m_fPostFx1Blue[i] / 255, CTimeCycle.m_fPostFx1Alpha[i] / 255)
	TimecycEditor.Im.PostFx2RGBA 				= imgui.new.float[4](CTimeCycle.m_fPostFx2Red[i] / 255, CTimeCycle.m_fPostFx2Green[i] / 255, CTimeCycle.m_fPostFx2Blue[i] / 255, CTimeCycle.m_fPostFx2Alpha[i] / 255)
	TimecycEditor.Im.CloudAlpha 				= imgui.new.int(CTimeCycle.m_fCloudAlpha[i])
	TimecycEditor.Im.HighLightMinIntensity 	= imgui.new.int(CTimeCycle.m_nHighLightMinIntensity[i])
	TimecycEditor.Im.WaterFogAlpha 			= imgui.new.int(CTimeCycle.m_nWaterFogAlpha[i])
	TimecycEditor.Im.DirectionalMult 			= imgui.new.int(CTimeCycle.m_nDirectionalMult[i])
end

-- Timecyc Stuff
function CTimeCycle.GetCurrentHourTimeId()
	local h = Hours[0]
	local id = nil
	if bTimecyc24h then return h end

	if h < 5 then  id = 0 end
	if h == 5 then  id = 1 end
	if h == 6 then  id = 2 end
	if 7 <= h and h < 12 then  id = 3 end
	if 12 <= h and h < 19 then  id = 4 end
	if h == 19 then  id = 5 end
	if h == 20 or h == 21 then  id = 6 end
	if h == 22 or h == 23 then  id = 7 end
	return id
end


function CTimeCycle.SaveToFile(filename)
    if not doesDirectoryExist(getWorkingDirectory().."\\GameTweaker\\timecyc") then
        createDirectory(getWorkingDirectory().."\\GameTweaker\\timecyc")
    end
	local timecycdat = io.open(getWorkingDirectory().."\\GameTweaker\\timecyc/"..filename .. ".dat", "w")
	local tc = CTimeCycle
	-- timecycdat:write("// TimeCycle created using Timecyc24h Editor\n// Be sure to check "..URL.." for updates!\n")

	for w = 0, NUMWEATHERS - 1 do
		timecycdat:write("//\n" .. "///////////////////////////////////////////" .. weather[w] .. " \n" .. "//\n")

		for h = 0, NUMHOURS - 1 do
			local i = NUMWEATHERS * h + w

			if bTimecyc24h then
				if (h >= 12) then
					if (h == 12) then
						timecycdat:write("// Midday \n")
					else
						timecycdat:write("// " .. (h - 12) .. "PM \n")
					end
				else
					if h == 0 then
						timecycdat:write("// Midnight \n")
					else
						timecycdat:write("// " .. h .. "AM \n")
					end
				end
			else
				if h == 0 then timecycdat:write("// Midnight\n") end
				if h == 1 then timecycdat:write("// 5 AM\n") end
				if h == 2 then timecycdat:write("// 6 AM\n") end
				if h == 3 then timecycdat:write("// 7 AM\n") end
				if h == 4 then timecycdat:write("// Midday\n") end
				if h == 5 then timecycdat:write("// 7 PM\n") end
				if h == 6 then timecycdat:write("// 8 PM\n") end
				if h == 7 then timecycdat:write("// 10 PM\n") end
			end


			-- timecycdat:write("// "..j.." \n")

			if (h == 0 or h == 12 and not bTimecyc24h) then
				timecycdat:write("//\tAmb\t\t\t\t\tAmb_Obj \t\t\t\tDir \t\t\t\t\tSky top\t\t\t\tSky bot\t\t\t\tSunCore\t\t\tSunCorona\t\t\tSunSz\t\tSprSz\tSprBght\t\tShdw\t\t\tLightShd\t\t\tPoleShd\t\t\tFarClp\t\t\tFogSt\t\t\tLightOnGround\t\t\tLowCloudsRGB\t\t\tBottomCloudRGB\t\t\tWaterRGBA\t\t\tAlpha1    RGB1\t\t\tAlpha2    RGB2\t\t\tCloudAlpha\t\t\tIntensityLimit\t\t\tWaterFogAlpha\t\t\tDirMult \n")
			end
			timecycdat:write(
				string.format(
					"\t%d %d %d \t\t" .. -- AmbRGB
					"\t%d %d %d \t\t" .. -- AmbObjRGB
					"\t%d %d %d \t\t" .. -- DirRGB (unused?)
					"\t%d %d %d \t\t" .. -- SkyTopRGB
					"\t%d %d %d \t\t" .. -- SkyBotRGB
					"\t%d %d %d \t\t" .. -- SunCore RGB
					"\t%d %d %d \t\t" .. -- SunCorona RGB
					"\t%.1f\t\t%.1f\t\t%.1f\t\t" .. -- SunSz, SpriteSz, SpriteBrightness
					"\t%d %d %d\t\t" .. -- ShadStrenght, LightShadStreght, PoleShadStrenght
					"\t%.1f\t\t%.1f\t\t%.1f\t\t" .. -- fFarClip, fFogStart, fLightsOnGroundBrightness
					"\t%d %d %d\t\t" .. -- LowCloudsRGB
					"\t%d %d %d\t\t" .. -- FluffyCloudsRGB
					"\t%d %d %d %d\t\t" .. -- WaterRGBA
					"\t%d %d %d %d\t\t" .. -- PostFx1ARGB
					"\t%d %d %d %d\t\t" .. -- PostFx2ARGB
					"\t%d\t%d\t%d\t%.2f\t\t\n", -- CloudAlpha HiLiMinIntensity WaterFogAlpha DirectionalMult
					tc.m_nAmbientRed[i], tc.m_nAmbientGreen[i],	tc.m_nAmbientBlue[i],
					tc.m_nAmbientRed_Obj[i], tc.m_nAmbientGreen_Obj[i],	tc.m_nAmbientBlue_Obj[i],
					255, 255, 255,
					tc.m_nSkyTopRed[i],	tc.m_nSkyTopGreen[i], tc.m_nSkyTopBlue[i],
					tc.m_nSkyBottomRed[i], tc.m_nSkyBottomGreen[i],	tc.m_nSkyBottomBlue[i],
					tc.m_nSunCoreRed[i],tc.m_nSunCoreGreen[i],tc.m_nSunCoreBlue[i],
					tc.m_nSunCoronaRed[i], tc.m_nSunCoronaGreen[i], tc.m_nSunCoronaBlue[i],
					(tc.m_fSunSize[i] - 0.5) / 10.0,(tc.m_fSpriteSize[i] - 0.5) / 10.0,(tc.m_fSpriteBrightness[i] - 0.5) / 10.0,
					tc.m_nShadowStrength[i],tc.m_nLightShadowStrength[i],tc.m_nPoleShadowStrength[i],
					tc.m_fFarClip[i],tc.m_fFogStart[i],	(tc.m_fLightsOnGroundBrightness[i] - 0.5) / 10.0,
					tc.m_nLowCloudsRed[i],tc.m_nLowCloudsGreen[i],tc.m_nLowCloudsBlue[i],
					tc.m_nFluffyCloudsBottomRed[i],tc.m_nFluffyCloudsBottomGreen[i],tc.m_nFluffyCloudsBottomBlue[i],
					tc.m_fWaterRed[i],tc.m_fWaterGreen[i],tc.m_fWaterBlue[i],tc.m_fWaterAlpha[i],
					tc.m_fPostFx1Alpha[i],tc.m_fPostFx1Red[i],tc.m_fPostFx1Green[i],tc.m_fPostFx1Blue[i],
					tc.m_fPostFx2Alpha[i],tc.m_fPostFx2Red[i],tc.m_fPostFx2Green[i],tc.m_fPostFx2Blue[i],
					tc.m_fCloudAlpha[i],tc.m_nHighLightMinIntensity[i],	tc.m_nWaterFogAlpha[i],	tc.m_nDirectionalMult[i] / 100.0
				)
			)
		end
	end
	io.close(timecycdat)
end

return TimecycEditor
end